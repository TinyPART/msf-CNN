// tvm target: c -keys=partial_conv,arm_cpu,cpu -mcpu=cortex-m4+nodsp -model=nrf52840
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_2_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_1(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_4_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_10(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_27_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_11(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_29_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_12(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_31_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_13(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_33_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_14(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_35_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_15(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_38_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_16(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_40_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_2(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_7_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_3(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_10_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_4(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_13_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_5(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_16_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_6(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_19_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_7(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_21_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_8(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_23_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_9(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_25_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_1_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_1(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_6_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_2(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_9_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_3(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_12_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_4(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_15_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_5(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_18_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_6(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_37_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_7(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_42_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_8(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_43_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_11(int32_t* iterator, int8_t* dummy_input_10, int8_t* weight_depth_wise_34, int8_t* weight_1x1_conv2d_linear_34, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_11_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_14(int32_t* iterator, int8_t* dummy_input_13, int8_t* weight_depth_wise_35, int8_t* weight_1x1_conv2d_linear_35, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_14_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_17(int32_t* iterator, int8_t* dummy_input_16, int8_t* weight_depth_wise_36, int8_t* weight_1x1_conv2d_linear_36, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_17_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_2(int32_t* iterator, int8_t* dummy_input_1, int8_t* weight_depth_wise_1, int8_t* conv2d_2, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_3_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_21(int32_t* iterator, int8_t* dummy_input_19, int8_t* weight_depth_wise_37, int8_t* weight_1x1_conv2d_linear_37, int8_t* weight_1x1_conv2d_38, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_20_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_24(int32_t* iterator, int8_t* dummy_input_22, int8_t* weight_depth_wise_38, int8_t* weight_1x1_conv2d_linear_38, int8_t* weight_1x1_conv2d_39, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_22_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_27(int32_t* iterator, int8_t* dummy_input_25, int8_t* weight_depth_wise_39, int8_t* weight_1x1_conv2d_linear_39, int8_t* weight_1x1_conv2d_40, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_24_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_30(int32_t* iterator, int8_t* dummy_input_28, int8_t* weight_depth_wise_40, int8_t* weight_1x1_conv2d_linear_40, int8_t* weight_1x1_conv2d_41, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_26_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_33(int32_t* iterator, int8_t* dummy_input_31, int8_t* weight_depth_wise_41, int8_t* weight_1x1_conv2d_linear_41, int8_t* weight_1x1_conv2d_42, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_28_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_36(int32_t* iterator, int8_t* dummy_input_34, int8_t* weight_depth_wise_42, int8_t* weight_1x1_conv2d_linear_42, int8_t* weight_1x1_conv2d_43, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_30_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_39(int32_t* iterator, int8_t* dummy_input_37, int8_t* weight_depth_wise_43, int8_t* weight_1x1_conv2d_linear_43, int8_t* weight_1x1_conv2d_44, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_32_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_42(int32_t* iterator, int8_t* dummy_input_40, int8_t* weight_depth_wise_44, int8_t* weight_1x1_conv2d_linear_44, int8_t* weight_1x1_conv2d_45, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_34_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_45(int32_t* iterator, int8_t* dummy_input_43, int8_t* weight_depth_wise_45, int8_t* weight_1x1_conv2d_linear_45, int8_t* weight_1x1_conv2d_46, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_36_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_48(int32_t* iterator, int8_t* dummy_input_47, int8_t* weight_1x1_conv2d_linear_46, int8_t* weight_1x1_conv2d_47, int8_t* conv2d_nchw, uint8_t* global_workspace_39_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_5(int32_t* iterator, int8_t* dummy_input_3, int8_t* weight_1x1_conv2d_32, int8_t* weight_depth_wise_32, int8_t* weight_1x1_conv2d_linear_32, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_5_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_51(int32_t* iterator, int8_t* dummy_input_49, int8_t* weight_depth_wise_47, int8_t* weight_1x1_conv2d_linear_47, int8_t* weight_1x1_conv2d_48, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_41_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_8(int32_t* iterator, int8_t* dummy_input_7, int8_t* weight_depth_wise_33, int8_t* weight_1x1_conv2d_linear_33, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_8_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(int8_t* data_buffer_var, int8_t* conv2d_1_buffer_var, int8_t* weight_depth_wise_1_buffer_var, int8_t* conv2d_2_buffer_var, int8_t* weight_1x1_conv2d_32_buffer_var, int8_t* weight_depth_wise_32_buffer_var, int8_t* weight_1x1_conv2d_linear_32_buffer_var, int8_t* weight_1x1_conv2d_33_buffer_var, int8_t* weight_depth_wise_33_buffer_var, int8_t* weight_1x1_conv2d_linear_33_buffer_var, int8_t* weight_1x1_conv2d_34_buffer_var, int8_t* weight_depth_wise_34_buffer_var, int8_t* weight_1x1_conv2d_linear_34_buffer_var, int8_t* weight_1x1_conv2d_35_buffer_var, int8_t* weight_depth_wise_35_buffer_var, int8_t* weight_1x1_conv2d_linear_35_buffer_var, int8_t* weight_1x1_conv2d_36_buffer_var, int8_t* weight_depth_wise_36_buffer_var, int8_t* weight_1x1_conv2d_linear_36_buffer_var, int8_t* weight_1x1_conv2d_37_buffer_var, int8_t* weight_depth_wise_37_buffer_var, int8_t* weight_1x1_conv2d_linear_37_buffer_var, int8_t* weight_1x1_conv2d_38_buffer_var, int8_t* weight_depth_wise_38_buffer_var, int8_t* weight_1x1_conv2d_linear_38_buffer_var, int8_t* weight_1x1_conv2d_39_buffer_var, int8_t* weight_depth_wise_39_buffer_var, int8_t* weight_1x1_conv2d_linear_39_buffer_var, int8_t* weight_1x1_conv2d_40_buffer_var, int8_t* weight_depth_wise_40_buffer_var, int8_t* weight_1x1_conv2d_linear_40_buffer_var, int8_t* weight_1x1_conv2d_41_buffer_var, int8_t* weight_depth_wise_41_buffer_var, int8_t* weight_1x1_conv2d_linear_41_buffer_var, int8_t* weight_1x1_conv2d_42_buffer_var, int8_t* weight_depth_wise_42_buffer_var, int8_t* weight_1x1_conv2d_linear_42_buffer_var, int8_t* weight_1x1_conv2d_43_buffer_var, int8_t* weight_depth_wise_43_buffer_var, int8_t* weight_1x1_conv2d_linear_43_buffer_var, int8_t* weight_1x1_conv2d_44_buffer_var, int8_t* weight_depth_wise_44_buffer_var, int8_t* weight_1x1_conv2d_linear_44_buffer_var, int8_t* weight_1x1_conv2d_45_buffer_var, int8_t* weight_depth_wise_45_buffer_var, int8_t* weight_1x1_conv2d_linear_45_buffer_var, int8_t* weight_1x1_conv2d_46_buffer_var, int8_t* weight_depth_wise_46_buffer_var, int8_t* weight_1x1_conv2d_linear_46_buffer_var, int8_t* weight_1x1_conv2d_47_buffer_var, int8_t* weight_depth_wise_47_buffer_var, int8_t* weight_1x1_conv2d_linear_47_buffer_var, int8_t* weight_1x1_conv2d_48_buffer_var, int8_t* weight_depth_wise_48_buffer_var, int8_t* weight_1x1_conv2d_linear_48_buffer_var, int8_t* output_buffer_var, uint8_t* global_workspace_0_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_2_var) {
  void* iterator_let = (&(global_workspace_2_var[186048]));
  void* iteratee_output_let = (&(global_workspace_2_var[186096]));
  void* bg_ind_let = (&(global_workspace_2_var[186080]));
  void* cache_buffer_var_let = (&(global_workspace_2_var[185856]));
  void* cache_cur_idx_let = (&(global_workspace_2_var[186064]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 87))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 87))) { break; }
      if (tvmgen_default_iteratee_2(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_2_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 8; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 61952) + (i * 7744)) + (((int32_t*)bg_ind_let)[1] * 7744)) + (((int32_t*)bg_ind_let)[2] * 88)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 87) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_1(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_4_var) {
  void* iterator_let = (&(global_workspace_4_var[2408]));
  void* iteratee_output_let = (&(global_workspace_4_var[2424]));
  void* bg_ind_let = (&(global_workspace_4_var[2456]));
  void* cache_buffer_var_let = (&(global_workspace_4_var[0]));
  void* cache_cur_idx_let = (&(global_workspace_4_var[2440]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 43))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 43))) { break; }
      if (tvmgen_default_iteratee_5(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_4_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 16; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 30976) + (i * 1936)) + (((int32_t*)bg_ind_let)[1] * 1936)) + (((int32_t*)bg_ind_let)[2] * 44)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 43) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_10(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_27_var) {
  void* iterator_let = (&(global_workspace_27_var[24360]));
  void* iteratee_output_let = (&(global_workspace_27_var[24160]));
  void* bg_ind_let = (&(global_workspace_27_var[24392]));
  void* cache_buffer_var_let = (&(global_workspace_27_var[19360]));
  void* cache_cur_idx_let = (&(global_workspace_27_var[24376]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_33(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_27_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 200; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 24200) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_11(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_29_var) {
  void* iterator_let = (&(global_workspace_29_var[59480]));
  void* iteratee_output_let = (&(global_workspace_29_var[59240]));
  void* bg_ind_let = (&(global_workspace_29_var[59512]));
  void* cache_buffer_var_let = (&(global_workspace_29_var[53240]));
  void* cache_cur_idx_let = (&(global_workspace_29_var[59496]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_36(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_29_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 240; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 29040) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_12(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_31_var) {
  void* iterator_let = (&(global_workspace_31_var[30960]));
  void* iteratee_output_let = (&(global_workspace_31_var[30720]));
  void* bg_ind_let = (&(global_workspace_31_var[30992]));
  void* cache_buffer_var_let = (&(global_workspace_31_var[63888]));
  void* cache_cur_idx_let = (&(global_workspace_31_var[30976]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_39(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_31_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 240; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 29040) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_13(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_33_var) {
  void* iterator_let = (&(global_workspace_33_var[67056]));
  void* iteratee_output_let = (&(global_workspace_33_var[66768]));
  void* bg_ind_let = (&(global_workspace_33_var[67088]));
  void* cache_buffer_var_let = (&(global_workspace_33_var[63888]));
  void* cache_cur_idx_let = (&(global_workspace_33_var[67072]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_42(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_33_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 288; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 34848) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_14(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_35_var) {
  void* iterator_let = (&(global_workspace_35_var[56064]));
  void* iteratee_output_let = (&(global_workspace_35_var[55584]));
  void* bg_ind_let = (&(global_workspace_35_var[56096]));
  void* cache_buffer_var_let = (&(global_workspace_35_var[52128]));
  void* cache_cur_idx_let = (&(global_workspace_35_var[56080]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 5))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 5))) { break; }
      if (tvmgen_default_iteratee_45(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_35_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 480; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 17280) + (i * 36)) + (((int32_t*)bg_ind_let)[1] * 36)) + (((int32_t*)bg_ind_let)[2] * 6)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 5) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_15(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_38_var) {
  void* iterator_let = (&(global_workspace_38_var[31968]));
  void* iteratee_output_let = (&(global_workspace_38_var[31584]));
  void* bg_ind_let = (&(global_workspace_38_var[31984]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 5))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 5))) { break; }
      if (tvmgen_default_iteratee_48(iterator_let, p0, p1, p2, iteratee_output_let, global_workspace_38_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 384; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 13824) + (i * 36)) + (((int32_t*)bg_ind_let)[1] * 36)) + (((int32_t*)bg_ind_let)[2] * 6)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 5) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_16(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_40_var) {
  void* iterator_let = (&(global_workspace_40_var[36192]));
  void* iteratee_output_let = (&(global_workspace_40_var[35712]));
  void* bg_ind_let = (&(global_workspace_40_var[36224]));
  void* cache_buffer_var_let = (&(global_workspace_40_var[31104]));
  void* cache_cur_idx_let = (&(global_workspace_40_var[36208]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 5))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 5))) { break; }
      if (tvmgen_default_iteratee_51(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_40_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 480; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 17280) + (i * 36)) + (((int32_t*)bg_ind_let)[1] * 36)) + (((int32_t*)bg_ind_let)[2] * 6)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 5) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_2(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_7_var) {
  void* iterator_let = (&(global_workspace_7_var[186816]));
  void* iteratee_output_let = (&(global_workspace_7_var[186832]));
  void* bg_ind_let = (&(global_workspace_7_var[186864]));
  void* cache_buffer_var_let = (&(global_workspace_7_var[185856]));
  void* cache_cur_idx_let = (&(global_workspace_7_var[186848]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 43))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 43))) { break; }
      if (tvmgen_default_iteratee_8(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_7_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 16; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 30976) + (i * 1936)) + (((int32_t*)bg_ind_let)[1] * 1936)) + (((int32_t*)bg_ind_let)[2] * 44)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 43) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_3(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_10_var) {
  void* iterator_let = (&(global_workspace_10_var[190336]));
  void* iteratee_output_let = (&(global_workspace_10_var[190352]));
  void* bg_ind_let = (&(global_workspace_10_var[190384]));
  void* cache_buffer_var_let = (&(global_workspace_10_var[185856]));
  void* cache_cur_idx_let = (&(global_workspace_10_var[190368]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 43))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 43))) { break; }
      if (tvmgen_default_iteratee_11(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_10_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 16; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 30976) + (i * 1936)) + (((int32_t*)bg_ind_let)[1] * 1936)) + (((int32_t*)bg_ind_let)[2] * 44)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 43) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_4(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_13_var) {
  void* iterator_let = (&(global_workspace_13_var[125824]));
  void* iteratee_output_let = (&(global_workspace_13_var[125840]));
  void* bg_ind_let = (&(global_workspace_13_var[125872]));
  void* cache_buffer_var_let = (&(global_workspace_13_var[123904]));
  void* cache_cur_idx_let = (&(global_workspace_13_var[125856]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 43))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 43))) { break; }
      if (tvmgen_default_iteratee_14(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_13_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 16; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 30976) + (i * 1936)) + (((int32_t*)bg_ind_let)[1] * 1936)) + (((int32_t*)bg_ind_let)[2] * 44)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 43) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_5(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_16_var) {
  void* iterator_let = (&(global_workspace_16_var[168920]));
  void* iteratee_output_let = (&(global_workspace_16_var[168896]));
  void* bg_ind_let = (&(global_workspace_16_var[168952]));
  void* cache_buffer_var_let = (&(global_workspace_16_var[166496]));
  void* cache_cur_idx_let = (&(global_workspace_16_var[168936]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 21))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 21))) { break; }
      if (tvmgen_default_iteratee_17(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_16_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 24; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 11616) + (i * 484)) + (((int32_t*)bg_ind_let)[1] * 484)) + (((int32_t*)bg_ind_let)[2] * 22)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 21) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_6(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_19_var) {
  void* iterator_let = (&(global_workspace_19_var[119880]));
  void* iteratee_output_let = (&(global_workspace_19_var[119760]));
  void* bg_ind_let = (&(global_workspace_19_var[119912]));
  void* cache_buffer_var_let = (&(global_workspace_19_var[116160]));
  void* cache_cur_idx_let = (&(global_workspace_19_var[119896]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 21))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 21))) { break; }
      if (tvmgen_default_iteratee_21(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_19_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 120; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 58080) + (i * 484)) + (((int32_t*)bg_ind_let)[1] * 484)) + (((int32_t*)bg_ind_let)[2] * 22)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 21) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_7(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_21_var) {
  void* iterator_let = (&(global_workspace_21_var[119880]));
  void* iteratee_output_let = (&(global_workspace_21_var[119760]));
  void* bg_ind_let = (&(global_workspace_21_var[119912]));
  void* cache_buffer_var_let = (&(global_workspace_21_var[116160]));
  void* cache_cur_idx_let = (&(global_workspace_21_var[119896]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 21))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 21))) { break; }
      if (tvmgen_default_iteratee_24(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_21_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 120; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 58080) + (i * 484)) + (((int32_t*)bg_ind_let)[1] * 484)) + (((int32_t*)bg_ind_let)[2] * 22)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 21) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_8(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_23_var) {
  void* iterator_let = (&(global_workspace_23_var[88800]));
  void* iteratee_output_let = (&(global_workspace_23_var[88560]));
  void* bg_ind_let = (&(global_workspace_23_var[88832]));
  void* cache_buffer_var_let = (&(global_workspace_23_var[87120]));
  void* cache_cur_idx_let = (&(global_workspace_23_var[88816]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_27(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_23_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 240; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 29040) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_9(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_25_var) {
  void* iterator_let = (&(global_workspace_25_var[44720]));
  void* iteratee_output_let = (&(global_workspace_25_var[44560]));
  void* bg_ind_let = (&(global_workspace_25_var[44752]));
  void* cache_buffer_var_let = (&(global_workspace_25_var[19360]));
  void* cache_cur_idx_let = (&(global_workspace_25_var[44736]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_30(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_25_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 160; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 19360) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_1_var) {
  void* pad_temp_let = (&(global_workspace_1_var[123904]));
  for (int32_t i1 = 0; i1 < 3; ++i1) {
    for (int32_t i2 = 0; i2 < 177; ++i2) {
      for (int32_t i3 = 0; i3 < 177; ++i3) {
        int8_t condval;
        if (((1 <= i2) && (1 <= i3))) {
          condval = p0[((((i1 * 30976) + (i2 * 176)) + i3) - 177)];
        } else {
          condval = (int8_t)0;
        }
        ((int8_t*)pad_temp_let)[(((i1 * 31329) + (i2 * 177)) + i3)] = condval;
      }
    }
  }
  for (int32_t ff = 0; ff < 16; ++ff) {
    for (int32_t yy = 0; yy < 88; ++yy) {
      for (int32_t xx = 0; xx < 88; ++xx) {
        conv2d_nchw[(((ff * 7744) + (yy * 88)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 3; ++rc) {
          for (int32_t ry = 0; ry < 3; ++ry) {
            for (int32_t rx = 0; rx < 3; ++rx) {
              int32_t cse_var_1 = (((ff * 7744) + (yy * 88)) + xx);
              conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (((int8_t*)pad_temp_let)[(((((rc * 31329) + (yy * 354)) + (ry * 177)) + (xx * 2)) + rx)] * p1[((((ff * 27) + (rc * 9)) + (ry * 3)) + rx)]));
            }
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_1(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_6_var) {
  for (int32_t ff = 0; ff < 80; ++ff) {
    for (int32_t yy = 0; yy < 44; ++yy) {
      for (int32_t xx = 0; xx < 44; ++xx) {
        conv2d_nchw[(((ff * 1936) + (yy * 44)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 16; ++rc) {
          int32_t cse_var_2 = (yy * 44);
          int32_t cse_var_1 = (((ff * 1936) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 1936) + cse_var_2) + xx)] * p1[((ff * 16) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_2(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_9_var) {
  for (int32_t ff = 0; ff < 80; ++ff) {
    for (int32_t yy = 0; yy < 44; ++yy) {
      for (int32_t xx = 0; xx < 44; ++xx) {
        conv2d_nchw[(((ff * 1936) + (yy * 44)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 16; ++rc) {
          int32_t cse_var_2 = (yy * 44);
          int32_t cse_var_1 = (((ff * 1936) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 1936) + cse_var_2) + xx)] * p1[((ff * 16) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_3(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_12_var) {
  for (int32_t ff = 0; ff < 64; ++ff) {
    for (int32_t yy = 0; yy < 44; ++yy) {
      for (int32_t xx = 0; xx < 44; ++xx) {
        conv2d_nchw[(((ff * 1936) + (yy * 44)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 16; ++rc) {
          int32_t cse_var_2 = (yy * 44);
          int32_t cse_var_1 = (((ff * 1936) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 1936) + cse_var_2) + xx)] * p1[((ff * 16) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_4(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_15_var) {
  for (int32_t ff = 0; ff < 80; ++ff) {
    for (int32_t yy = 0; yy < 44; ++yy) {
      for (int32_t xx = 0; xx < 44; ++xx) {
        conv2d_nchw[(((ff * 1936) + (yy * 44)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 16; ++rc) {
          int32_t cse_var_2 = (yy * 44);
          int32_t cse_var_1 = (((ff * 1936) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 1936) + cse_var_2) + xx)] * p1[((ff * 16) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_5(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_18_var) {
  for (int32_t ff = 0; ff < 120; ++ff) {
    for (int32_t yy = 0; yy < 22; ++yy) {
      for (int32_t xx = 0; xx < 22; ++xx) {
        conv2d_nchw[(((ff * 484) + (yy * 22)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 24; ++rc) {
          int32_t cse_var_2 = (yy * 22);
          int32_t cse_var_1 = (((ff * 484) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 484) + cse_var_2) + xx)] * p1[((ff * 24) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_6(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_37_var) {
  for (int32_t c = 0; c < 480; ++c) {
    for (int32_t i = 0; i < 6; ++i) {
      for (int32_t j = 0; j < 6; ++j) {
        DepthwiseConv2d[(((c * 36) + (i * 6)) + j)] = (int8_t)0;
        for (int32_t di = 0; di < 7; ++di) {
          for (int32_t dj = 0; dj < 7; ++dj) {
            int32_t cse_var_2 = (c * 36);
            int32_t cse_var_1 = ((cse_var_2 + (i * 6)) + j);
            DepthwiseConv2d[cse_var_1] = (DepthwiseConv2d[cse_var_1] + (p0[((cse_var_2 + (((i + di) % 6) * 6)) + ((j + dj) % 6))] * p1[(((c * 49) + (di * 7)) + dj)]));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_7(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_42_var) {
  for (int32_t c = 0; c < 480; ++c) {
    for (int32_t i = 0; i < 6; ++i) {
      for (int32_t j = 0; j < 6; ++j) {
        DepthwiseConv2d[(((c * 36) + (i * 6)) + j)] = (int8_t)0;
        for (int32_t di = 0; di < 7; ++di) {
          for (int32_t dj = 0; dj < 7; ++dj) {
            int32_t cse_var_2 = (c * 36);
            int32_t cse_var_1 = ((cse_var_2 + (i * 6)) + j);
            DepthwiseConv2d[cse_var_1] = (DepthwiseConv2d[cse_var_1] + (p0[((cse_var_2 + (((i + di) % 6) * 6)) + ((j + dj) % 6))] * p1[(((c * 49) + (di * 7)) + dj)]));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_8(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_43_var) {
  for (int32_t ff = 0; ff < 160; ++ff) {
    for (int32_t yy = 0; yy < 6; ++yy) {
      for (int32_t xx = 0; xx < 6; ++xx) {
        conv2d_nchw[(((ff * 36) + (yy * 6)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 480; ++rc) {
          int32_t cse_var_2 = (yy * 6);
          int32_t cse_var_1 = (((ff * 36) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 36) + cse_var_2) + xx)] * p1[((ff * 480) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_11(int32_t* iterator, int8_t* dummy_input_10, int8_t* weight_depth_wise_34, int8_t* weight_1x1_conv2d_linear_34, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_11_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_11_var[189776]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_11_var[0]));
  for (int32_t i1 = 0; i1 < 80; ++i1) {
    for (int32_t i2 = 0; i2 < 7; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 7) + i2)] = dummy_input_10[((((((iterator[0] * 154880) + (i1 * 1936)) + (iterator[1] * 1936)) + (i2 * 44)) + (iterator[2] * 44)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 80; ++i) {
      for (int32_t j = 0; j < 7; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 49) + (j * 7)) + ((cache_cur_idx[3] % 6) + (6 & ((cache_cur_idx[3] % 6) >> 31))))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 7) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (6 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 80; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 7; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 7; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 49) + (j_2 * 7)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 80; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 7; ++di) {
      for (int32_t dj = 0; dj < 7; ++dj) {
        int32_t cse_var_2 = (((c * 49) + (di * 7)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_34[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 16; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 80; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_34[((ff * 80) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_14(int32_t* iterator, int8_t* dummy_input_13, int8_t* weight_depth_wise_35, int8_t* weight_1x1_conv2d_linear_35, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_14_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_14_var[125504]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_14_var[0]));
  for (int32_t i1 = 0; i1 < 64; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_13[((((((iterator[0] * 123904) + (i1 * 1936)) + (iterator[1] * 1936)) + (i2 * 44)) + (iterator[2] * 44)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 64; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 64; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 64; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_2 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_35[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 16; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 64; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_35[((ff * 64) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_17(int32_t* iterator, int8_t* dummy_input_16, int8_t* weight_depth_wise_36, int8_t* weight_1x1_conv2d_linear_36, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_17_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_17_var[168496]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_17_var[0]));
  for (int32_t i1 = 0; i1 < 80; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_16[((((((iterator[0] * 154880) + (i1 * 1936)) + (iterator[1] * 1936)) + (i2 * 44)) + (iterator[2] * 44)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 80; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((4 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 80; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 80; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_2 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_36[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 24; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 80; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_36[((ff * 80) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_2(int32_t* iterator, int8_t* dummy_input_1, int8_t* weight_depth_wise_1, int8_t* conv2d_2, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_3_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_3_var[186000]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_3_var[0]));
  for (int32_t i1 = 0; i1 < 16; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_1[((((((iterator[0] * 123904) + (i1 * 7744)) + (iterator[1] * 7744)) + (i2 * 88)) + (iterator[2] * 88)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 16; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 16; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 16; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_1[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 8; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 16; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * conv2d_2[((ff * 16) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_21(int32_t* iterator, int8_t* dummy_input_19, int8_t* weight_depth_wise_37, int8_t* weight_1x1_conv2d_linear_37, int8_t* weight_1x1_conv2d_38, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_20_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_20_var[119160]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_20_var[0]));
  void* conv2d_nchw_let = (&(global_workspace_20_var[0]));
  for (int32_t i1 = 0; i1 < 120; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_19[((((((iterator[0] * 58080) + (i1 * 484)) + (iterator[1] * 484)) + (i2 * 22)) + (iterator[2] * 22)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 120; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 120; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 120; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_2 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_37[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 24; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 120; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_37[((ff * 120) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 120; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 24; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_38[((ff_1 * 24) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_24(int32_t* iterator, int8_t* dummy_input_22, int8_t* weight_depth_wise_38, int8_t* weight_1x1_conv2d_linear_38, int8_t* weight_1x1_conv2d_39, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_22_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_22_var[119160]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_22_var[58080]));
  void* conv2d_nchw_let = (&(global_workspace_22_var[58080]));
  for (int32_t i1 = 0; i1 < 120; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_22[((((((iterator[0] * 58080) + (i1 * 484)) + (iterator[1] * 484)) + (i2 * 22)) + (iterator[2] * 22)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 120; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 120; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 120; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_2 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_38[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 24; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 120; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_38[((ff * 120) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 120; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 24; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_39[((ff_1 * 24) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_27(int32_t* iterator, int8_t* dummy_input_25, int8_t* weight_depth_wise_39, int8_t* weight_1x1_conv2d_linear_39, int8_t* weight_1x1_conv2d_40, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_24_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_24_var[88200]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_24_var[0]));
  void* conv2d_nchw_let = (&(global_workspace_24_var[0]));
  for (int32_t i1 = 0; i1 < 120; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_25[((((((iterator[0] * 58080) + (i1 * 484)) + (iterator[1] * 484)) + (i2 * 22)) + (iterator[2] * 22)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 120; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((2 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 120; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 120; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_39[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 40; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 120; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_39[((ff * 120) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 240; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 40; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_40[((ff_1 * 40) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_30(int32_t* iterator, int8_t* dummy_input_28, int8_t* weight_depth_wise_40, int8_t* weight_1x1_conv2d_linear_40, int8_t* weight_1x1_conv2d_41, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_26_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_26_var[42880]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_26_var[31120]));
  void* conv2d_nchw_let = (&(global_workspace_26_var[31120]));
  for (int32_t i1 = 0; i1 < 240; ++i1) {
    for (int32_t i2 = 0; i2 < 7; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 7) + i2)] = dummy_input_28[((((((iterator[0] * 29040) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 240; ++i) {
      for (int32_t j = 0; j < 7; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 49) + (j * 7)) + ((cache_cur_idx[3] % 6) + (6 & ((cache_cur_idx[3] % 6) >> 31))))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 7) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (6 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 240; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 7; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 7; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 49) + (j_2 * 7)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 240; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 7; ++di) {
      for (int32_t dj = 0; dj < 7; ++dj) {
        int32_t cse_var_2 = (((c * 49) + (di * 7)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_40[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 40; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 240; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_40[((ff * 240) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 160; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 40; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_41[((ff_1 * 40) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_33(int32_t* iterator, int8_t* dummy_input_31, int8_t* weight_depth_wise_41, int8_t* weight_1x1_conv2d_linear_41, int8_t* weight_1x1_conv2d_42, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_28_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_28_var[23360]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_28_var[0]));
  void* conv2d_nchw_let = (&(global_workspace_28_var[0]));
  for (int32_t i1 = 0; i1 < 160; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_31[((((((iterator[0] * 19360) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 160; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 160; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 160; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_2 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_41[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 40; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 160; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_41[((ff * 160) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 200; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 40; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_42[((ff_1 * 40) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_36(int32_t* iterator, int8_t* dummy_input_34, int8_t* weight_depth_wise_42, int8_t* weight_1x1_conv2d_linear_42, int8_t* weight_1x1_conv2d_43, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_30_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_30_var[58240]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_30_var[29040]));
  void* conv2d_nchw_let = (&(global_workspace_30_var[29040]));
  for (int32_t i1 = 0; i1 < 200; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_34[((((((iterator[0] * 24200) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 200; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 200; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 200; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_2 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_42[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 200; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_42[((ff * 200) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 240; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 48; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_43[((ff_1 * 48) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_39(int32_t* iterator, int8_t* dummy_input_37, int8_t* weight_depth_wise_43, int8_t* weight_1x1_conv2d_linear_43, int8_t* weight_1x1_conv2d_44, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_32_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_32_var[29040]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_32_var[0]));
  void* conv2d_nchw_let = (&(global_workspace_32_var[0]));
  for (int32_t i1 = 0; i1 < 240; ++i1) {
    for (int32_t i2 = 0; i2 < 7; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 7) + i2)] = dummy_input_37[((((((iterator[0] * 29040) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 240; ++i) {
      for (int32_t j = 0; j < 7; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 49) + (j * 7)) + ((cache_cur_idx[3] % 6) + (6 & ((cache_cur_idx[3] % 6) >> 31))))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 7) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (6 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 240; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 7; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 7; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 49) + (j_2 * 7)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 240; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 7; ++di) {
      for (int32_t dj = 0; dj < 7; ++dj) {
        int32_t cse_var_2 = (((c * 49) + (di * 7)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_43[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 240; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_43[((ff * 240) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 240; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 48; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_44[((ff_1 * 48) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_42(int32_t* iterator, int8_t* dummy_input_40, int8_t* weight_depth_wise_44, int8_t* weight_1x1_conv2d_linear_44, int8_t* weight_1x1_conv2d_45, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_34_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_34_var[66048]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_34_var[34848]));
  void* conv2d_nchw_let = (&(global_workspace_34_var[34848]));
  for (int32_t i1 = 0; i1 < 240; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_40[((((((iterator[0] * 29040) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 240; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 240; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 240; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_44[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 240; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_44[((ff * 240) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 288; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 48; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_45[((ff_1 * 48) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_45(int32_t* iterator, int8_t* dummy_input_43, int8_t* weight_depth_wise_45, int8_t* weight_1x1_conv2d_linear_45, int8_t* weight_1x1_conv2d_46, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_36_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_36_var[54720]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_36_var[0]));
  void* conv2d_nchw_let = (&(global_workspace_36_var[0]));
  for (int32_t i1 = 0; i1 < 288; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_43[((((((iterator[0] * 34848) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 288; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((2 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 288; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 288; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_45[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 96; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 288; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_45[((ff * 288) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 480; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 96; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_46[((ff_1 * 96) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_48(int32_t* iterator, int8_t* dummy_input_47, int8_t* weight_1x1_conv2d_linear_46, int8_t* weight_1x1_conv2d_47, int8_t* conv2d_nchw, uint8_t* global_workspace_39_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_39_var[31104]));
  void* conv2d_nchw_let = (&(global_workspace_39_var[0]));
  for (int32_t i1 = 0; i1 < 480; ++i1) {
    ((int8_t*)dyn_slice_fixed_size_let)[i1] = dummy_input_47[(((((iterator[0] * 17280) + (i1 * 36)) + (iterator[1] * 36)) + (iterator[2] * 6)) + iterator[3])];
  }
  for (int32_t ff = 0; ff < 96; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 480; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_46[((ff * 480) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 384; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 96; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_47[((ff_1 * 96) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_5(int32_t* iterator, int8_t* dummy_input_3, int8_t* weight_1x1_conv2d_32, int8_t* weight_depth_wise_32, int8_t* weight_1x1_conv2d_linear_32, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_5_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_5_var[2352]));
  void* conv2d_nchw_let = (&(global_workspace_5_var[1176]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_5_var[1176]));
  for (int32_t i1 = 0; i1 < 8; ++i1) {
    for (int32_t i2 = 0; i2 < 7; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 7) + i2)] = dummy_input_3[((((((iterator[0] * 61952) + (i1 * 7744)) + (iterator[1] * 7744)) + (i2 * 88)) + (iterator[2] * 88)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 24; ++ff) {
    for (int32_t yy = 0; yy < 7; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 7) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 8; ++rc) {
        int32_t cse_var_1 = ((ff * 7) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 7) + yy)] * weight_1x1_conv2d_32[((ff * 8) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 24; ++i) {
      for (int32_t j = 0; j < 7; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 49) + (j * 7)) + ((cache_cur_idx[3] % 6) + (6 & ((cache_cur_idx[3] % 6) >> 31))))] = ((int8_t*)conv2d_nchw_let)[((i * 7) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((6 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 24; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 7; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 7; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 49) + (j_2 * 7)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 24; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 7; ++di) {
      for (int32_t dj = 0; dj < 7; ++dj) {
        int32_t cse_var_3 = (((c * 49) + (di * 7)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_3] * weight_depth_wise_32[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 16; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 24; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)dyn_slice_fixed_size_let)[rc_1] * weight_1x1_conv2d_linear_32[((ff_1 * 24) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_51(int32_t* iterator, int8_t* dummy_input_49, int8_t* weight_depth_wise_47, int8_t* weight_1x1_conv2d_linear_47, int8_t* weight_1x1_conv2d_48, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_41_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_41_var[34560]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_41_var[17280]));
  void* conv2d_nchw_let = (&(global_workspace_41_var[17280]));
  for (int32_t i1 = 0; i1 < 384; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_49[((((((iterator[0] * 13824) + (i1 * 36)) + (iterator[1] * 36)) + (i2 * 6)) + (iterator[2] * 6)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 384; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 384; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 384; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_47[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 96; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 384; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_47[((ff * 384) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 480; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 96; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_48[((ff_1 * 96) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_8(int32_t* iterator, int8_t* dummy_input_7, int8_t* weight_depth_wise_33, int8_t* weight_1x1_conv2d_linear_33, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_8_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_8_var[186576]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_8_var[0]));
  for (int32_t i1 = 0; i1 < 80; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_7[((((((iterator[0] * 154880) + (i1 * 1936)) + (iterator[1] * 1936)) + (i2 * 44)) + (iterator[2] * 44)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 80; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 80; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 80; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_33[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 16; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 80; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_33[((ff * 80) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(int8_t* data_buffer_var, int8_t* conv2d_1_buffer_var, int8_t* weight_depth_wise_1_buffer_var, int8_t* conv2d_2_buffer_var, int8_t* weight_1x1_conv2d_32_buffer_var, int8_t* weight_depth_wise_32_buffer_var, int8_t* weight_1x1_conv2d_linear_32_buffer_var, int8_t* weight_1x1_conv2d_33_buffer_var, int8_t* weight_depth_wise_33_buffer_var, int8_t* weight_1x1_conv2d_linear_33_buffer_var, int8_t* weight_1x1_conv2d_34_buffer_var, int8_t* weight_depth_wise_34_buffer_var, int8_t* weight_1x1_conv2d_linear_34_buffer_var, int8_t* weight_1x1_conv2d_35_buffer_var, int8_t* weight_depth_wise_35_buffer_var, int8_t* weight_1x1_conv2d_linear_35_buffer_var, int8_t* weight_1x1_conv2d_36_buffer_var, int8_t* weight_depth_wise_36_buffer_var, int8_t* weight_1x1_conv2d_linear_36_buffer_var, int8_t* weight_1x1_conv2d_37_buffer_var, int8_t* weight_depth_wise_37_buffer_var, int8_t* weight_1x1_conv2d_linear_37_buffer_var, int8_t* weight_1x1_conv2d_38_buffer_var, int8_t* weight_depth_wise_38_buffer_var, int8_t* weight_1x1_conv2d_linear_38_buffer_var, int8_t* weight_1x1_conv2d_39_buffer_var, int8_t* weight_depth_wise_39_buffer_var, int8_t* weight_1x1_conv2d_linear_39_buffer_var, int8_t* weight_1x1_conv2d_40_buffer_var, int8_t* weight_depth_wise_40_buffer_var, int8_t* weight_1x1_conv2d_linear_40_buffer_var, int8_t* weight_1x1_conv2d_41_buffer_var, int8_t* weight_depth_wise_41_buffer_var, int8_t* weight_1x1_conv2d_linear_41_buffer_var, int8_t* weight_1x1_conv2d_42_buffer_var, int8_t* weight_depth_wise_42_buffer_var, int8_t* weight_1x1_conv2d_linear_42_buffer_var, int8_t* weight_1x1_conv2d_43_buffer_var, int8_t* weight_depth_wise_43_buffer_var, int8_t* weight_1x1_conv2d_linear_43_buffer_var, int8_t* weight_1x1_conv2d_44_buffer_var, int8_t* weight_depth_wise_44_buffer_var, int8_t* weight_1x1_conv2d_linear_44_buffer_var, int8_t* weight_1x1_conv2d_45_buffer_var, int8_t* weight_depth_wise_45_buffer_var, int8_t* weight_1x1_conv2d_linear_45_buffer_var, int8_t* weight_1x1_conv2d_46_buffer_var, int8_t* weight_depth_wise_46_buffer_var, int8_t* weight_1x1_conv2d_linear_46_buffer_var, int8_t* weight_1x1_conv2d_47_buffer_var, int8_t* weight_depth_wise_47_buffer_var, int8_t* weight_1x1_conv2d_linear_47_buffer_var, int8_t* weight_1x1_conv2d_48_buffer_var, int8_t* weight_depth_wise_48_buffer_var, int8_t* weight_1x1_conv2d_linear_48_buffer_var, int8_t* output_buffer_var, uint8_t* global_workspace_0_var) {
  void* sid_56_let = (&(global_workspace_0_var[123904]));
  void* sid_55_let = (&(global_workspace_0_var[0]));
  void* sid_60_let = (&(global_workspace_0_var[0]));
  void* sid_67_let = (&(global_workspace_0_var[58080]));
  void* sid_59_let = (&(global_workspace_0_var[154880]));
  void* sid_57_let = (&(global_workspace_0_var[185856]));
  void* sid_58_let = (&(global_workspace_0_var[0]));
  void* sid_78_let = (&(global_workspace_0_var[0]));
  void* sid_61_let = (&(global_workspace_0_var[154880]));
  void* sid_62_let = (&(global_workspace_0_var[0]));
  void* sid_63_let = (&(global_workspace_0_var[154880]));
  void* sid_64_let = (&(global_workspace_0_var[0]));
  void* sid_65_let = (&(global_workspace_0_var[154880]));
  void* sid_66_let = (&(global_workspace_0_var[0]));
  void* sid_68_let = (&(global_workspace_0_var[0]));
  void* sid_69_let = (&(global_workspace_0_var[58080]));
  void* sid_70_let = (&(global_workspace_0_var[0]));
  void* sid_71_let = (&(global_workspace_0_var[29040]));
  void* sid_72_let = (&(global_workspace_0_var[0]));
  void* sid_73_let = (&(global_workspace_0_var[34848]));
  void* sid_74_let = (&(global_workspace_0_var[0]));
  void* sid_75_let = (&(global_workspace_0_var[34848]));
  void* sid_76_let = (&(global_workspace_0_var[0]));
  void* sid_77_let = (&(global_workspace_0_var[17280]));
  void* sid_79_let = (&(global_workspace_0_var[17280]));
  if (tvmgen_default_fused_nn_conv2d(data_buffer_var, conv2d_1_buffer_var, sid_55_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker(sid_55_let, weight_depth_wise_1_buffer_var, conv2d_2_buffer_var, sid_56_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_1(sid_56_let, weight_1x1_conv2d_32_buffer_var, weight_depth_wise_32_buffer_var, weight_1x1_conv2d_linear_32_buffer_var, sid_57_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_1(sid_57_let, weight_1x1_conv2d_33_buffer_var, sid_58_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_2(sid_58_let, weight_depth_wise_33_buffer_var, weight_1x1_conv2d_linear_33_buffer_var, sid_59_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_2(sid_59_let, weight_1x1_conv2d_34_buffer_var, sid_60_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_3(sid_60_let, weight_depth_wise_34_buffer_var, weight_1x1_conv2d_linear_34_buffer_var, sid_61_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_3(sid_61_let, weight_1x1_conv2d_35_buffer_var, sid_62_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_4(sid_62_let, weight_depth_wise_35_buffer_var, weight_1x1_conv2d_linear_35_buffer_var, sid_63_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_4(sid_63_let, weight_1x1_conv2d_36_buffer_var, sid_64_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_5(sid_64_let, weight_depth_wise_36_buffer_var, weight_1x1_conv2d_linear_36_buffer_var, sid_65_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_5(sid_65_let, weight_1x1_conv2d_37_buffer_var, sid_66_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_6(sid_66_let, weight_depth_wise_37_buffer_var, weight_1x1_conv2d_linear_37_buffer_var, weight_1x1_conv2d_38_buffer_var, sid_67_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_7(sid_67_let, weight_depth_wise_38_buffer_var, weight_1x1_conv2d_linear_38_buffer_var, weight_1x1_conv2d_39_buffer_var, sid_68_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_8(sid_68_let, weight_depth_wise_39_buffer_var, weight_1x1_conv2d_linear_39_buffer_var, weight_1x1_conv2d_40_buffer_var, sid_69_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_9(sid_69_let, weight_depth_wise_40_buffer_var, weight_1x1_conv2d_linear_40_buffer_var, weight_1x1_conv2d_41_buffer_var, sid_70_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_10(sid_70_let, weight_depth_wise_41_buffer_var, weight_1x1_conv2d_linear_41_buffer_var, weight_1x1_conv2d_42_buffer_var, sid_71_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_11(sid_71_let, weight_depth_wise_42_buffer_var, weight_1x1_conv2d_linear_42_buffer_var, weight_1x1_conv2d_43_buffer_var, sid_72_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_12(sid_72_let, weight_depth_wise_43_buffer_var, weight_1x1_conv2d_linear_43_buffer_var, weight_1x1_conv2d_44_buffer_var, sid_73_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_13(sid_73_let, weight_depth_wise_44_buffer_var, weight_1x1_conv2d_linear_44_buffer_var, weight_1x1_conv2d_45_buffer_var, sid_74_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_14(sid_74_let, weight_depth_wise_45_buffer_var, weight_1x1_conv2d_linear_45_buffer_var, weight_1x1_conv2d_46_buffer_var, sid_75_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_6(sid_75_let, weight_depth_wise_46_buffer_var, sid_76_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_15(sid_76_let, weight_1x1_conv2d_linear_46_buffer_var, weight_1x1_conv2d_47_buffer_var, sid_77_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_16(sid_77_let, weight_depth_wise_47_buffer_var, weight_1x1_conv2d_linear_47_buffer_var, weight_1x1_conv2d_48_buffer_var, sid_78_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_7(sid_78_let, weight_depth_wise_48_buffer_var, sid_79_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_8(sid_79_let, weight_1x1_conv2d_linear_48_buffer_var, output_buffer_var, global_workspace_0_var) != 0 ) return -1;
  return 0;
}


// tvm target: c -keys=partial_conv,arm_cpu,cpu -mcpu=cortex-m4+nodsp -model=nrf52840
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* fusion_iter_worker, uint8_t* global_workspace_1_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_1(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_3_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_10(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_23_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_11(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* fusion_iter_worker, uint8_t* global_workspace_25_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_2(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_5_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_3(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_7_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_4(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* fusion_iter_worker, uint8_t* global_workspace_9_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_5(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_11_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_6(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* fusion_iter_worker, uint8_t* global_workspace_13_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_7(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_16_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_8(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_18_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_9(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_21_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_15_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_1(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_20_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_2(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_27_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_3(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_28_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_11(int32_t* iterator, int8_t* dummy_input_9, int8_t* weight_1x1_conv2d_20, int8_t* weight_depth_wise_20, int8_t* weight_1x1_conv2d_linear_20, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_6_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_14(int32_t* iterator, int8_t* dummy_input_12, int8_t* weight_1x1_conv2d_21, int8_t* weight_depth_wise_21, int8_t* weight_1x1_conv2d_linear_21, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_8_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_18(int32_t* iterator, int8_t* dummy_input_15, int8_t* weight_1x1_conv2d_22, int8_t* weight_depth_wise_22, int8_t* weight_1x1_conv2d_linear_22, int8_t* weight_1x1_conv2d_23, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_10_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_20(int32_t* iterator, int8_t* dummy_input_19, int8_t* weight_depth_wise_23, int8_t* weight_1x1_conv2d_linear_23, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_12_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_24(int32_t* iterator, int8_t* dummy_input_21, int8_t* weight_1x1_conv2d_24, int8_t* weight_depth_wise_24, int8_t* weight_1x1_conv2d_linear_24, int8_t* weight_1x1_conv2d_25, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_14_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_27(int32_t* iterator, int8_t* dummy_input_26, int8_t* weight_1x1_conv2d_linear_25, int8_t* weight_1x1_conv2d_26, int8_t* conv2d_nchw, uint8_t* global_workspace_17_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_30(int32_t* iterator, int8_t* dummy_input_28, int8_t* weight_depth_wise_26, int8_t* weight_1x1_conv2d_linear_26, int8_t* weight_1x1_conv2d_27, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_19_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_34(int32_t* iterator, int8_t* dummy_input_32, int8_t* weight_1x1_conv2d_linear_27, int8_t* weight_1x1_conv2d_28, int8_t* weight_depth_wise_28, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* DepthwiseConv2d, uint8_t* global_workspace_22_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_37(int32_t* iterator, int8_t* dummy_input_35, int8_t* weight_1x1_conv2d_linear_28, int8_t* weight_1x1_conv2d_29, int8_t* weight_depth_wise_29, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* DepthwiseConv2d, uint8_t* global_workspace_24_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_42(int32_t* iterator, int8_t* dummy_input_38, int8_t* weight_1x1_conv2d_linear_29, int8_t* weight_1x1_conv2d_30, int8_t* weight_depth_wise_30, int8_t* weight_1x1_conv2d_linear_30, int8_t* weight_1x1_conv2d_31, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_26_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_5(int32_t* iterator, int8_t* dummy_input_0, int8_t* conv2d_1, int8_t* weight_depth_wise_1, int8_t* conv2d_2, int8_t* weight_1x1_conv2d_18, int8_t* weight_depth_wise_18, int8_t* weight_1x1_conv2d_linear_18, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* cache_buffer_var_2, int32_t* cache_cur_idx_2, int8_t* conv2d_nchw, uint8_t* global_workspace_2_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_8(int32_t* iterator, int8_t* dummy_input_6, int8_t* weight_1x1_conv2d_19, int8_t* weight_depth_wise_19, int8_t* weight_1x1_conv2d_linear_19, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_4_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(int8_t* data_buffer_var, int8_t* conv2d_1_buffer_var, int8_t* weight_depth_wise_1_buffer_var, int8_t* conv2d_2_buffer_var, int8_t* weight_1x1_conv2d_18_buffer_var, int8_t* weight_depth_wise_18_buffer_var, int8_t* weight_1x1_conv2d_linear_18_buffer_var, int8_t* weight_1x1_conv2d_19_buffer_var, int8_t* weight_depth_wise_19_buffer_var, int8_t* weight_1x1_conv2d_linear_19_buffer_var, int8_t* weight_1x1_conv2d_20_buffer_var, int8_t* weight_depth_wise_20_buffer_var, int8_t* weight_1x1_conv2d_linear_20_buffer_var, int8_t* weight_1x1_conv2d_21_buffer_var, int8_t* weight_depth_wise_21_buffer_var, int8_t* weight_1x1_conv2d_linear_21_buffer_var, int8_t* weight_1x1_conv2d_22_buffer_var, int8_t* weight_depth_wise_22_buffer_var, int8_t* weight_1x1_conv2d_linear_22_buffer_var, int8_t* weight_1x1_conv2d_23_buffer_var, int8_t* weight_depth_wise_23_buffer_var, int8_t* weight_1x1_conv2d_linear_23_buffer_var, int8_t* weight_1x1_conv2d_24_buffer_var, int8_t* weight_depth_wise_24_buffer_var, int8_t* weight_1x1_conv2d_linear_24_buffer_var, int8_t* weight_1x1_conv2d_25_buffer_var, int8_t* weight_depth_wise_25_buffer_var, int8_t* weight_1x1_conv2d_linear_25_buffer_var, int8_t* weight_1x1_conv2d_26_buffer_var, int8_t* weight_depth_wise_26_buffer_var, int8_t* weight_1x1_conv2d_linear_26_buffer_var, int8_t* weight_1x1_conv2d_27_buffer_var, int8_t* weight_depth_wise_27_buffer_var, int8_t* weight_1x1_conv2d_linear_27_buffer_var, int8_t* weight_1x1_conv2d_28_buffer_var, int8_t* weight_depth_wise_28_buffer_var, int8_t* weight_1x1_conv2d_linear_28_buffer_var, int8_t* weight_1x1_conv2d_29_buffer_var, int8_t* weight_depth_wise_29_buffer_var, int8_t* weight_1x1_conv2d_linear_29_buffer_var, int8_t* weight_1x1_conv2d_30_buffer_var, int8_t* weight_depth_wise_30_buffer_var, int8_t* weight_1x1_conv2d_linear_30_buffer_var, int8_t* weight_1x1_conv2d_31_buffer_var, int8_t* weight_depth_wise_31_buffer_var, int8_t* weight_1x1_conv2d_linear_31_buffer_var, int8_t* output_buffer_var, uint8_t* global_workspace_0_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* fusion_iter_worker, uint8_t* global_workspace_1_var) {
  void* iterator_let = (&(global_workspace_1_var[7748]));
  void* iteratee_output_let = (&(global_workspace_1_var[7764]));
  void* bg_ind_let = (&(global_workspace_1_var[7828]));
  void* cache_buffer_var_let = (&(global_workspace_1_var[7648]));
  void* cache_cur_idx_let = (&(global_workspace_1_var[7812]));
  void* cache_buffer_var_let_1 = (&(global_workspace_1_var[7264]));
  void* cache_cur_idx_let_1 = (&(global_workspace_1_var[7796]));
  void* cache_buffer_var_let_2 = (&(global_workspace_1_var[6832]));
  void* cache_cur_idx_let_2 = (&(global_workspace_1_var[7780]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_1)[0] = 0;
  ((int32_t*)cache_cur_idx_let_1)[1] = 0;
  ((int32_t*)cache_cur_idx_let_1)[2] = 0;
  ((int32_t*)cache_cur_idx_let_1)[3] = 0;
  ((int8_t*)cache_buffer_var_let_2)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_2)[0] = 0;
  ((int32_t*)cache_cur_idx_let_2)[1] = 0;
  ((int32_t*)cache_cur_idx_let_2)[2] = 0;
  ((int32_t*)cache_cur_idx_let_2)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 19))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 19))) { break; }
      if (tvmgen_default_iteratee_5(iterator_let, p0, p1, p2, p3, p4, p5, p6, cache_buffer_var_let, cache_cur_idx_let, cache_buffer_var_let_1, cache_cur_idx_let_1, cache_buffer_var_let_2, cache_cur_idx_let_2, iteratee_output_let, global_workspace_1_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 16; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 6400) + (i * 400)) + (((int32_t*)bg_ind_let)[1] * 400)) + (((int32_t*)bg_ind_let)[2] * 20)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 19) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 4);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_1)[0] = 0;
    ((int32_t*)cache_cur_idx_let_1)[1] = 0;
    ((int32_t*)cache_cur_idx_let_1)[2] = 0;
    ((int32_t*)cache_cur_idx_let_1)[3] = 0;
    ((int8_t*)cache_buffer_var_let_2)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_2)[0] = 0;
    ((int32_t*)cache_cur_idx_let_2)[1] = 0;
    ((int32_t*)cache_cur_idx_let_2)[2] = 0;
    ((int32_t*)cache_cur_idx_let_2)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 4);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_1(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_3_var) {
  void* iterator_let = (&(global_workspace_3_var[13664]));
  void* iteratee_output_let = (&(global_workspace_3_var[13680]));
  void* bg_ind_let = (&(global_workspace_3_var[13712]));
  void* cache_buffer_var_let = (&(global_workspace_3_var[13232]));
  void* cache_cur_idx_let = (&(global_workspace_3_var[13696]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 19))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 19))) { break; }
      if (tvmgen_default_iteratee_8(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_3_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 16; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 6400) + (i * 400)) + (((int32_t*)bg_ind_let)[1] * 400)) + (((int32_t*)bg_ind_let)[2] * 20)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 19) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_10(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_23_var) {
  void* iterator_let = (&(global_workspace_23_var[14880]));
  void* iteratee_output_let = (&(global_workspace_23_var[14400]));
  void* bg_ind_let = (&(global_workspace_23_var[14912]));
  void* cache_buffer_var_let = (&(global_workspace_23_var[4320]));
  void* cache_cur_idx_let = (&(global_workspace_23_var[14896]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 2))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 2))) { break; }
      if (tvmgen_default_iteratee_37(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_23_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 480; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 4320) + (i * 9)) + (((int32_t*)bg_ind_let)[1] * 9)) + (((int32_t*)bg_ind_let)[2] * 3)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 2) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_11(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* fusion_iter_worker, uint8_t* global_workspace_25_var) {
  void* iterator_let = (&(global_workspace_25_var[12096]));
  void* iteratee_output_let = (&(global_workspace_25_var[11808]));
  void* bg_ind_let = (&(global_workspace_25_var[12128]));
  void* cache_buffer_var_let = (&(global_workspace_25_var[4320]));
  void* cache_cur_idx_let = (&(global_workspace_25_var[12112]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 2))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 2))) { break; }
      if (tvmgen_default_iteratee_42(iterator_let, p0, p1, p2, p3, p4, p5, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_25_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 288; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 2592) + (i * 9)) + (((int32_t*)bg_ind_let)[1] * 9)) + (((int32_t*)bg_ind_let)[2] * 3)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 2) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_2(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_5_var) {
  void* iterator_let = (&(global_workspace_5_var[13664]));
  void* iteratee_output_let = (&(global_workspace_5_var[13680]));
  void* bg_ind_let = (&(global_workspace_5_var[13712]));
  void* cache_buffer_var_let = (&(global_workspace_5_var[13232]));
  void* cache_cur_idx_let = (&(global_workspace_5_var[13696]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 19))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 19))) { break; }
      if (tvmgen_default_iteratee_11(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_5_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 16; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 6400) + (i * 400)) + (((int32_t*)bg_ind_let)[1] * 400)) + (((int32_t*)bg_ind_let)[2] * 20)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 19) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_3(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_7_var) {
  void* iterator_let = (&(global_workspace_7_var[8888]));
  void* iteratee_output_let = (&(global_workspace_7_var[8864]));
  void* bg_ind_let = (&(global_workspace_7_var[8920]));
  void* cache_buffer_var_let = (&(global_workspace_7_var[6400]));
  void* cache_cur_idx_let = (&(global_workspace_7_var[8904]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 9))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 9))) { break; }
      if (tvmgen_default_iteratee_14(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_7_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 24; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 2400) + (i * 100)) + (((int32_t*)bg_ind_let)[1] * 100)) + (((int32_t*)bg_ind_let)[2] * 10)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 9) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_4(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* fusion_iter_worker, uint8_t* global_workspace_9_var) {
  void* iterator_let = (&(global_workspace_9_var[15888]));
  void* iteratee_output_let = (&(global_workspace_9_var[15696]));
  void* bg_ind_let = (&(global_workspace_9_var[15920]));
  void* cache_buffer_var_let = (&(global_workspace_9_var[14400]));
  void* cache_cur_idx_let = (&(global_workspace_9_var[15904]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 9))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 9))) { break; }
      if (tvmgen_default_iteratee_18(iterator_let, p0, p1, p2, p3, p4, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_9_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 120; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 12000) + (i * 100)) + (((int32_t*)bg_ind_let)[1] * 100)) + (((int32_t*)bg_ind_let)[2] * 10)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 9) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_5(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_11_var) {
  void* iterator_let = (&(global_workspace_11_var[18024]));
  void* iteratee_output_let = (&(global_workspace_11_var[15600]));
  void* bg_ind_let = (&(global_workspace_11_var[18056]));
  void* cache_buffer_var_let = (&(global_workspace_11_var[12000]));
  void* cache_cur_idx_let = (&(global_workspace_11_var[18040]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 9))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 9))) { break; }
      if (tvmgen_default_iteratee_20(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_11_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 24; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 2400) + (i * 100)) + (((int32_t*)bg_ind_let)[1] * 100)) + (((int32_t*)bg_ind_let)[2] * 10)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 9) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_6(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* fusion_iter_worker, uint8_t* global_workspace_13_var) {
  void* iterator_let = (&(global_workspace_13_var[13056]));
  void* iteratee_output_let = (&(global_workspace_13_var[20128]));
  void* bg_ind_let = (&(global_workspace_13_var[20552]));
  void* cache_buffer_var_let = (&(global_workspace_13_var[0]));
  void* cache_cur_idx_let = (&(global_workspace_13_var[20536]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 4))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 4))) { break; }
      if (tvmgen_default_iteratee_24(iterator_let, p0, p1, p2, p3, p4, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_13_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 240; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 6000) + (i * 25)) + (((int32_t*)bg_ind_let)[1] * 25)) + (((int32_t*)bg_ind_let)[2] * 5)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 4) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_7(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_16_var) {
  void* iterator_let = (&(global_workspace_16_var[6520]));
  void* iteratee_output_let = (&(global_workspace_16_var[6000]));
  void* bg_ind_let = (&(global_workspace_16_var[6536]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 4))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 4))) { break; }
      if (tvmgen_default_iteratee_27(iterator_let, p0, p1, p2, iteratee_output_let, global_workspace_16_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 240; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 6000) + (i * 25)) + (((int32_t*)bg_ind_let)[1] * 25)) + (((int32_t*)bg_ind_let)[2] * 5)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 4) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_8(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_18_var) {
  void* iterator_let = (&(global_workspace_18_var[13872]));
  void* iteratee_output_let = (&(global_workspace_18_var[13680]));
  void* bg_ind_let = (&(global_workspace_18_var[13904]));
  void* cache_buffer_var_let = (&(global_workspace_18_var[10800]));
  void* cache_cur_idx_let = (&(global_workspace_18_var[13888]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 4))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 4))) { break; }
      if (tvmgen_default_iteratee_30(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_18_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 192; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 4800) + (i * 25)) + (((int32_t*)bg_ind_let)[1] * 25)) + (((int32_t*)bg_ind_let)[2] * 5)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 4) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_9(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_21_var) {
  void* iterator_let = (&(global_workspace_21_var[18000]));
  void* iteratee_output_let = (&(global_workspace_21_var[17760]));
  void* bg_ind_let = (&(global_workspace_21_var[18032]));
  void* cache_buffer_var_let = (&(global_workspace_21_var[0]));
  void* cache_cur_idx_let = (&(global_workspace_21_var[18016]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 2))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 2))) { break; }
      if (tvmgen_default_iteratee_34(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_21_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 240; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 2160) + (i * 9)) + (((int32_t*)bg_ind_let)[1] * 9)) + (((int32_t*)bg_ind_let)[2] * 3)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 2) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_15_var) {
  for (int32_t c = 0; c < 240; ++c) {
    for (int32_t i = 0; i < 5; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        DepthwiseConv2d[(((c * 25) + (i * 5)) + j)] = (int8_t)0;
        for (int32_t di = 0; di < 7; ++di) {
          for (int32_t dj = 0; dj < 7; ++dj) {
            int32_t cse_var_2 = (c * 25);
            int32_t cse_var_1 = ((cse_var_2 + (i * 5)) + j);
            DepthwiseConv2d[cse_var_1] = (DepthwiseConv2d[cse_var_1] + (p0[((cse_var_2 + (((i + di) % 5) * 5)) + ((j + dj) % 5))] * p1[(((c * 49) + (di * 7)) + dj)]));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_1(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_20_var) {
  for (int32_t c = 0; c < 192; ++c) {
    for (int32_t i = 0; i < 5; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        DepthwiseConv2d[(((c * 25) + (i * 5)) + j)] = (int8_t)0;
        for (int32_t di = 0; di < 3; ++di) {
          for (int32_t dj = 0; dj < 3; ++dj) {
            int32_t cse_var_2 = (c * 25);
            int32_t cse_var_1 = ((cse_var_2 + (i * 5)) + j);
            DepthwiseConv2d[cse_var_1] = (DepthwiseConv2d[cse_var_1] + (p0[((cse_var_2 + (((i + di) % 5) * 5)) + ((j + dj) % 5))] * p1[(((c * 9) + (di * 3)) + dj)]));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_2(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_27_var) {
  for (int32_t c = 0; c < 288; ++c) {
    for (int32_t i = 0; i < 3; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        DepthwiseConv2d[(((c * 9) + (i * 3)) + j)] = (int8_t)0;
        for (int32_t di = 0; di < 7; ++di) {
          for (int32_t dj = 0; dj < 7; ++dj) {
            int32_t cse_var_2 = (c * 9);
            int32_t cse_var_1 = ((cse_var_2 + (i * 3)) + j);
            DepthwiseConv2d[cse_var_1] = (DepthwiseConv2d[cse_var_1] + (p0[((cse_var_2 + (((i + di) % 3) * 3)) + ((j + dj) % 3))] * p1[(((c * 49) + (di * 7)) + dj)]));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_3(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_28_var) {
  for (int32_t ff = 0; ff < 160; ++ff) {
    for (int32_t yy = 0; yy < 3; ++yy) {
      for (int32_t xx = 0; xx < 3; ++xx) {
        conv2d_nchw[(((ff * 9) + (yy * 3)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 288; ++rc) {
          int32_t cse_var_2 = (yy * 3);
          int32_t cse_var_1 = (((ff * 9) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 9) + cse_var_2) + xx)] * p1[((ff * 288) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_11(int32_t* iterator, int8_t* dummy_input_9, int8_t* weight_1x1_conv2d_20, int8_t* weight_depth_wise_20, int8_t* weight_1x1_conv2d_linear_20, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_6_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_6_var[12800]));
  void* conv2d_nchw_let = (&(global_workspace_6_var[6400]));
  for (int32_t i1 = 0; i1 < 16; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_9[((((((iterator[0] * 6400) + (i1 * 400)) + (iterator[1] * 400)) + (i2 * 20)) + (iterator[2] * 20)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    for (int32_t yy = 0; yy < 3; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 3) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 16; ++rc) {
        int32_t cse_var_1 = ((ff * 3) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 3) + yy)] * weight_1x1_conv2d_20[((ff * 16) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 48; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)conv2d_nchw_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 48; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 48; ++c) {
    ((int8_t*)conv2d_nchw_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_3 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)conv2d_nchw_let)[c] = (((int8_t*)conv2d_nchw_let)[c] + (((int8_t*)dyn_slice_fixed_size_let)[cse_var_3] * weight_depth_wise_20[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 16; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 48; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_linear_20[((ff_1 * 48) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_14(int32_t* iterator, int8_t* dummy_input_12, int8_t* weight_1x1_conv2d_21, int8_t* weight_depth_wise_21, int8_t* weight_1x1_conv2d_linear_21, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_8_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_8_var[8752]));
  void* conv2d_nchw_let = (&(global_workspace_8_var[0]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_8_var[0]));
  for (int32_t i1 = 0; i1 < 16; ++i1) {
    for (int32_t i2 = 0; i2 < 7; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 7) + i2)] = dummy_input_12[((((((iterator[0] * 6400) + (i1 * 400)) + (iterator[1] * 400)) + (i2 * 20)) + (iterator[2] * 20)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    for (int32_t yy = 0; yy < 7; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 7) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 16; ++rc) {
        int32_t cse_var_1 = ((ff * 7) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 7) + yy)] * weight_1x1_conv2d_21[((ff * 16) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 48; ++i) {
      for (int32_t j = 0; j < 7; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 49) + (j * 7)) + ((cache_cur_idx[3] % 6) + (6 & ((cache_cur_idx[3] % 6) >> 31))))] = ((int8_t*)conv2d_nchw_let)[((i * 7) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((6 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 48; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 7; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 7; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 49) + (j_2 * 7)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 48; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 7; ++di) {
      for (int32_t dj = 0; dj < 7; ++dj) {
        int32_t cse_var_3 = (((c * 49) + (di * 7)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_3] * weight_depth_wise_21[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 24; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 48; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)dyn_slice_fixed_size_let)[rc_1] * weight_1x1_conv2d_linear_21[((ff_1 * 48) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_18(int32_t* iterator, int8_t* dummy_input_15, int8_t* weight_1x1_conv2d_22, int8_t* weight_depth_wise_22, int8_t* weight_1x1_conv2d_linear_22, int8_t* weight_1x1_conv2d_23, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_10_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_10_var[15816]));
  void* conv2d_nchw_let = (&(global_workspace_10_var[13296]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_10_var[12000]));
  for (int32_t i1 = 0; i1 < 24; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_15[((((((iterator[0] * 2400) + (i1 * 100)) + (iterator[1] * 100)) + (i2 * 10)) + (iterator[2] * 10)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 144; ++ff) {
    for (int32_t yy = 0; yy < 3; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 3) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 24; ++rc) {
        int32_t cse_var_1 = ((ff * 3) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 3) + yy)] * weight_1x1_conv2d_22[((ff * 24) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 144; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)conv2d_nchw_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 144; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 144; ++c) {
    ((int8_t*)conv2d_nchw_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_3 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)conv2d_nchw_let)[c] = (((int8_t*)conv2d_nchw_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_3] * weight_depth_wise_22[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 24; ++ff_1) {
    ((int8_t*)dyn_slice_fixed_size_let)[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 144; ++rc_1) {
      ((int8_t*)dyn_slice_fixed_size_let)[ff_1] = (((int8_t*)dyn_slice_fixed_size_let)[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_linear_22[((ff_1 * 144) + rc_1)]));
    }
  }
  for (int32_t ff_2 = 0; ff_2 < 120; ++ff_2) {
    conv2d_nchw[ff_2] = (int8_t)0;
    for (int32_t rc_2 = 0; rc_2 < 24; ++rc_2) {
      conv2d_nchw[ff_2] = (conv2d_nchw[ff_2] + (((int8_t*)dyn_slice_fixed_size_let)[rc_2] * weight_1x1_conv2d_23[((ff_2 * 24) + rc_2)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_20(int32_t* iterator, int8_t* dummy_input_19, int8_t* weight_depth_wise_23, int8_t* weight_1x1_conv2d_linear_23, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_12_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_12_var[15000]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_12_var[0]));
  for (int32_t i1 = 0; i1 < 120; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_19[((((((iterator[0] * 12000) + (i1 * 100)) + (iterator[1] * 100)) + (i2 * 10)) + (iterator[2] * 10)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 120; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 120; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 120; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_2 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_23[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 24; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 120; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_23[((ff * 120) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_24(int32_t* iterator, int8_t* dummy_input_21, int8_t* weight_1x1_conv2d_24, int8_t* weight_depth_wise_24, int8_t* weight_1x1_conv2d_linear_24, int8_t* weight_1x1_conv2d_25, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_14_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_14_var[20368]));
  void* conv2d_nchw_let = (&(global_workspace_14_var[13072]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_14_var[13072]));
  void* conv2d_nchw_let_1 = (&(global_workspace_14_var[13072]));
  for (int32_t i1 = 0; i1 < 24; ++i1) {
    for (int32_t i2 = 0; i2 < 7; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 7) + i2)] = dummy_input_21[((((((iterator[0] * 2400) + (i1 * 100)) + (iterator[1] * 100)) + (i2 * 10)) + (iterator[2] * 10)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 144; ++ff) {
    for (int32_t yy = 0; yy < 7; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 7) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 24; ++rc) {
        int32_t cse_var_1 = ((ff * 7) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 7) + yy)] * weight_1x1_conv2d_24[((ff * 24) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 144; ++i) {
      for (int32_t j = 0; j < 7; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 49) + (j * 7)) + ((cache_cur_idx[3] % 6) + (6 & ((cache_cur_idx[3] % 6) >> 31))))] = ((int8_t*)conv2d_nchw_let)[((i * 7) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((6 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 144; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 7; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 7; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 49) + (j_2 * 7)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 144; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 7; ++di) {
      for (int32_t dj = 0; dj < 7; ++dj) {
        int32_t cse_var_3 = (((c * 49) + (di * 7)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_3] * weight_depth_wise_24[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 40; ++ff_1) {
    ((int8_t*)conv2d_nchw_let_1)[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 144; ++rc_1) {
      ((int8_t*)conv2d_nchw_let_1)[ff_1] = (((int8_t*)conv2d_nchw_let_1)[ff_1] + (((int8_t*)dyn_slice_fixed_size_let)[rc_1] * weight_1x1_conv2d_linear_24[((ff_1 * 144) + rc_1)]));
    }
  }
  for (int32_t ff_2 = 0; ff_2 < 240; ++ff_2) {
    conv2d_nchw[ff_2] = (int8_t)0;
    for (int32_t rc_2 = 0; rc_2 < 40; ++rc_2) {
      conv2d_nchw[ff_2] = (conv2d_nchw[ff_2] + (((int8_t*)conv2d_nchw_let_1)[rc_2] * weight_1x1_conv2d_25[((ff_2 * 40) + rc_2)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_27(int32_t* iterator, int8_t* dummy_input_26, int8_t* weight_1x1_conv2d_linear_25, int8_t* weight_1x1_conv2d_26, int8_t* conv2d_nchw, uint8_t* global_workspace_17_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_17_var[6240]));
  void* conv2d_nchw_let = (&(global_workspace_17_var[6480]));
  for (int32_t i1 = 0; i1 < 240; ++i1) {
    ((int8_t*)dyn_slice_fixed_size_let)[i1] = dummy_input_26[(((((iterator[0] * 6000) + (i1 * 25)) + (iterator[1] * 25)) + (iterator[2] * 5)) + iterator[3])];
  }
  for (int32_t ff = 0; ff < 40; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 240; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_25[((ff * 240) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 240; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 40; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_26[((ff_1 * 40) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_30(int32_t* iterator, int8_t* dummy_input_28, int8_t* weight_depth_wise_26, int8_t* weight_1x1_conv2d_linear_26, int8_t* weight_1x1_conv2d_27, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_19_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_19_var[12960]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_19_var[0]));
  void* conv2d_nchw_let = (&(global_workspace_19_var[0]));
  for (int32_t i1 = 0; i1 < 240; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_28[((((((iterator[0] * 6000) + (i1 * 25)) + (iterator[1] * 25)) + (i2 * 5)) + (iterator[2] * 5)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 240; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 240; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 240; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_26[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 240; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_26[((ff * 240) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 192; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 48; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_27[((ff_1 * 48) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_34(int32_t* iterator, int8_t* dummy_input_32, int8_t* weight_1x1_conv2d_linear_27, int8_t* weight_1x1_conv2d_28, int8_t* weight_depth_wise_28, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* DepthwiseConv2d, uint8_t* global_workspace_22_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_22_var[6000]));
  void* conv2d_nchw_let = (&(global_workspace_22_var[7200]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_22_var[6000]));
  for (int32_t i1 = 0; i1 < 192; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_32[((((((iterator[0] * 4800) + (i1 * 25)) + (iterator[1] * 25)) + (i2 * 5)) + (iterator[2] * 5)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    for (int32_t yy = 0; yy < 5; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 5) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 192; ++rc) {
        int32_t cse_var_1 = ((ff * 5) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 5) + yy)] * weight_1x1_conv2d_linear_27[((ff * 192) + rc)]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 240; ++ff_1) {
    for (int32_t yy_1 = 0; yy_1 < 5; ++yy_1) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_1 * 5) + yy_1)] = (int8_t)0;
      for (int32_t rc_1 = 0; rc_1 < 48; ++rc_1) {
        int32_t cse_var_2 = ((ff_1 * 5) + yy_1);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] + (((int8_t*)conv2d_nchw_let)[((rc_1 * 5) + yy_1)] * weight_1x1_conv2d_28[((ff_1 * 48) + rc_1)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 240; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((4 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 240; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_3 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_3] = cache_buffer_var[cse_var_3];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 240; ++c) {
    DepthwiseConv2d[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_4 = (((c * 25) + (di * 5)) + dj);
        DepthwiseConv2d[c] = (DepthwiseConv2d[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_4] * weight_depth_wise_28[cse_var_4]));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_37(int32_t* iterator, int8_t* dummy_input_35, int8_t* weight_1x1_conv2d_linear_28, int8_t* weight_1x1_conv2d_29, int8_t* weight_depth_wise_29, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* DepthwiseConv2d, uint8_t* global_workspace_24_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_24_var[12960]));
  void* conv2d_nchw_let = (&(global_workspace_24_var[8640]));
  for (int32_t i1 = 0; i1 < 240; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_35[((((((iterator[0] * 2160) + (i1 * 9)) + (iterator[1] * 9)) + (i2 * 3)) + (iterator[2] * 3)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 96; ++ff) {
    for (int32_t yy = 0; yy < 3; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 3) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 240; ++rc) {
        int32_t cse_var_1 = ((ff * 3) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 3) + yy)] * weight_1x1_conv2d_linear_28[((ff * 240) + rc)]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 480; ++ff_1) {
    for (int32_t yy_1 = 0; yy_1 < 3; ++yy_1) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_1 * 3) + yy_1)] = (int8_t)0;
      for (int32_t rc_1 = 0; rc_1 < 96; ++rc_1) {
        int32_t cse_var_2 = ((ff_1 * 3) + yy_1);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] + (((int8_t*)conv2d_nchw_let)[((rc_1 * 3) + yy_1)] * weight_1x1_conv2d_29[((ff_1 * 96) + rc_1)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 480; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 480; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_3 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)conv2d_nchw_let)[cse_var_3] = cache_buffer_var[cse_var_3];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 480; ++c) {
    DepthwiseConv2d[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_4 = (((c * 9) + (di * 3)) + dj);
        DepthwiseConv2d[c] = (DepthwiseConv2d[c] + (((int8_t*)conv2d_nchw_let)[cse_var_4] * weight_depth_wise_29[cse_var_4]));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_42(int32_t* iterator, int8_t* dummy_input_38, int8_t* weight_1x1_conv2d_linear_29, int8_t* weight_1x1_conv2d_30, int8_t* weight_depth_wise_30, int8_t* weight_1x1_conv2d_linear_30, int8_t* weight_1x1_conv2d_31, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_26_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_26_var[10368]));
  void* conv2d_nchw_let = (&(global_workspace_26_var[0]));
  void* conv2d_nchw_let_1 = (&(global_workspace_26_var[0]));
  for (int32_t i1 = 0; i1 < 480; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_38[((((((iterator[0] * 4320) + (i1 * 9)) + (iterator[1] * 9)) + (i2 * 3)) + (iterator[2] * 3)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 96; ++ff) {
    for (int32_t yy = 0; yy < 3; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 3) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 480; ++rc) {
        int32_t cse_var_1 = ((ff * 3) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 3) + yy)] * weight_1x1_conv2d_linear_29[((ff * 480) + rc)]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 384; ++ff_1) {
    for (int32_t yy_1 = 0; yy_1 < 3; ++yy_1) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_1 * 3) + yy_1)] = (int8_t)0;
      for (int32_t rc_1 = 0; rc_1 < 96; ++rc_1) {
        int32_t cse_var_2 = ((ff_1 * 3) + yy_1);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] + (((int8_t*)conv2d_nchw_let)[((rc_1 * 3) + yy_1)] * weight_1x1_conv2d_30[((ff_1 * 96) + rc_1)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 384; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 384; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_3 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)conv2d_nchw_let)[cse_var_3] = cache_buffer_var[cse_var_3];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 384; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_4 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)conv2d_nchw_let)[cse_var_4] * weight_depth_wise_30[cse_var_4]));
      }
    }
  }
  for (int32_t ff_2 = 0; ff_2 < 96; ++ff_2) {
    ((int8_t*)conv2d_nchw_let_1)[ff_2] = (int8_t)0;
    for (int32_t rc_2 = 0; rc_2 < 384; ++rc_2) {
      ((int8_t*)conv2d_nchw_let_1)[ff_2] = (((int8_t*)conv2d_nchw_let_1)[ff_2] + (((int8_t*)dyn_slice_fixed_size_let)[rc_2] * weight_1x1_conv2d_linear_30[((ff_2 * 384) + rc_2)]));
    }
  }
  for (int32_t ff_3 = 0; ff_3 < 288; ++ff_3) {
    conv2d_nchw[ff_3] = (int8_t)0;
    for (int32_t rc_3 = 0; rc_3 < 96; ++rc_3) {
      conv2d_nchw[ff_3] = (conv2d_nchw[ff_3] + (((int8_t*)conv2d_nchw_let_1)[rc_3] * weight_1x1_conv2d_31[((ff_3 * 96) + rc_3)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_5(int32_t* iterator, int8_t* dummy_input_0, int8_t* conv2d_1, int8_t* weight_depth_wise_1, int8_t* conv2d_2, int8_t* weight_1x1_conv2d_18, int8_t* weight_depth_wise_18, int8_t* weight_1x1_conv2d_linear_18, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* cache_buffer_var_2, int32_t* cache_cur_idx_2, int8_t* conv2d_nchw, uint8_t* global_workspace_2_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_2_var[7504]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_2_var[6400]));
  for (int32_t i1 = 0; i1 < 3; ++i1) {
    for (int32_t i2 = 0; i2 < 11; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 11) + i2)] = dummy_input_0[((((((iterator[0] * 19200) + (i1 * 6400)) + (iterator[1] * 6400)) + (i2 * 80)) + (iterator[2] * 80)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 3; ++i) {
      for (int32_t j = 0; j < 11; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 33) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 11) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((2 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 3; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 11; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 33) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t ff = 0; ff < 16; ++ff) {
    for (int32_t yy = 0; yy < 5; ++yy) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff * 5) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 3; ++rc) {
        for (int32_t ry = 0; ry < 3; ++ry) {
          for (int32_t rx = 0; rx < 3; ++rx) {
            int32_t cse_var_3 = (ry * 3);
            int32_t cse_var_2 = ((ff * 5) + yy);
            ((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] + (((int8_t*)cache_conv_input_compute_generic_let)[((((rc * 33) + (yy * 6)) + cse_var_3) + rx)] * conv2d_1[((((ff * 27) + (rc * 9)) + cse_var_3) + rx)]));
          }
        }
      }
    }
  }
  for (int32_t n_2 = 0; n_2 < 1; ++n_2) {
    for (int32_t i_1 = 0; i_1 < 16; ++i_1) {
      for (int32_t j_3 = 0; j_3 < 5; ++j_3) {
        for (int32_t k_2 = 0; k_2 < 1; ++k_2) {
          cache_buffer_var_1[(((i_1 * 15) + (j_3 * 3)) + (cache_cur_idx_1[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i_1 * 5) + j_3)];
        }
      }
    }
  }
  cache_cur_idx_1[3] = (cache_cur_idx_1[3] + 1);
  if (2 <= cache_cur_idx_1[3]) {
    for (int32_t n_3 = 0; n_3 < 1; ++n_3) {
      for (int32_t j_4 = 0; j_4 < 16; ++j_4) {
        for (int32_t j_5 = 0; j_5 < 5; ++j_5) {
          for (int32_t k_3 = 0; k_3 < 3; ++k_3) {
            int32_t cse_var_4 = (((j_4 * 15) + (j_5 * 3)) + k_3);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_4] = cache_buffer_var_1[cse_var_4];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 16; ++c) {
    for (int32_t i_2 = 0; i_2 < 3; ++i_2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((c * 3) + i_2)] = (int8_t)0;
      for (int32_t di = 0; di < 3; ++di) {
        for (int32_t dj = 0; dj < 3; ++dj) {
          int32_t cse_var_6 = (di * 3);
          int32_t cse_var_5 = ((c * 3) + i_2);
          ((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] + (((int8_t*)cache_conv_input_compute_generic_let)[((((c * 15) + (i_2 * 3)) + cse_var_6) + dj)] * weight_depth_wise_1[(((c * 9) + cse_var_6) + dj)]));
        }
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 8; ++ff_1) {
    for (int32_t yy_1 = 0; yy_1 < 3; ++yy_1) {
      ((int8_t*)cache_conv_input_compute_generic_let)[((ff_1 * 3) + yy_1)] = (int8_t)0;
      for (int32_t rc_1 = 0; rc_1 < 16; ++rc_1) {
        int32_t cse_var_7 = ((ff_1 * 3) + yy_1);
        ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_7] = (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_7] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_1 * 3) + yy_1)] * conv2d_2[((ff_1 * 16) + rc_1)]));
      }
    }
  }
  for (int32_t ff_2 = 0; ff_2 < 48; ++ff_2) {
    for (int32_t yy_2 = 0; yy_2 < 3; ++yy_2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_2 * 3) + yy_2)] = (int8_t)0;
      for (int32_t rc_2 = 0; rc_2 < 8; ++rc_2) {
        int32_t cse_var_8 = ((ff_2 * 3) + yy_2);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_8] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_8] + (((int8_t*)cache_conv_input_compute_generic_let)[((rc_2 * 3) + yy_2)] * weight_1x1_conv2d_18[((ff_2 * 8) + rc_2)]));
      }
    }
  }
  for (int32_t n_4 = 0; n_4 < 1; ++n_4) {
    for (int32_t i_3 = 0; i_3 < 48; ++i_3) {
      for (int32_t j_6 = 0; j_6 < 3; ++j_6) {
        for (int32_t k_4 = 0; k_4 < 1; ++k_4) {
          cache_buffer_var_2[(((i_3 * 9) + (j_6 * 3)) + (cache_cur_idx_2[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i_3 * 3) + j_6)];
        }
      }
    }
  }
  cache_cur_idx_2[3] = (cache_cur_idx_2[3] + 1);
  if ((2 <= cache_cur_idx_2[3]) && ((cache_cur_idx_2[3] % 2) == 0)) {
    for (int32_t n_5 = 0; n_5 < 1; ++n_5) {
      for (int32_t j_7 = 0; j_7 < 48; ++j_7) {
        for (int32_t j_8 = 0; j_8 < 3; ++j_8) {
          for (int32_t k_5 = 0; k_5 < 3; ++k_5) {
            int32_t cse_var_9 = (((j_7 * 9) + (j_8 * 3)) + k_5);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_9] = cache_buffer_var_2[cse_var_9];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_1 = 0; c_1 < 48; ++c_1) {
    ((int8_t*)dyn_slice_fixed_size_let)[c_1] = (int8_t)0;
    for (int32_t di_1 = 0; di_1 < 3; ++di_1) {
      for (int32_t dj_1 = 0; dj_1 < 3; ++dj_1) {
        int32_t cse_var_10 = (((c_1 * 9) + (di_1 * 3)) + dj_1);
        ((int8_t*)dyn_slice_fixed_size_let)[c_1] = (((int8_t*)dyn_slice_fixed_size_let)[c_1] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_10] * weight_depth_wise_18[cse_var_10]));
      }
    }
  }
  for (int32_t ff_3 = 0; ff_3 < 16; ++ff_3) {
    conv2d_nchw[ff_3] = (int8_t)0;
    for (int32_t rc_3 = 0; rc_3 < 48; ++rc_3) {
      conv2d_nchw[ff_3] = (conv2d_nchw[ff_3] + (((int8_t*)dyn_slice_fixed_size_let)[rc_3] * weight_1x1_conv2d_linear_18[((ff_3 * 48) + rc_3)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_8(int32_t* iterator, int8_t* dummy_input_6, int8_t* weight_1x1_conv2d_19, int8_t* weight_depth_wise_19, int8_t* weight_1x1_conv2d_linear_19, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_4_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_4_var[12800]));
  void* conv2d_nchw_let = (&(global_workspace_4_var[0]));
  for (int32_t i1 = 0; i1 < 16; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_6[((((((iterator[0] * 6400) + (i1 * 400)) + (iterator[1] * 400)) + (i2 * 20)) + (iterator[2] * 20)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    for (int32_t yy = 0; yy < 3; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 3) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 16; ++rc) {
        int32_t cse_var_1 = ((ff * 3) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 3) + yy)] * weight_1x1_conv2d_19[((ff * 16) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 48; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)conv2d_nchw_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 48; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 48; ++c) {
    ((int8_t*)conv2d_nchw_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_3 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)conv2d_nchw_let)[c] = (((int8_t*)conv2d_nchw_let)[c] + (((int8_t*)dyn_slice_fixed_size_let)[cse_var_3] * weight_depth_wise_19[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 16; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 48; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_linear_19[((ff_1 * 48) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(int8_t* data_buffer_var, int8_t* conv2d_1_buffer_var, int8_t* weight_depth_wise_1_buffer_var, int8_t* conv2d_2_buffer_var, int8_t* weight_1x1_conv2d_18_buffer_var, int8_t* weight_depth_wise_18_buffer_var, int8_t* weight_1x1_conv2d_linear_18_buffer_var, int8_t* weight_1x1_conv2d_19_buffer_var, int8_t* weight_depth_wise_19_buffer_var, int8_t* weight_1x1_conv2d_linear_19_buffer_var, int8_t* weight_1x1_conv2d_20_buffer_var, int8_t* weight_depth_wise_20_buffer_var, int8_t* weight_1x1_conv2d_linear_20_buffer_var, int8_t* weight_1x1_conv2d_21_buffer_var, int8_t* weight_depth_wise_21_buffer_var, int8_t* weight_1x1_conv2d_linear_21_buffer_var, int8_t* weight_1x1_conv2d_22_buffer_var, int8_t* weight_depth_wise_22_buffer_var, int8_t* weight_1x1_conv2d_linear_22_buffer_var, int8_t* weight_1x1_conv2d_23_buffer_var, int8_t* weight_depth_wise_23_buffer_var, int8_t* weight_1x1_conv2d_linear_23_buffer_var, int8_t* weight_1x1_conv2d_24_buffer_var, int8_t* weight_depth_wise_24_buffer_var, int8_t* weight_1x1_conv2d_linear_24_buffer_var, int8_t* weight_1x1_conv2d_25_buffer_var, int8_t* weight_depth_wise_25_buffer_var, int8_t* weight_1x1_conv2d_linear_25_buffer_var, int8_t* weight_1x1_conv2d_26_buffer_var, int8_t* weight_depth_wise_26_buffer_var, int8_t* weight_1x1_conv2d_linear_26_buffer_var, int8_t* weight_1x1_conv2d_27_buffer_var, int8_t* weight_depth_wise_27_buffer_var, int8_t* weight_1x1_conv2d_linear_27_buffer_var, int8_t* weight_1x1_conv2d_28_buffer_var, int8_t* weight_depth_wise_28_buffer_var, int8_t* weight_1x1_conv2d_linear_28_buffer_var, int8_t* weight_1x1_conv2d_29_buffer_var, int8_t* weight_depth_wise_29_buffer_var, int8_t* weight_1x1_conv2d_linear_29_buffer_var, int8_t* weight_1x1_conv2d_30_buffer_var, int8_t* weight_depth_wise_30_buffer_var, int8_t* weight_1x1_conv2d_linear_30_buffer_var, int8_t* weight_1x1_conv2d_31_buffer_var, int8_t* weight_depth_wise_31_buffer_var, int8_t* weight_1x1_conv2d_linear_31_buffer_var, int8_t* output_buffer_var, uint8_t* global_workspace_0_var) {
  void* sid_51_let = (&(global_workspace_0_var[15624]));
  void* sid_50_let = (&(global_workspace_0_var[0]));
  void* sid_49_let = (&(global_workspace_0_var[12000]));
  void* sid_48_let = (&(global_workspace_0_var[0]));
  void* sid_46_let = (&(global_workspace_0_var[0]));
  void* sid_47_let = (&(global_workspace_0_var[6400]));
  void* sid_59_let = (&(global_workspace_0_var[7776]));
  void* sid_54_let = (&(global_workspace_0_var[0]));
  void* sid_55_let = (&(global_workspace_0_var[6000]));
  void* sid_52_let = (&(global_workspace_0_var[7056]));
  void* sid_56_let = (&(global_workspace_0_var[10800]));
  void* sid_53_let = (&(global_workspace_0_var[13056]));
  void* sid_57_let = (&(global_workspace_0_var[15600]));
  void* sid_58_let = (&(global_workspace_0_var[0]));
  void* sid_60_let = (&(global_workspace_0_var[0]));
  if (tvmgen_default_fused_fusion_iter_worker(data_buffer_var, conv2d_1_buffer_var, weight_depth_wise_1_buffer_var, conv2d_2_buffer_var, weight_1x1_conv2d_18_buffer_var, weight_depth_wise_18_buffer_var, weight_1x1_conv2d_linear_18_buffer_var, sid_46_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_1(sid_46_let, weight_1x1_conv2d_19_buffer_var, weight_depth_wise_19_buffer_var, weight_1x1_conv2d_linear_19_buffer_var, sid_47_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_2(sid_47_let, weight_1x1_conv2d_20_buffer_var, weight_depth_wise_20_buffer_var, weight_1x1_conv2d_linear_20_buffer_var, sid_48_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_3(sid_48_let, weight_1x1_conv2d_21_buffer_var, weight_depth_wise_21_buffer_var, weight_1x1_conv2d_linear_21_buffer_var, sid_49_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_4(sid_49_let, weight_1x1_conv2d_22_buffer_var, weight_depth_wise_22_buffer_var, weight_1x1_conv2d_linear_22_buffer_var, weight_1x1_conv2d_23_buffer_var, sid_50_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_5(sid_50_let, weight_depth_wise_23_buffer_var, weight_1x1_conv2d_linear_23_buffer_var, sid_51_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_6(sid_51_let, weight_1x1_conv2d_24_buffer_var, weight_depth_wise_24_buffer_var, weight_1x1_conv2d_linear_24_buffer_var, weight_1x1_conv2d_25_buffer_var, sid_52_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d(sid_52_let, weight_depth_wise_25_buffer_var, sid_53_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_7(sid_53_let, weight_1x1_conv2d_linear_25_buffer_var, weight_1x1_conv2d_26_buffer_var, sid_54_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_8(sid_54_let, weight_depth_wise_26_buffer_var, weight_1x1_conv2d_linear_26_buffer_var, weight_1x1_conv2d_27_buffer_var, sid_55_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_1(sid_55_let, weight_depth_wise_27_buffer_var, sid_56_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_9(sid_56_let, weight_1x1_conv2d_linear_27_buffer_var, weight_1x1_conv2d_28_buffer_var, weight_depth_wise_28_buffer_var, sid_57_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_10(sid_57_let, weight_1x1_conv2d_linear_28_buffer_var, weight_1x1_conv2d_29_buffer_var, weight_depth_wise_29_buffer_var, sid_58_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_11(sid_58_let, weight_1x1_conv2d_linear_29_buffer_var, weight_1x1_conv2d_30_buffer_var, weight_depth_wise_30_buffer_var, weight_1x1_conv2d_linear_30_buffer_var, weight_1x1_conv2d_31_buffer_var, sid_59_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_2(sid_59_let, weight_depth_wise_31_buffer_var, sid_60_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_3(sid_60_let, weight_1x1_conv2d_linear_31_buffer_var, output_buffer_var, global_workspace_0_var) != 0 ) return -1;
  return 0;
}


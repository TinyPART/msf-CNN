#ifndef TVMGEN_DEFAULT_H_
#define TVMGEN_DEFAULT_H_
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*!
 * \brief Input tensor weight_1x1_conv2d_linear_26 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_26_SIZE 11520
/*!
 * \brief Input tensor weight_depth_wise_18 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_18_SIZE 432
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_24 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_24_SIZE 5760
/*!
 * \brief Input tensor weight_1x1_conv2d_23 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_23_SIZE 2880
/*!
 * \brief Input tensor weight_1x1_conv2d_31 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_31_SIZE 27648
/*!
 * \brief Input tensor weight_depth_wise_26 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_26_SIZE 2160
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_22 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_22_SIZE 3456
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_20 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_20_SIZE 768
/*!
 * \brief Input tensor weight_depth_wise_22 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_22_SIZE 1296
/*!
 * \brief Input tensor weight_1x1_conv2d_18 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_18_SIZE 384
/*!
 * \brief Input tensor weight_depth_wise_30 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_30_SIZE 3456
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_19 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_19_SIZE 768
/*!
 * \brief Input tensor weight_1x1_conv2d_26 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_26_SIZE 9600
/*!
 * \brief Input tensor weight_depth_wise_29 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_29_SIZE 4320
/*!
 * \brief Input tensor data size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_DATA_SIZE 19200
/*!
 * \brief Input tensor weight_1x1_conv2d_22 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_22_SIZE 3456
/*!
 * \brief Input tensor weight_1x1_conv2d_30 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_30_SIZE 36864
/*!
 * \brief Input tensor weight_depth_wise_25 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_25_SIZE 11760
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_30 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_30_SIZE 36864
/*!
 * \brief Input tensor weight_1x1_conv2d_29 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_29_SIZE 46080
/*!
 * \brief Input tensor conv2d_1 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_CONV2D_1_SIZE 432
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_29 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_29_SIZE 46080
/*!
 * \brief Input tensor weight_depth_wise_21 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_21_SIZE 2352
/*!
 * \brief Input tensor weight_depth_wise_1 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_1_SIZE 144
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_27 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_27_SIZE 9216
/*!
 * \brief Input tensor weight_1x1_conv2d_25 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_25_SIZE 9600
/*!
 * \brief Input tensor weight_depth_wise_28 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_28_SIZE 6000
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_25 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_25_SIZE 9600
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_23 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_23_SIZE 2880
/*!
 * \brief Input tensor weight_1x1_conv2d_21 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_21_SIZE 768
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_21 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_21_SIZE 1152
/*!
 * \brief Input tensor weight_depth_wise_24 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_24_SIZE 7056
/*!
 * \brief Input tensor weight_1x1_conv2d_28 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_28_SIZE 11520
/*!
 * \brief Input tensor weight_depth_wise_20 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_20_SIZE 432
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_18 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_18_SIZE 768
/*!
 * \brief Input tensor weight_1x1_conv2d_24 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_24_SIZE 3456
/*!
 * \brief Input tensor weight_depth_wise_19 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_19_SIZE 432
/*!
 * \brief Input tensor weight_depth_wise_27 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_27_SIZE 1728
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_31 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_31_SIZE 46080
/*!
 * \brief Input tensor conv2d_2 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_CONV2D_2_SIZE 128
/*!
 * \brief Input tensor weight_1x1_conv2d_20 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_20_SIZE 768
/*!
 * \brief Input tensor weight_depth_wise_23 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_23_SIZE 3000
/*!
 * \brief Input tensor weight_1x1_conv2d_19 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_19_SIZE 768
/*!
 * \brief Input tensor weight_depth_wise_31 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_31_SIZE 14112
/*!
 * \brief Input tensor weight_1x1_conv2d_27 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_27_SIZE 9216
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_28 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_28_SIZE 23040
/*!
 * \brief Output tensor output size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_OUTPUT_SIZE 1440
/*!
 * \brief Input tensor pointers for TVM module "default" 
 */
struct tvmgen_default_inputs {
  void* data;
  void* conv2d_1;
  void* weight_depth_wise_1;
  void* conv2d_2;
  void* weight_1x1_conv2d_18;
  void* weight_depth_wise_18;
  void* weight_1x1_conv2d_linear_18;
  void* weight_1x1_conv2d_19;
  void* weight_depth_wise_19;
  void* weight_1x1_conv2d_linear_19;
  void* weight_1x1_conv2d_20;
  void* weight_depth_wise_20;
  void* weight_1x1_conv2d_linear_20;
  void* weight_1x1_conv2d_21;
  void* weight_depth_wise_21;
  void* weight_1x1_conv2d_linear_21;
  void* weight_1x1_conv2d_22;
  void* weight_depth_wise_22;
  void* weight_1x1_conv2d_linear_22;
  void* weight_1x1_conv2d_23;
  void* weight_depth_wise_23;
  void* weight_1x1_conv2d_linear_23;
  void* weight_1x1_conv2d_24;
  void* weight_depth_wise_24;
  void* weight_1x1_conv2d_linear_24;
  void* weight_1x1_conv2d_25;
  void* weight_depth_wise_25;
  void* weight_1x1_conv2d_linear_25;
  void* weight_1x1_conv2d_26;
  void* weight_depth_wise_26;
  void* weight_1x1_conv2d_linear_26;
  void* weight_1x1_conv2d_27;
  void* weight_depth_wise_27;
  void* weight_1x1_conv2d_linear_27;
  void* weight_1x1_conv2d_28;
  void* weight_depth_wise_28;
  void* weight_1x1_conv2d_linear_28;
  void* weight_1x1_conv2d_29;
  void* weight_depth_wise_29;
  void* weight_1x1_conv2d_linear_29;
  void* weight_1x1_conv2d_30;
  void* weight_depth_wise_30;
  void* weight_1x1_conv2d_linear_30;
  void* weight_1x1_conv2d_31;
  void* weight_depth_wise_31;
  void* weight_1x1_conv2d_linear_31;
};

/*!
 * \brief Output tensor pointers for TVM module "default" 
 */
struct tvmgen_default_outputs {
  void* output;
};

/*!
 * \brief entrypoint function for TVM module "default"
 * \param inputs Input tensors for the module 
 * \param outputs Output tensors for the module 
 */
int32_t tvmgen_default_run(
  struct tvmgen_default_inputs* inputs,
  struct tvmgen_default_outputs* outputs
);
/*!
 * \brief Workspace size for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WORKSPACE_SIZE 15368

#ifdef __cplusplus
}
#endif

#endif // TVMGEN_DEFAULT_H_

// tvm target: c -keys=partial_conv,arm_cpu,cpu -mcpu=cortex-m4+nodsp -model=nrf52840
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* p7, int8_t* fusion_iter_worker, uint8_t* global_workspace_1_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_1(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_3_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_10(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_26_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_11(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_30_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_12(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_32_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_13(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_34_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_14(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_36_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_2(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_5_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_3(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_7_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_4(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* p7, int8_t* fusion_iter_worker, uint8_t* global_workspace_9_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_5(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_11_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_6(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_14_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_7(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_17_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_8(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_20_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_9(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_23_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_13_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_1(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_16_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_2(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_19_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_3(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_22_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_4(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_25_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_5(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_28_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_6(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_29_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_12(int32_t* iterator, int8_t* dummy_input_10, int8_t* weight_1x1_conv2d_4, int8_t* weight_depth_wise_4, int8_t* weight_1x1_conv2d_linear_4, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_6_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_15(int32_t* iterator, int8_t* dummy_input_13, int8_t* weight_1x1_conv2d_5, int8_t* weight_depth_wise_5, int8_t* weight_1x1_conv2d_linear_5, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_8_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_22(int32_t* iterator, int8_t* dummy_input_16, int8_t* weight_1x1_conv2d_6, int8_t* weight_depth_wise_6, int8_t* weight_1x1_conv2d_linear_6, int8_t* weight_1x1_conv2d_7, int8_t* weight_depth_wise_7, int8_t* weight_1x1_conv2d_linear_7, int8_t* weight_1x1_conv2d_8, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* conv2d_nchw, uint8_t* global_workspace_10_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_24(int32_t* iterator, int8_t* dummy_input_23, int8_t* weight_depth_wise_8, int8_t* weight_1x1_conv2d_linear_8, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_12_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_27(int32_t* iterator, int8_t* dummy_input_26, int8_t* weight_depth_wise_9, int8_t* weight_1x1_conv2d_linear_9, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_15_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_30(int32_t* iterator, int8_t* dummy_input_29, int8_t* weight_depth_wise_10, int8_t* weight_1x1_conv2d_linear_10, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_18_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_33(int32_t* iterator, int8_t* dummy_input_32, int8_t* weight_depth_wise_11, int8_t* weight_1x1_conv2d_linear_11, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_21_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_36(int32_t* iterator, int8_t* dummy_input_35, int8_t* weight_depth_wise_12, int8_t* weight_1x1_conv2d_linear_12, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_24_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_39(int32_t* iterator, int8_t* dummy_input_38, int8_t* weight_depth_wise_13, int8_t* weight_1x1_conv2d_linear_13, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_27_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_43(int32_t* iterator, int8_t* dummy_input_42, int8_t* weight_1x1_conv2d_linear_14, int8_t* weight_1x1_conv2d_15, int8_t* conv2d_nchw, uint8_t* global_workspace_31_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_46(int32_t* iterator, int8_t* dummy_input_44, int8_t* weight_depth_wise_15, int8_t* weight_1x1_conv2d_linear_15, int8_t* weight_1x1_conv2d_16, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_33_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_49(int32_t* iterator, int8_t* dummy_input_47, int8_t* weight_depth_wise_16, int8_t* weight_1x1_conv2d_linear_16, int8_t* weight_1x1_conv2d_17, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_35_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_52(int32_t* iterator, int8_t* dummy_input_50, int8_t* weight_depth_wise_17, int8_t* weight_1x1_conv2d_linear_17, int8_t* conv2d_2, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_37_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_6(int32_t* iterator, int8_t* dummy_input_0, int8_t* conv2d_1, int8_t* weight_1x1_conv2d_1, int8_t* weight_depth_wise_1, int8_t* weight_1x1_conv2d_linear_1, int8_t* weight_1x1_conv2d_2, int8_t* weight_depth_wise_2, int8_t* weight_1x1_conv2d_linear_2, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* cache_buffer_var_2, int32_t* cache_cur_idx_2, int8_t* conv2d_nchw, uint8_t* global_workspace_2_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_9(int32_t* iterator, int8_t* dummy_input_7, int8_t* weight_1x1_conv2d_3, int8_t* weight_depth_wise_3, int8_t* weight_1x1_conv2d_linear_3, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_4_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(int8_t* data_buffer_var, int8_t* conv2d_1_buffer_var, int8_t* weight_1x1_conv2d_1_buffer_var, int8_t* weight_depth_wise_1_buffer_var, int8_t* weight_1x1_conv2d_linear_1_buffer_var, int8_t* weight_1x1_conv2d_2_buffer_var, int8_t* weight_depth_wise_2_buffer_var, int8_t* weight_1x1_conv2d_linear_2_buffer_var, int8_t* weight_1x1_conv2d_3_buffer_var, int8_t* weight_depth_wise_3_buffer_var, int8_t* weight_1x1_conv2d_linear_3_buffer_var, int8_t* weight_1x1_conv2d_4_buffer_var, int8_t* weight_depth_wise_4_buffer_var, int8_t* weight_1x1_conv2d_linear_4_buffer_var, int8_t* weight_1x1_conv2d_5_buffer_var, int8_t* weight_depth_wise_5_buffer_var, int8_t* weight_1x1_conv2d_linear_5_buffer_var, int8_t* weight_1x1_conv2d_6_buffer_var, int8_t* weight_depth_wise_6_buffer_var, int8_t* weight_1x1_conv2d_linear_6_buffer_var, int8_t* weight_1x1_conv2d_7_buffer_var, int8_t* weight_depth_wise_7_buffer_var, int8_t* weight_1x1_conv2d_linear_7_buffer_var, int8_t* weight_1x1_conv2d_8_buffer_var, int8_t* weight_depth_wise_8_buffer_var, int8_t* weight_1x1_conv2d_linear_8_buffer_var, int8_t* weight_1x1_conv2d_9_buffer_var, int8_t* weight_depth_wise_9_buffer_var, int8_t* weight_1x1_conv2d_linear_9_buffer_var, int8_t* weight_1x1_conv2d_10_buffer_var, int8_t* weight_depth_wise_10_buffer_var, int8_t* weight_1x1_conv2d_linear_10_buffer_var, int8_t* weight_1x1_conv2d_11_buffer_var, int8_t* weight_depth_wise_11_buffer_var, int8_t* weight_1x1_conv2d_linear_11_buffer_var, int8_t* weight_1x1_conv2d_12_buffer_var, int8_t* weight_depth_wise_12_buffer_var, int8_t* weight_1x1_conv2d_linear_12_buffer_var, int8_t* weight_1x1_conv2d_13_buffer_var, int8_t* weight_depth_wise_13_buffer_var, int8_t* weight_1x1_conv2d_linear_13_buffer_var, int8_t* weight_1x1_conv2d_14_buffer_var, int8_t* weight_depth_wise_14_buffer_var, int8_t* weight_1x1_conv2d_linear_14_buffer_var, int8_t* weight_1x1_conv2d_15_buffer_var, int8_t* weight_depth_wise_15_buffer_var, int8_t* weight_1x1_conv2d_linear_15_buffer_var, int8_t* weight_1x1_conv2d_16_buffer_var, int8_t* weight_depth_wise_16_buffer_var, int8_t* weight_1x1_conv2d_linear_16_buffer_var, int8_t* weight_1x1_conv2d_17_buffer_var, int8_t* weight_depth_wise_17_buffer_var, int8_t* weight_1x1_conv2d_linear_17_buffer_var, int8_t* conv2d_2_buffer_var, int8_t* output_buffer_var, uint8_t* global_workspace_0_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* p7, int8_t* fusion_iter_worker, uint8_t* global_workspace_1_var) {
  void* iterator_let = (&(global_workspace_1_var[11280]));
  void* iteratee_output_let = (&(global_workspace_1_var[11360]));
  void* bg_ind_let = (&(global_workspace_1_var[11344]));
  void* cache_buffer_var_let = (&(global_workspace_1_var[11180]));
  void* cache_cur_idx_let = (&(global_workspace_1_var[11328]));
  void* cache_buffer_var_let_1 = (&(global_workspace_1_var[10912]));
  void* cache_cur_idx_let_1 = (&(global_workspace_1_var[11312]));
  void* cache_buffer_var_let_2 = (&(global_workspace_1_var[10640]));
  void* cache_cur_idx_let_2 = (&(global_workspace_1_var[11296]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_1)[0] = 0;
  ((int32_t*)cache_cur_idx_let_1)[1] = 0;
  ((int32_t*)cache_cur_idx_let_1)[2] = 0;
  ((int32_t*)cache_cur_idx_let_1)[3] = 0;
  ((int8_t*)cache_buffer_var_let_2)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_2)[0] = 0;
  ((int32_t*)cache_cur_idx_let_2)[1] = 0;
  ((int32_t*)cache_cur_idx_let_2)[2] = 0;
  ((int32_t*)cache_cur_idx_let_2)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 35))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 35))) { break; }
      if (tvmgen_default_iteratee_6(iterator_let, p0, p1, p2, p3, p4, p5, p6, p7, cache_buffer_var_let, cache_cur_idx_let, cache_buffer_var_let_1, cache_cur_idx_let_1, cache_buffer_var_let_2, cache_cur_idx_let_2, iteratee_output_let, global_workspace_1_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 8; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 10368) + (i * 1296)) + (((int32_t*)bg_ind_let)[1] * 1296)) + (((int32_t*)bg_ind_let)[2] * 36)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 35) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 4);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_1)[0] = 0;
    ((int32_t*)cache_cur_idx_let_1)[1] = 0;
    ((int32_t*)cache_cur_idx_let_1)[2] = 0;
    ((int32_t*)cache_cur_idx_let_1)[3] = 0;
    ((int8_t*)cache_buffer_var_let_2)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_2)[0] = 0;
    ((int32_t*)cache_cur_idx_let_2)[1] = 0;
    ((int32_t*)cache_cur_idx_let_2)[2] = 0;
    ((int32_t*)cache_cur_idx_let_2)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 4);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_1(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_3_var) {
  void* iterator_let = (&(global_workspace_3_var[21192]));
  void* iteratee_output_let = (&(global_workspace_3_var[21240]));
  void* bg_ind_let = (&(global_workspace_3_var[21224]));
  void* cache_buffer_var_let = (&(global_workspace_3_var[20736]));
  void* cache_cur_idx_let = (&(global_workspace_3_var[21208]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 35))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 35))) { break; }
      if (tvmgen_default_iteratee_9(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_3_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 8; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 10368) + (i * 1296)) + (((int32_t*)bg_ind_let)[1] * 1296)) + (((int32_t*)bg_ind_let)[2] * 36)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 35) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_10(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_26_var) {
  void* iterator_let = (&(global_workspace_26_var[21132]));
  void* iteratee_output_let = (&(global_workspace_26_var[21096]));
  void* bg_ind_let = (&(global_workspace_26_var[21164]));
  void* cache_buffer_var_let = (&(global_workspace_26_var[18716]));
  void* cache_cur_idx_let = (&(global_workspace_26_var[21148]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 8))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 8))) { break; }
      if (tvmgen_default_iteratee_39(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_26_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 33; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 2673) + (i * 81)) + (((int32_t*)bg_ind_let)[1] * 81)) + (((int32_t*)bg_ind_let)[2] * 9)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 8) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_11(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_30_var) {
  void* iterator_let = (&(global_workspace_30_var[0]));
  void* iteratee_output_let = (&(global_workspace_30_var[4968]));
  void* bg_ind_let = (&(global_workspace_30_var[5504]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 4))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 4))) { break; }
      if (tvmgen_default_iteratee_43(iterator_let, p0, p1, p2, iteratee_output_let, global_workspace_30_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 336; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 8400) + (i * 25)) + (((int32_t*)bg_ind_let)[1] * 25)) + (((int32_t*)bg_ind_let)[2] * 5)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 4) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_12(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_32_var) {
  void* iterator_let = (&(global_workspace_32_var[12840]));
  void* iteratee_output_let = (&(global_workspace_32_var[12448]));
  void* bg_ind_let = (&(global_workspace_32_var[11424]));
  void* cache_buffer_var_let = (&(global_workspace_32_var[0]));
  void* cache_cur_idx_let = (&(global_workspace_32_var[12856]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 4))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 4))) { break; }
      if (tvmgen_default_iteratee_46(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_32_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 336; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 8400) + (i * 25)) + (((int32_t*)bg_ind_let)[1] * 25)) + (((int32_t*)bg_ind_let)[2] * 5)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 4) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_13(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_34_var) {
  void* iterator_let = (&(global_workspace_34_var[21168]));
  void* iteratee_output_let = (&(global_workspace_34_var[20832]));
  void* bg_ind_let = (&(global_workspace_34_var[21200]));
  void* cache_buffer_var_let = (&(global_workspace_34_var[0]));
  void* cache_cur_idx_let = (&(global_workspace_34_var[21184]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 4))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 4))) { break; }
      if (tvmgen_default_iteratee_49(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_34_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 336; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 8400) + (i * 25)) + (((int32_t*)bg_ind_let)[1] * 25)) + (((int32_t*)bg_ind_let)[2] * 5)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 4) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_14(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_36_var) {
  void* iterator_let = (&(global_workspace_36_var[7504]));
  void* iteratee_output_let = (&(global_workspace_36_var[7056]));
  void* bg_ind_let = (&(global_workspace_36_var[7536]));
  void* cache_buffer_var_let = (&(global_workspace_36_var[0]));
  void* cache_cur_idx_let = (&(global_workspace_36_var[7520]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 4))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 4))) { break; }
      if (tvmgen_default_iteratee_52(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_36_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 448; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 11200) + (i * 25)) + (((int32_t*)bg_ind_let)[1] * 25)) + (((int32_t*)bg_ind_let)[2] * 5)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 4) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_2(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_5_var) {
  void* iterator_let = (&(global_workspace_5_var[4572]));
  void* iteratee_output_let = (&(global_workspace_5_var[4620]));
  void* bg_ind_let = (&(global_workspace_5_var[4604]));
  void* cache_buffer_var_let = (&(global_workspace_5_var[3564]));
  void* cache_cur_idx_let = (&(global_workspace_5_var[4588]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 17))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 17))) { break; }
      if (tvmgen_default_iteratee_12(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_5_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 11; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 3564) + (i * 324)) + (((int32_t*)bg_ind_let)[1] * 324)) + (((int32_t*)bg_ind_let)[2] * 18)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 17) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_3(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_7_var) {
  void* iterator_let = (&(global_workspace_7_var[4196]));
  void* iteratee_output_let = (&(global_workspace_7_var[4244]));
  void* bg_ind_let = (&(global_workspace_7_var[4228]));
  void* cache_buffer_var_let = (&(global_workspace_7_var[3564]));
  void* cache_cur_idx_let = (&(global_workspace_7_var[4212]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 17))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 17))) { break; }
      if (tvmgen_default_iteratee_15(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_7_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 11; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 3564) + (i * 324)) + (((int32_t*)bg_ind_let)[1] * 324)) + (((int32_t*)bg_ind_let)[2] * 18)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 17) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_4(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* p7, int8_t* fusion_iter_worker, uint8_t* global_workspace_9_var) {
  void* iterator_let = (&(global_workspace_9_var[16032]));
  void* iteratee_output_let = (&(global_workspace_9_var[15844]));
  void* bg_ind_let = (&(global_workspace_9_var[16080]));
  void* cache_buffer_var_let = (&(global_workspace_9_var[14256]));
  void* cache_cur_idx_let = (&(global_workspace_9_var[16064]));
  void* cache_buffer_var_let_1 = (&(global_workspace_9_var[15248]));
  void* cache_cur_idx_let_1 = (&(global_workspace_9_var[16048]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_1)[0] = 0;
  ((int32_t*)cache_cur_idx_let_1)[1] = 0;
  ((int32_t*)cache_cur_idx_let_1)[2] = 0;
  ((int32_t*)cache_cur_idx_let_1)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 8))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 8))) { break; }
      if (tvmgen_default_iteratee_22(iterator_let, p0, p1, p2, p3, p4, p5, p6, p7, cache_buffer_var_let, cache_cur_idx_let, cache_buffer_var_let_1, cache_cur_idx_let_1, iteratee_output_let, global_workspace_9_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 132; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 10692) + (i * 81)) + (((int32_t*)bg_ind_let)[1] * 81)) + (((int32_t*)bg_ind_let)[2] * 9)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 8) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_1)[0] = 0;
    ((int32_t*)cache_cur_idx_let_1)[1] = 0;
    ((int32_t*)cache_cur_idx_let_1)[2] = 0;
    ((int32_t*)cache_cur_idx_let_1)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_5(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_11_var) {
  void* iterator_let = (&(global_workspace_11_var[14084]));
  void* iteratee_output_let = (&(global_workspace_11_var[14060]));
  void* bg_ind_let = (&(global_workspace_11_var[14116]));
  void* cache_buffer_var_let = (&(global_workspace_11_var[12476]));
  void* cache_cur_idx_let = (&(global_workspace_11_var[14100]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 8))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 8))) { break; }
      if (tvmgen_default_iteratee_24(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_11_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 22; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 1782) + (i * 81)) + (((int32_t*)bg_ind_let)[1] * 81)) + (((int32_t*)bg_ind_let)[2] * 9)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 8) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_6(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_14_var) {
  void* iterator_let = (&(global_workspace_14_var[14084]));
  void* iteratee_output_let = (&(global_workspace_14_var[14060]));
  void* bg_ind_let = (&(global_workspace_14_var[14116]));
  void* cache_buffer_var_let = (&(global_workspace_14_var[12476]));
  void* cache_cur_idx_let = (&(global_workspace_14_var[14100]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 8))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 8))) { break; }
      if (tvmgen_default_iteratee_27(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_14_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 22; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 1782) + (i * 81)) + (((int32_t*)bg_ind_let)[1] * 81)) + (((int32_t*)bg_ind_let)[2] * 9)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 8) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_7(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_17_var) {
  void* iterator_let = (&(global_workspace_17_var[14084]));
  void* iteratee_output_let = (&(global_workspace_17_var[14060]));
  void* bg_ind_let = (&(global_workspace_17_var[14116]));
  void* cache_buffer_var_let = (&(global_workspace_17_var[12476]));
  void* cache_cur_idx_let = (&(global_workspace_17_var[14100]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 8))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 8))) { break; }
      if (tvmgen_default_iteratee_30(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_17_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 22; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 1782) + (i * 81)) + (((int32_t*)bg_ind_let)[1] * 81)) + (((int32_t*)bg_ind_let)[2] * 9)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 8) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_8(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_20_var) {
  void* iterator_let = (&(global_workspace_20_var[12312]));
  void* iteratee_output_let = (&(global_workspace_20_var[12276]));
  void* bg_ind_let = (&(global_workspace_20_var[12344]));
  void* cache_buffer_var_let = (&(global_workspace_20_var[10692]));
  void* cache_cur_idx_let = (&(global_workspace_20_var[12328]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 8))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 8))) { break; }
      if (tvmgen_default_iteratee_33(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_20_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 33; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 2673) + (i * 81)) + (((int32_t*)bg_ind_let)[1] * 81)) + (((int32_t*)bg_ind_let)[2] * 9)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 8) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_9(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_23_var) {
  void* iterator_let = (&(global_workspace_23_var[18456]));
  void* iteratee_output_let = (&(global_workspace_23_var[18420]));
  void* bg_ind_let = (&(global_workspace_23_var[18488]));
  void* cache_buffer_var_let = (&(global_workspace_23_var[16040]));
  void* cache_cur_idx_let = (&(global_workspace_23_var[18472]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 8))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 8))) { break; }
      if (tvmgen_default_iteratee_36(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_23_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 33; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 2673) + (i * 81)) + (((int32_t*)bg_ind_let)[1] * 81)) + (((int32_t*)bg_ind_let)[2] * 9)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 8) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_13_var) {
  for (int32_t ff = 0; ff < 132; ++ff) {
    for (int32_t yy = 0; yy < 9; ++yy) {
      for (int32_t xx = 0; xx < 9; ++xx) {
        conv2d_nchw[(((ff * 81) + (yy * 9)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 22; ++rc) {
          int32_t cse_var_2 = (yy * 9);
          int32_t cse_var_1 = (((ff * 81) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 81) + cse_var_2) + xx)] * p1[((ff * 22) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_1(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_16_var) {
  for (int32_t ff = 0; ff < 132; ++ff) {
    for (int32_t yy = 0; yy < 9; ++yy) {
      for (int32_t xx = 0; xx < 9; ++xx) {
        conv2d_nchw[(((ff * 81) + (yy * 9)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 22; ++rc) {
          int32_t cse_var_2 = (yy * 9);
          int32_t cse_var_1 = (((ff * 81) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 81) + cse_var_2) + xx)] * p1[((ff * 22) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_2(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_19_var) {
  for (int32_t ff = 0; ff < 132; ++ff) {
    for (int32_t yy = 0; yy < 9; ++yy) {
      for (int32_t xx = 0; xx < 9; ++xx) {
        conv2d_nchw[(((ff * 81) + (yy * 9)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 22; ++rc) {
          int32_t cse_var_2 = (yy * 9);
          int32_t cse_var_1 = (((ff * 81) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 81) + cse_var_2) + xx)] * p1[((ff * 22) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_3(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_22_var) {
  for (int32_t ff = 0; ff < 198; ++ff) {
    for (int32_t yy = 0; yy < 9; ++yy) {
      for (int32_t xx = 0; xx < 9; ++xx) {
        conv2d_nchw[(((ff * 81) + (yy * 9)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 33; ++rc) {
          int32_t cse_var_2 = (yy * 9);
          int32_t cse_var_1 = (((ff * 81) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 81) + cse_var_2) + xx)] * p1[((ff * 33) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_4(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_25_var) {
  for (int32_t ff = 0; ff < 198; ++ff) {
    for (int32_t yy = 0; yy < 9; ++yy) {
      for (int32_t xx = 0; xx < 9; ++xx) {
        conv2d_nchw[(((ff * 81) + (yy * 9)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 33; ++rc) {
          int32_t cse_var_2 = (yy * 9);
          int32_t cse_var_1 = (((ff * 81) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 81) + cse_var_2) + xx)] * p1[((ff * 33) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_5(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_28_var) {
  for (int32_t ff = 0; ff < 198; ++ff) {
    for (int32_t yy = 0; yy < 9; ++yy) {
      for (int32_t xx = 0; xx < 9; ++xx) {
        conv2d_nchw[(((ff * 81) + (yy * 9)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 33; ++rc) {
          int32_t cse_var_2 = (yy * 9);
          int32_t cse_var_1 = (((ff * 81) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 81) + cse_var_2) + xx)] * p1[((ff * 33) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_6(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_29_var) {
  for (int32_t c = 0; c < 198; ++c) {
    for (int32_t i = 0; i < 5; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        DepthwiseConv2d[(((c * 25) + (i * 5)) + j)] = (int8_t)0;
        for (int32_t di = 0; di < 3; ++di) {
          for (int32_t dj = 0; dj < 3; ++dj) {
            int32_t cse_var_1 = (((c * 25) + (i * 5)) + j);
            DepthwiseConv2d[cse_var_1] = (DepthwiseConv2d[cse_var_1] + (p0[(((c * 81) + ((((i * 2) + di) % 9) * 9)) + (((j * 2) + dj) % 9))] * p1[(((c * 9) + (di * 3)) + dj)]));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_12(int32_t* iterator, int8_t* dummy_input_10, int8_t* weight_1x1_conv2d_4, int8_t* weight_depth_wise_4, int8_t* weight_1x1_conv2d_linear_4, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_6_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_6_var[3996]));
  void* conv2d_nchw_let = (&(global_workspace_6_var[4428]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_6_var[3996]));
  for (int32_t i1 = 0; i1 < 8; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_10[((((((iterator[0] * 10368) + (i1 * 1296)) + (iterator[1] * 1296)) + (i2 * 36)) + (iterator[2] * 36)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    for (int32_t yy = 0; yy < 3; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 3) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 8; ++rc) {
        int32_t cse_var_1 = ((ff * 3) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 3) + yy)] * weight_1x1_conv2d_4[((ff * 8) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 48; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)conv2d_nchw_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((2 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 48; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 48; ++c) {
    ((int8_t*)conv2d_nchw_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_3 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)conv2d_nchw_let)[c] = (((int8_t*)conv2d_nchw_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_3] * weight_depth_wise_4[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 11; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 48; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_linear_4[((ff_1 * 48) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_15(int32_t* iterator, int8_t* dummy_input_13, int8_t* weight_1x1_conv2d_5, int8_t* weight_depth_wise_5, int8_t* weight_1x1_conv2d_linear_5, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_8_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_8_var[4160]));
  void* conv2d_nchw_let = (&(global_workspace_8_var[596]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_8_var[0]));
  for (int32_t i1 = 0; i1 < 11; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_13[((((((iterator[0] * 3564) + (i1 * 324)) + (iterator[1] * 324)) + (i2 * 18)) + (iterator[2] * 18)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 66; ++ff) {
    for (int32_t yy = 0; yy < 3; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 3) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 11; ++rc) {
        int32_t cse_var_1 = ((ff * 3) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 3) + yy)] * weight_1x1_conv2d_5[((ff * 11) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 66; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)conv2d_nchw_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 66; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 66; ++c) {
    ((int8_t*)conv2d_nchw_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_3 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)conv2d_nchw_let)[c] = (((int8_t*)conv2d_nchw_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_3] * weight_depth_wise_5[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 11; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 66; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_linear_5[((ff_1 * 66) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_22(int32_t* iterator, int8_t* dummy_input_16, int8_t* weight_1x1_conv2d_6, int8_t* weight_depth_wise_6, int8_t* weight_1x1_conv2d_linear_6, int8_t* weight_1x1_conv2d_7, int8_t* weight_depth_wise_7, int8_t* weight_1x1_conv2d_linear_7, int8_t* weight_1x1_conv2d_8, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* conv2d_nchw, uint8_t* global_workspace_10_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_10_var[15976]));
  void* conv2d_nchw_let = (&(global_workspace_10_var[11684]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_10_var[10692]));
  for (int32_t i1 = 0; i1 < 11; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_16[((((((iterator[0] * 3564) + (i1 * 324)) + (iterator[1] * 324)) + (i2 * 18)) + (iterator[2] * 18)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 66; ++ff) {
    for (int32_t yy = 0; yy < 5; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 5) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 11; ++rc) {
        int32_t cse_var_1 = ((ff * 5) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 5) + yy)] * weight_1x1_conv2d_6[((ff * 11) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 66; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 15) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)conv2d_nchw_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 66; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 15) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 66; ++c) {
    for (int32_t i_1 = 0; i_1 < 3; ++i_1) {
      ((int8_t*)conv2d_nchw_let)[((c * 3) + i_1)] = (int8_t)0;
      for (int32_t di = 0; di < 3; ++di) {
        for (int32_t dj = 0; dj < 3; ++dj) {
          int32_t cse_var_4 = (di * 3);
          int32_t cse_var_3 = ((c * 3) + i_1);
          ((int8_t*)conv2d_nchw_let)[cse_var_3] = (((int8_t*)conv2d_nchw_let)[cse_var_3] + (((int8_t*)cache_conv_input_compute_generic_let)[((((c * 15) + (i_1 * 3)) + cse_var_4) + dj)] * weight_depth_wise_6[(((c * 9) + cse_var_4) + dj)]));
        }
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 11; ++ff_1) {
    for (int32_t yy_1 = 0; yy_1 < 3; ++yy_1) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_1 * 3) + yy_1)] = (int8_t)0;
      for (int32_t rc_1 = 0; rc_1 < 66; ++rc_1) {
        int32_t cse_var_5 = ((ff_1 * 3) + yy_1);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] + (((int8_t*)conv2d_nchw_let)[((rc_1 * 3) + yy_1)] * weight_1x1_conv2d_linear_6[((ff_1 * 66) + rc_1)]));
      }
    }
  }
  for (int32_t ff_2 = 0; ff_2 < 66; ++ff_2) {
    for (int32_t yy_2 = 0; yy_2 < 3; ++yy_2) {
      ((int8_t*)conv2d_nchw_let)[((ff_2 * 3) + yy_2)] = (int8_t)0;
      for (int32_t rc_2 = 0; rc_2 < 11; ++rc_2) {
        int32_t cse_var_6 = ((ff_2 * 3) + yy_2);
        ((int8_t*)conv2d_nchw_let)[cse_var_6] = (((int8_t*)conv2d_nchw_let)[cse_var_6] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_2 * 3) + yy_2)] * weight_1x1_conv2d_7[((ff_2 * 11) + rc_2)]));
      }
    }
  }
  for (int32_t n_2 = 0; n_2 < 1; ++n_2) {
    for (int32_t i_2 = 0; i_2 < 66; ++i_2) {
      for (int32_t j_3 = 0; j_3 < 3; ++j_3) {
        for (int32_t k_2 = 0; k_2 < 1; ++k_2) {
          cache_buffer_var_1[(((i_2 * 9) + (j_3 * 3)) + (cache_cur_idx_1[3] & 1))] = ((int8_t*)conv2d_nchw_let)[((i_2 * 3) + j_3)];
        }
      }
    }
  }
  cache_cur_idx_1[3] = (cache_cur_idx_1[3] + 1);
  if ((2 <= cache_cur_idx_1[3]) && ((cache_cur_idx_1[3] % 2) == 0)) {
    for (int32_t n_3 = 0; n_3 < 1; ++n_3) {
      for (int32_t j_4 = 0; j_4 < 66; ++j_4) {
        for (int32_t j_5 = 0; j_5 < 3; ++j_5) {
          for (int32_t k_3 = 0; k_3 < 3; ++k_3) {
            int32_t cse_var_7 = (((j_4 * 9) + (j_5 * 3)) + k_3);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_7] = cache_buffer_var_1[cse_var_7];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_1 = 0; c_1 < 66; ++c_1) {
    ((int8_t*)conv2d_nchw_let)[c_1] = (int8_t)0;
    for (int32_t di_1 = 0; di_1 < 3; ++di_1) {
      for (int32_t dj_1 = 0; dj_1 < 3; ++dj_1) {
        int32_t cse_var_8 = (((c_1 * 9) + (di_1 * 3)) + dj_1);
        ((int8_t*)conv2d_nchw_let)[c_1] = (((int8_t*)conv2d_nchw_let)[c_1] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_8] * weight_depth_wise_7[cse_var_8]));
      }
    }
  }
  for (int32_t ff_3 = 0; ff_3 < 22; ++ff_3) {
    ((int8_t*)dyn_slice_fixed_size_let)[ff_3] = (int8_t)0;
    for (int32_t rc_3 = 0; rc_3 < 66; ++rc_3) {
      ((int8_t*)dyn_slice_fixed_size_let)[ff_3] = (((int8_t*)dyn_slice_fixed_size_let)[ff_3] + (((int8_t*)conv2d_nchw_let)[rc_3] * weight_1x1_conv2d_linear_7[((ff_3 * 66) + rc_3)]));
    }
  }
  for (int32_t ff_4 = 0; ff_4 < 132; ++ff_4) {
    conv2d_nchw[ff_4] = (int8_t)0;
    for (int32_t rc_4 = 0; rc_4 < 22; ++rc_4) {
      conv2d_nchw[ff_4] = (conv2d_nchw[ff_4] + (((int8_t*)dyn_slice_fixed_size_let)[rc_4] * weight_1x1_conv2d_8[((ff_4 * 22) + rc_4)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_24(int32_t* iterator, int8_t* dummy_input_23, int8_t* weight_depth_wise_8, int8_t* weight_1x1_conv2d_linear_8, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_12_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_12_var[13664]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_12_var[0]));
  for (int32_t i1 = 0; i1 < 132; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_23[((((((iterator[0] * 10692) + (i1 * 81)) + (iterator[1] * 81)) + (i2 * 9)) + (iterator[2] * 9)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 132; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 132; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 132; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_8[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 22; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 132; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_8[((ff * 132) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_27(int32_t* iterator, int8_t* dummy_input_26, int8_t* weight_depth_wise_9, int8_t* weight_1x1_conv2d_linear_9, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_15_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_15_var[13664]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_15_var[0]));
  for (int32_t i1 = 0; i1 < 132; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_26[((((((iterator[0] * 10692) + (i1 * 81)) + (iterator[1] * 81)) + (i2 * 9)) + (iterator[2] * 9)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 132; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 132; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 132; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_9[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 22; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 132; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_9[((ff * 132) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_30(int32_t* iterator, int8_t* dummy_input_29, int8_t* weight_depth_wise_10, int8_t* weight_1x1_conv2d_linear_10, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_18_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_18_var[13664]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_18_var[0]));
  for (int32_t i1 = 0; i1 < 132; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_29[((((((iterator[0] * 10692) + (i1 * 81)) + (iterator[1] * 81)) + (i2 * 9)) + (iterator[2] * 9)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 132; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 132; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 132; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_10[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 22; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 132; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_10[((ff * 132) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_33(int32_t* iterator, int8_t* dummy_input_32, int8_t* weight_depth_wise_11, int8_t* weight_1x1_conv2d_linear_11, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_21_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_21_var[11880]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_21_var[0]));
  for (int32_t i1 = 0; i1 < 132; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_32[((((((iterator[0] * 10692) + (i1 * 81)) + (iterator[1] * 81)) + (i2 * 9)) + (iterator[2] * 9)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 132; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 132; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 132; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_11[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 33; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 132; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_11[((ff * 132) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_36(int32_t* iterator, int8_t* dummy_input_35, int8_t* weight_depth_wise_12, int8_t* weight_1x1_conv2d_linear_12, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_24_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_24_var[17824]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_24_var[0]));
  for (int32_t i1 = 0; i1 < 198; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_35[((((((iterator[0] * 16038) + (i1 * 81)) + (iterator[1] * 81)) + (i2 * 9)) + (iterator[2] * 9)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 198; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 198; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 198; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_12[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 33; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 198; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_12[((ff * 198) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_39(int32_t* iterator, int8_t* dummy_input_38, int8_t* weight_depth_wise_13, int8_t* weight_1x1_conv2d_linear_13, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_27_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_27_var[20500]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_27_var[2676]));
  for (int32_t i1 = 0; i1 < 198; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_38[((((((iterator[0] * 16038) + (i1 * 81)) + (iterator[1] * 81)) + (i2 * 9)) + (iterator[2] * 9)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 198; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 198; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 198; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_13[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 33; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 198; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_13[((ff * 198) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_43(int32_t* iterator, int8_t* dummy_input_42, int8_t* weight_1x1_conv2d_linear_14, int8_t* weight_1x1_conv2d_15, int8_t* conv2d_nchw, uint8_t* global_workspace_31_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_31_var[5304]));
  void* conv2d_nchw_let = (&(global_workspace_31_var[16]));
  for (int32_t i1 = 0; i1 < 198; ++i1) {
    ((int8_t*)dyn_slice_fixed_size_let)[i1] = dummy_input_42[(((((iterator[0] * 4950) + (i1 * 25)) + (iterator[1] * 25)) + (iterator[2] * 5)) + iterator[3])];
  }
  for (int32_t ff = 0; ff < 56; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 198; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_14[((ff * 198) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 336; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 56; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_15[((ff_1 * 56) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_46(int32_t* iterator, int8_t* dummy_input_44, int8_t* weight_depth_wise_15, int8_t* weight_1x1_conv2d_linear_15, int8_t* weight_1x1_conv2d_16, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_33_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_33_var[11440]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_33_var[12872]));
  void* conv2d_nchw_let = (&(global_workspace_33_var[12784]));
  for (int32_t i1 = 0; i1 < 336; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_44[((((((iterator[0] * 8400) + (i1 * 25)) + (iterator[1] * 25)) + (i2 * 5)) + (iterator[2] * 5)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 336; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 336; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 336; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_15[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 56; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 336; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_15[((ff * 336) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 336; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 56; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_16[((ff_1 * 56) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_49(int32_t* iterator, int8_t* dummy_input_47, int8_t* weight_depth_wise_16, int8_t* weight_1x1_conv2d_linear_16, int8_t* weight_1x1_conv2d_17, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_35_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_35_var[19824]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_35_var[3024]));
  void* conv2d_nchw_let = (&(global_workspace_35_var[3024]));
  for (int32_t i1 = 0; i1 < 336; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_47[((((((iterator[0] * 8400) + (i1 * 25)) + (iterator[1] * 25)) + (i2 * 5)) + (iterator[2] * 5)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 336; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 336; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 336; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_16[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 56; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 336; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_16[((ff * 336) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 336; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 56; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_17[((ff_1 * 56) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_52(int32_t* iterator, int8_t* dummy_input_50, int8_t* weight_depth_wise_17, int8_t* weight_1x1_conv2d_linear_17, int8_t* conv2d_2, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_37_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_37_var[6048]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_37_var[3024]));
  void* conv2d_nchw_let = (&(global_workspace_37_var[3024]));
  for (int32_t i1 = 0; i1 < 336; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_50[((((((iterator[0] * 8400) + (i1 * 25)) + (iterator[1] * 25)) + (i2 * 5)) + (iterator[2] * 5)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 336; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 336; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 336; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_17[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 112; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 336; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_17[((ff * 336) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 448; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 112; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * conv2d_2[((ff_1 * 112) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_6(int32_t* iterator, int8_t* dummy_input_0, int8_t* conv2d_1, int8_t* weight_1x1_conv2d_1, int8_t* weight_depth_wise_1, int8_t* weight_1x1_conv2d_linear_1, int8_t* weight_1x1_conv2d_2, int8_t* weight_depth_wise_2, int8_t* weight_1x1_conv2d_linear_2, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* cache_buffer_var_2, int32_t* cache_cur_idx_2, int8_t* conv2d_nchw, uint8_t* global_workspace_2_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_2_var[10368]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_2_var[11080]));
  for (int32_t i1 = 0; i1 < 3; ++i1) {
    for (int32_t i2 = 0; i2 < 11; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 11) + i2)] = dummy_input_0[((((((iterator[0] * 62208) + (i1 * 20736)) + (iterator[1] * 20736)) + (i2 * 144)) + (iterator[2] * 144)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 3; ++i) {
      for (int32_t j = 0; j < 11; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 33) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 11) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((2 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 3; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 11; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 33) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t ff = 0; ff < 11; ++ff) {
    for (int32_t yy = 0; yy < 5; ++yy) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff * 5) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 3; ++rc) {
        for (int32_t ry = 0; ry < 3; ++ry) {
          for (int32_t rx = 0; rx < 3; ++rx) {
            int32_t cse_var_3 = (ry * 3);
            int32_t cse_var_2 = ((ff * 5) + yy);
            ((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] + (((int8_t*)cache_conv_input_compute_generic_let)[((((rc * 33) + (yy * 6)) + cse_var_3) + rx)] * conv2d_1[((((ff * 27) + (rc * 9)) + cse_var_3) + rx)]));
          }
        }
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 11; ++ff_1) {
    for (int32_t yy_1 = 0; yy_1 < 5; ++yy_1) {
      ((int8_t*)cache_conv_input_compute_generic_let)[((ff_1 * 5) + yy_1)] = (int8_t)0;
      for (int32_t rc_1 = 0; rc_1 < 11; ++rc_1) {
        int32_t cse_var_4 = ((ff_1 * 5) + yy_1);
        ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_4] = (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_4] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_1 * 5) + yy_1)] * weight_1x1_conv2d_1[((ff_1 * 11) + rc_1)]));
      }
    }
  }
  for (int32_t n_2 = 0; n_2 < 1; ++n_2) {
    for (int32_t i_1 = 0; i_1 < 11; ++i_1) {
      for (int32_t j_3 = 0; j_3 < 5; ++j_3) {
        for (int32_t k_2 = 0; k_2 < 1; ++k_2) {
          cache_buffer_var_1[(((i_1 * 15) + (j_3 * 3)) + (cache_cur_idx_1[3] & 1))] = ((int8_t*)cache_conv_input_compute_generic_let)[((i_1 * 5) + j_3)];
        }
      }
    }
  }
  cache_cur_idx_1[3] = (cache_cur_idx_1[3] + 1);
  if (2 <= cache_cur_idx_1[3]) {
    for (int32_t n_3 = 0; n_3 < 1; ++n_3) {
      for (int32_t j_4 = 0; j_4 < 11; ++j_4) {
        for (int32_t j_5 = 0; j_5 < 5; ++j_5) {
          for (int32_t k_3 = 0; k_3 < 3; ++k_3) {
            int32_t cse_var_5 = (((j_4 * 15) + (j_5 * 3)) + k_3);
            ((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] = cache_buffer_var_1[cse_var_5];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 11; ++c) {
    for (int32_t i_2 = 0; i_2 < 3; ++i_2) {
      ((int8_t*)cache_conv_input_compute_generic_let)[((c * 3) + i_2)] = (int8_t)0;
      for (int32_t di = 0; di < 3; ++di) {
        for (int32_t dj = 0; dj < 3; ++dj) {
          int32_t cse_var_7 = (di * 3);
          int32_t cse_var_6 = ((c * 3) + i_2);
          ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_6] = (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_6] + (((int8_t*)dyn_slice_fixed_size_let)[((((c * 15) + (i_2 * 3)) + cse_var_7) + dj)] * weight_depth_wise_1[(((c * 9) + cse_var_7) + dj)]));
        }
      }
    }
  }
  for (int32_t ff_2 = 0; ff_2 < 5; ++ff_2) {
    for (int32_t yy_2 = 0; yy_2 < 3; ++yy_2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_2 * 3) + yy_2)] = (int8_t)0;
      for (int32_t rc_2 = 0; rc_2 < 11; ++rc_2) {
        int32_t cse_var_8 = ((ff_2 * 3) + yy_2);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_8] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_8] + (((int8_t*)cache_conv_input_compute_generic_let)[((rc_2 * 3) + yy_2)] * weight_1x1_conv2d_linear_1[((ff_2 * 11) + rc_2)]));
      }
    }
  }
  for (int32_t ff_3 = 0; ff_3 < 30; ++ff_3) {
    for (int32_t yy_3 = 0; yy_3 < 3; ++yy_3) {
      ((int8_t*)cache_conv_input_compute_generic_let)[((ff_3 * 3) + yy_3)] = (int8_t)0;
      for (int32_t rc_3 = 0; rc_3 < 5; ++rc_3) {
        int32_t cse_var_9 = ((ff_3 * 3) + yy_3);
        ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_9] = (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_9] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_3 * 3) + yy_3)] * weight_1x1_conv2d_2[((ff_3 * 5) + rc_3)]));
      }
    }
  }
  for (int32_t n_4 = 0; n_4 < 1; ++n_4) {
    for (int32_t i_3 = 0; i_3 < 30; ++i_3) {
      for (int32_t j_6 = 0; j_6 < 3; ++j_6) {
        for (int32_t k_4 = 0; k_4 < 1; ++k_4) {
          cache_buffer_var_2[(((i_3 * 9) + (j_6 * 3)) + (cache_cur_idx_2[3] & 1))] = ((int8_t*)cache_conv_input_compute_generic_let)[((i_3 * 3) + j_6)];
        }
      }
    }
  }
  cache_cur_idx_2[3] = (cache_cur_idx_2[3] + 1);
  if ((2 <= cache_cur_idx_2[3]) && ((cache_cur_idx_2[3] % 2) == 0)) {
    for (int32_t n_5 = 0; n_5 < 1; ++n_5) {
      for (int32_t j_7 = 0; j_7 < 30; ++j_7) {
        for (int32_t j_8 = 0; j_8 < 3; ++j_8) {
          for (int32_t k_5 = 0; k_5 < 3; ++k_5) {
            int32_t cse_var_10 = (((j_7 * 9) + (j_8 * 3)) + k_5);
            ((int8_t*)dyn_slice_fixed_size_let)[cse_var_10] = cache_buffer_var_2[cse_var_10];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_1 = 0; c_1 < 30; ++c_1) {
    ((int8_t*)cache_conv_input_compute_generic_let)[c_1] = (int8_t)0;
    for (int32_t di_1 = 0; di_1 < 3; ++di_1) {
      for (int32_t dj_1 = 0; dj_1 < 3; ++dj_1) {
        int32_t cse_var_11 = (((c_1 * 9) + (di_1 * 3)) + dj_1);
        ((int8_t*)cache_conv_input_compute_generic_let)[c_1] = (((int8_t*)cache_conv_input_compute_generic_let)[c_1] + (((int8_t*)dyn_slice_fixed_size_let)[cse_var_11] * weight_depth_wise_2[cse_var_11]));
      }
    }
  }
  for (int32_t ff_4 = 0; ff_4 < 8; ++ff_4) {
    conv2d_nchw[ff_4] = (int8_t)0;
    for (int32_t rc_4 = 0; rc_4 < 30; ++rc_4) {
      conv2d_nchw[ff_4] = (conv2d_nchw[ff_4] + (((int8_t*)cache_conv_input_compute_generic_let)[rc_4] * weight_1x1_conv2d_linear_2[((ff_4 * 30) + rc_4)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_9(int32_t* iterator, int8_t* dummy_input_7, int8_t* weight_1x1_conv2d_3, int8_t* weight_depth_wise_3, int8_t* weight_1x1_conv2d_linear_3, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_4_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_4_var[21168]));
  void* conv2d_nchw_let = (&(global_workspace_4_var[432]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_4_var[0]));
  for (int32_t i1 = 0; i1 < 8; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_7[((((((iterator[0] * 10368) + (i1 * 1296)) + (iterator[1] * 1296)) + (i2 * 36)) + (iterator[2] * 36)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    for (int32_t yy = 0; yy < 3; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 3) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 8; ++rc) {
        int32_t cse_var_1 = ((ff * 3) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 3) + yy)] * weight_1x1_conv2d_3[((ff * 8) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 48; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)conv2d_nchw_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 48; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 48; ++c) {
    ((int8_t*)conv2d_nchw_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_3 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)conv2d_nchw_let)[c] = (((int8_t*)conv2d_nchw_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_3] * weight_depth_wise_3[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 8; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 48; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_linear_3[((ff_1 * 48) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(int8_t* data_buffer_var, int8_t* conv2d_1_buffer_var, int8_t* weight_1x1_conv2d_1_buffer_var, int8_t* weight_depth_wise_1_buffer_var, int8_t* weight_1x1_conv2d_linear_1_buffer_var, int8_t* weight_1x1_conv2d_2_buffer_var, int8_t* weight_depth_wise_2_buffer_var, int8_t* weight_1x1_conv2d_linear_2_buffer_var, int8_t* weight_1x1_conv2d_3_buffer_var, int8_t* weight_depth_wise_3_buffer_var, int8_t* weight_1x1_conv2d_linear_3_buffer_var, int8_t* weight_1x1_conv2d_4_buffer_var, int8_t* weight_depth_wise_4_buffer_var, int8_t* weight_1x1_conv2d_linear_4_buffer_var, int8_t* weight_1x1_conv2d_5_buffer_var, int8_t* weight_depth_wise_5_buffer_var, int8_t* weight_1x1_conv2d_linear_5_buffer_var, int8_t* weight_1x1_conv2d_6_buffer_var, int8_t* weight_depth_wise_6_buffer_var, int8_t* weight_1x1_conv2d_linear_6_buffer_var, int8_t* weight_1x1_conv2d_7_buffer_var, int8_t* weight_depth_wise_7_buffer_var, int8_t* weight_1x1_conv2d_linear_7_buffer_var, int8_t* weight_1x1_conv2d_8_buffer_var, int8_t* weight_depth_wise_8_buffer_var, int8_t* weight_1x1_conv2d_linear_8_buffer_var, int8_t* weight_1x1_conv2d_9_buffer_var, int8_t* weight_depth_wise_9_buffer_var, int8_t* weight_1x1_conv2d_linear_9_buffer_var, int8_t* weight_1x1_conv2d_10_buffer_var, int8_t* weight_depth_wise_10_buffer_var, int8_t* weight_1x1_conv2d_linear_10_buffer_var, int8_t* weight_1x1_conv2d_11_buffer_var, int8_t* weight_depth_wise_11_buffer_var, int8_t* weight_1x1_conv2d_linear_11_buffer_var, int8_t* weight_1x1_conv2d_12_buffer_var, int8_t* weight_depth_wise_12_buffer_var, int8_t* weight_1x1_conv2d_linear_12_buffer_var, int8_t* weight_1x1_conv2d_13_buffer_var, int8_t* weight_depth_wise_13_buffer_var, int8_t* weight_1x1_conv2d_linear_13_buffer_var, int8_t* weight_1x1_conv2d_14_buffer_var, int8_t* weight_depth_wise_14_buffer_var, int8_t* weight_1x1_conv2d_linear_14_buffer_var, int8_t* weight_1x1_conv2d_15_buffer_var, int8_t* weight_depth_wise_15_buffer_var, int8_t* weight_1x1_conv2d_linear_15_buffer_var, int8_t* weight_1x1_conv2d_16_buffer_var, int8_t* weight_depth_wise_16_buffer_var, int8_t* weight_1x1_conv2d_linear_16_buffer_var, int8_t* weight_1x1_conv2d_17_buffer_var, int8_t* weight_depth_wise_17_buffer_var, int8_t* weight_1x1_conv2d_linear_17_buffer_var, int8_t* conv2d_2_buffer_var, int8_t* output_buffer_var, uint8_t* global_workspace_0_var) {
  void* sid_55_let = (&(global_workspace_0_var[10368]));
  void* sid_54_let = (&(global_workspace_0_var[0]));
  void* sid_56_let = (&(global_workspace_0_var[0]));
  void* sid_70_let = (&(global_workspace_0_var[4968]));
  void* sid_57_let = (&(global_workspace_0_var[10692]));
  void* sid_58_let = (&(global_workspace_0_var[0]));
  void* sid_68_let = (&(global_workspace_0_var[2676]));
  void* sid_59_let = (&(global_workspace_0_var[10692]));
  void* sid_60_let = (&(global_workspace_0_var[0]));
  void* sid_61_let = (&(global_workspace_0_var[10692]));
  void* sid_62_let = (&(global_workspace_0_var[0]));
  void* sid_63_let = (&(global_workspace_0_var[10692]));
  void* sid_64_let = (&(global_workspace_0_var[0]));
  void* sid_65_let = (&(global_workspace_0_var[16040]));
  void* sid_66_let = (&(global_workspace_0_var[0]));
  void* sid_67_let = (&(global_workspace_0_var[18716]));
  void* sid_69_let = (&(global_workspace_0_var[0]));
  void* sid_71_let = (&(global_workspace_0_var[16]));
  void* sid_72_let = (&(global_workspace_0_var[12872]));
  void* sid_73_let = (&(global_workspace_0_var[3024]));
  void* sid_74_let = (&(global_workspace_0_var[11424]));
  if (tvmgen_default_fused_fusion_iter_worker(data_buffer_var, conv2d_1_buffer_var, weight_1x1_conv2d_1_buffer_var, weight_depth_wise_1_buffer_var, weight_1x1_conv2d_linear_1_buffer_var, weight_1x1_conv2d_2_buffer_var, weight_depth_wise_2_buffer_var, weight_1x1_conv2d_linear_2_buffer_var, sid_54_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_1(sid_54_let, weight_1x1_conv2d_3_buffer_var, weight_depth_wise_3_buffer_var, weight_1x1_conv2d_linear_3_buffer_var, sid_55_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_2(sid_55_let, weight_1x1_conv2d_4_buffer_var, weight_depth_wise_4_buffer_var, weight_1x1_conv2d_linear_4_buffer_var, sid_56_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_3(sid_56_let, weight_1x1_conv2d_5_buffer_var, weight_depth_wise_5_buffer_var, weight_1x1_conv2d_linear_5_buffer_var, sid_57_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_4(sid_57_let, weight_1x1_conv2d_6_buffer_var, weight_depth_wise_6_buffer_var, weight_1x1_conv2d_linear_6_buffer_var, weight_1x1_conv2d_7_buffer_var, weight_depth_wise_7_buffer_var, weight_1x1_conv2d_linear_7_buffer_var, weight_1x1_conv2d_8_buffer_var, sid_58_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_5(sid_58_let, weight_depth_wise_8_buffer_var, weight_1x1_conv2d_linear_8_buffer_var, sid_59_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d(sid_59_let, weight_1x1_conv2d_9_buffer_var, sid_60_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_6(sid_60_let, weight_depth_wise_9_buffer_var, weight_1x1_conv2d_linear_9_buffer_var, sid_61_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_1(sid_61_let, weight_1x1_conv2d_10_buffer_var, sid_62_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_7(sid_62_let, weight_depth_wise_10_buffer_var, weight_1x1_conv2d_linear_10_buffer_var, sid_63_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_2(sid_63_let, weight_1x1_conv2d_11_buffer_var, sid_64_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_8(sid_64_let, weight_depth_wise_11_buffer_var, weight_1x1_conv2d_linear_11_buffer_var, sid_65_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_3(sid_65_let, weight_1x1_conv2d_12_buffer_var, sid_66_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_9(sid_66_let, weight_depth_wise_12_buffer_var, weight_1x1_conv2d_linear_12_buffer_var, sid_67_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_4(sid_67_let, weight_1x1_conv2d_13_buffer_var, sid_68_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_10(sid_68_let, weight_depth_wise_13_buffer_var, weight_1x1_conv2d_linear_13_buffer_var, sid_69_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_5(sid_69_let, weight_1x1_conv2d_14_buffer_var, sid_70_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_6(sid_70_let, weight_depth_wise_14_buffer_var, sid_71_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_11(sid_71_let, weight_1x1_conv2d_linear_14_buffer_var, weight_1x1_conv2d_15_buffer_var, sid_72_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_12(sid_72_let, weight_depth_wise_15_buffer_var, weight_1x1_conv2d_linear_15_buffer_var, weight_1x1_conv2d_16_buffer_var, sid_73_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_13(sid_73_let, weight_depth_wise_16_buffer_var, weight_1x1_conv2d_linear_16_buffer_var, weight_1x1_conv2d_17_buffer_var, sid_74_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_14(sid_74_let, weight_depth_wise_17_buffer_var, weight_1x1_conv2d_linear_17_buffer_var, conv2d_2_buffer_var, output_buffer_var, global_workspace_0_var) != 0 ) return -1;
  return 0;
}


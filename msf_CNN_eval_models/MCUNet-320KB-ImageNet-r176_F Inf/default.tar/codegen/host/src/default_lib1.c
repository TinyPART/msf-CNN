// tvm target: c -keys=partial_conv,arm_cpu,cpu -mcpu=cortex-m4+nodsp -model=nrf52840
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* p7, int8_t* p8, int8_t* p9, int8_t* p10, int8_t* p11, int8_t* p12, int8_t* p13, int8_t* p14, int8_t* p15, int8_t* p16, int8_t* p17, int8_t* p18, int8_t* fusion_iter_worker, uint8_t* global_workspace_1_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_1(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_3_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_10(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_26_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_2(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* fusion_iter_worker, uint8_t* global_workspace_5_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_3(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* fusion_iter_worker, uint8_t* global_workspace_7_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_4(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_9_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_5(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_12_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_6(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_14_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_7(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_17_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_8(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_20_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_9(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_24_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_11_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_1(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_16_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_2(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_19_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_3(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_22_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_4(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_23_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_5(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_28_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_6(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_29_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_17(int32_t* iterator, int8_t* dummy_input_0, int8_t* conv2d_1, int8_t* weight_depth_wise_1, int8_t* conv2d_2, int8_t* weight_1x1_conv2d_32, int8_t* weight_depth_wise_32, int8_t* weight_1x1_conv2d_linear_32, int8_t* weight_1x1_conv2d_33, int8_t* weight_depth_wise_33, int8_t* weight_1x1_conv2d_linear_33, int8_t* weight_1x1_conv2d_34, int8_t* weight_depth_wise_34, int8_t* weight_1x1_conv2d_linear_34, int8_t* weight_1x1_conv2d_35, int8_t* weight_depth_wise_35, int8_t* weight_1x1_conv2d_linear_35, int8_t* weight_1x1_conv2d_36, int8_t* weight_depth_wise_36, int8_t* weight_1x1_conv2d_linear_36, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* cache_buffer_var_2, int32_t* cache_cur_idx_2, int8_t* cache_buffer_var_3, int32_t* cache_cur_idx_3, int8_t* cache_buffer_var_4, int32_t* cache_cur_idx_4, int8_t* cache_buffer_var_5, int32_t* cache_cur_idx_5, int8_t* cache_buffer_var_6, int32_t* cache_cur_idx_6, int8_t* conv2d_nchw, uint8_t* global_workspace_2_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_20(int32_t* iterator, int8_t* dummy_input_18, int8_t* weight_1x1_conv2d_37, int8_t* weight_depth_wise_37, int8_t* weight_1x1_conv2d_linear_37, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_4_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_26(int32_t* iterator, int8_t* dummy_input_21, int8_t* weight_1x1_conv2d_38, int8_t* weight_depth_wise_38, int8_t* weight_1x1_conv2d_linear_38, int8_t* weight_1x1_conv2d_39, int8_t* weight_depth_wise_39, int8_t* weight_1x1_conv2d_linear_39, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* conv2d_nchw, uint8_t* global_workspace_6_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_30(int32_t* iterator, int8_t* dummy_input_27, int8_t* weight_1x1_conv2d_40, int8_t* weight_depth_wise_40, int8_t* weight_1x1_conv2d_linear_40, int8_t* weight_1x1_conv2d_41, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_8_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_32(int32_t* iterator, int8_t* dummy_input_31, int8_t* weight_depth_wise_41, int8_t* weight_1x1_conv2d_linear_41, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_10_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_35(int32_t* iterator, int8_t* dummy_input_34, int8_t* weight_depth_wise_42, int8_t* weight_1x1_conv2d_linear_42, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_13_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_38(int32_t* iterator, int8_t* dummy_input_36, int8_t* weight_1x1_conv2d_43, int8_t* weight_depth_wise_43, int8_t* weight_1x1_conv2d_linear_43, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_15_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_41(int32_t* iterator, int8_t* dummy_input_40, int8_t* weight_depth_wise_44, int8_t* weight_1x1_conv2d_linear_44, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_18_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_44(int32_t* iterator, int8_t* dummy_input_43, int8_t* weight_depth_wise_45, int8_t* weight_1x1_conv2d_linear_45, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_21_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_48(int32_t* iterator, int8_t* dummy_input_47, int8_t* weight_1x1_conv2d_linear_46, int8_t* weight_1x1_conv2d_47, int8_t* conv2d_nchw, uint8_t* global_workspace_25_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_51(int32_t* iterator, int8_t* dummy_input_49, int8_t* weight_depth_wise_47, int8_t* weight_1x1_conv2d_linear_47, int8_t* weight_1x1_conv2d_48, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_27_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(int8_t* data_buffer_var, int8_t* conv2d_1_buffer_var, int8_t* weight_depth_wise_1_buffer_var, int8_t* conv2d_2_buffer_var, int8_t* weight_1x1_conv2d_32_buffer_var, int8_t* weight_depth_wise_32_buffer_var, int8_t* weight_1x1_conv2d_linear_32_buffer_var, int8_t* weight_1x1_conv2d_33_buffer_var, int8_t* weight_depth_wise_33_buffer_var, int8_t* weight_1x1_conv2d_linear_33_buffer_var, int8_t* weight_1x1_conv2d_34_buffer_var, int8_t* weight_depth_wise_34_buffer_var, int8_t* weight_1x1_conv2d_linear_34_buffer_var, int8_t* weight_1x1_conv2d_35_buffer_var, int8_t* weight_depth_wise_35_buffer_var, int8_t* weight_1x1_conv2d_linear_35_buffer_var, int8_t* weight_1x1_conv2d_36_buffer_var, int8_t* weight_depth_wise_36_buffer_var, int8_t* weight_1x1_conv2d_linear_36_buffer_var, int8_t* weight_1x1_conv2d_37_buffer_var, int8_t* weight_depth_wise_37_buffer_var, int8_t* weight_1x1_conv2d_linear_37_buffer_var, int8_t* weight_1x1_conv2d_38_buffer_var, int8_t* weight_depth_wise_38_buffer_var, int8_t* weight_1x1_conv2d_linear_38_buffer_var, int8_t* weight_1x1_conv2d_39_buffer_var, int8_t* weight_depth_wise_39_buffer_var, int8_t* weight_1x1_conv2d_linear_39_buffer_var, int8_t* weight_1x1_conv2d_40_buffer_var, int8_t* weight_depth_wise_40_buffer_var, int8_t* weight_1x1_conv2d_linear_40_buffer_var, int8_t* weight_1x1_conv2d_41_buffer_var, int8_t* weight_depth_wise_41_buffer_var, int8_t* weight_1x1_conv2d_linear_41_buffer_var, int8_t* weight_1x1_conv2d_42_buffer_var, int8_t* weight_depth_wise_42_buffer_var, int8_t* weight_1x1_conv2d_linear_42_buffer_var, int8_t* weight_1x1_conv2d_43_buffer_var, int8_t* weight_depth_wise_43_buffer_var, int8_t* weight_1x1_conv2d_linear_43_buffer_var, int8_t* weight_1x1_conv2d_44_buffer_var, int8_t* weight_depth_wise_44_buffer_var, int8_t* weight_1x1_conv2d_linear_44_buffer_var, int8_t* weight_1x1_conv2d_45_buffer_var, int8_t* weight_depth_wise_45_buffer_var, int8_t* weight_1x1_conv2d_linear_45_buffer_var, int8_t* weight_1x1_conv2d_46_buffer_var, int8_t* weight_depth_wise_46_buffer_var, int8_t* weight_1x1_conv2d_linear_46_buffer_var, int8_t* weight_1x1_conv2d_47_buffer_var, int8_t* weight_depth_wise_47_buffer_var, int8_t* weight_1x1_conv2d_linear_47_buffer_var, int8_t* weight_1x1_conv2d_48_buffer_var, int8_t* weight_depth_wise_48_buffer_var, int8_t* weight_1x1_conv2d_linear_48_buffer_var, int8_t* output_buffer_var, uint8_t* global_workspace_0_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* p7, int8_t* p8, int8_t* p9, int8_t* p10, int8_t* p11, int8_t* p12, int8_t* p13, int8_t* p14, int8_t* p15, int8_t* p16, int8_t* p17, int8_t* p18, int8_t* fusion_iter_worker, uint8_t* global_workspace_1_var) {
  void* iterator_let = (&(global_workspace_1_var[51020]));
  void* iteratee_output_let = (&(global_workspace_1_var[50996]));
  void* bg_ind_let = (&(global_workspace_1_var[51148]));
  void* cache_buffer_var_let = (&(global_workspace_1_var[49976]));
  void* cache_cur_idx_let = (&(global_workspace_1_var[51132]));
  void* cache_buffer_var_let_1 = (&(global_workspace_1_var[48008]));
  void* cache_cur_idx_let_1 = (&(global_workspace_1_var[51116]));
  void* cache_buffer_var_let_2 = (&(global_workspace_1_var[28416]));
  void* cache_cur_idx_let_2 = (&(global_workspace_1_var[51100]));
  void* cache_buffer_var_let_3 = (&(global_workspace_1_var[39048]));
  void* cache_cur_idx_let_3 = (&(global_workspace_1_var[51084]));
  void* cache_buffer_var_let_4 = (&(global_workspace_1_var[20016]));
  void* cache_cur_idx_let_4 = (&(global_workspace_1_var[51068]));
  void* cache_buffer_var_let_5 = (&(global_workspace_1_var[43128]));
  void* cache_cur_idx_let_5 = (&(global_workspace_1_var[51052]));
  void* cache_buffer_var_let_6 = (&(global_workspace_1_var[46008]));
  void* cache_cur_idx_let_6 = (&(global_workspace_1_var[51036]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_1)[0] = 0;
  ((int32_t*)cache_cur_idx_let_1)[1] = 0;
  ((int32_t*)cache_cur_idx_let_1)[2] = 0;
  ((int32_t*)cache_cur_idx_let_1)[3] = 0;
  ((int8_t*)cache_buffer_var_let_2)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_2)[0] = 0;
  ((int32_t*)cache_cur_idx_let_2)[1] = 0;
  ((int32_t*)cache_cur_idx_let_2)[2] = 0;
  ((int32_t*)cache_cur_idx_let_2)[3] = 0;
  ((int8_t*)cache_buffer_var_let_3)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_3)[0] = 0;
  ((int32_t*)cache_cur_idx_let_3)[1] = 0;
  ((int32_t*)cache_cur_idx_let_3)[2] = 0;
  ((int32_t*)cache_cur_idx_let_3)[3] = 0;
  ((int8_t*)cache_buffer_var_let_4)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_4)[0] = 0;
  ((int32_t*)cache_cur_idx_let_4)[1] = 0;
  ((int32_t*)cache_cur_idx_let_4)[2] = 0;
  ((int32_t*)cache_cur_idx_let_4)[3] = 0;
  ((int8_t*)cache_buffer_var_let_5)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_5)[0] = 0;
  ((int32_t*)cache_cur_idx_let_5)[1] = 0;
  ((int32_t*)cache_cur_idx_let_5)[2] = 0;
  ((int32_t*)cache_cur_idx_let_5)[3] = 0;
  ((int8_t*)cache_buffer_var_let_6)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_6)[0] = 0;
  ((int32_t*)cache_cur_idx_let_6)[1] = 0;
  ((int32_t*)cache_cur_idx_let_6)[2] = 0;
  ((int32_t*)cache_cur_idx_let_6)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 21))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 21))) { break; }
      if (tvmgen_default_iteratee_17(iterator_let, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, cache_buffer_var_let, cache_cur_idx_let, cache_buffer_var_let_1, cache_cur_idx_let_1, cache_buffer_var_let_2, cache_cur_idx_let_2, cache_buffer_var_let_3, cache_cur_idx_let_3, cache_buffer_var_let_4, cache_cur_idx_let_4, cache_buffer_var_let_5, cache_cur_idx_let_5, cache_buffer_var_let_6, cache_cur_idx_let_6, iteratee_output_let, global_workspace_1_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 24; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 11616) + (i * 484)) + (((int32_t*)bg_ind_let)[1] * 484)) + (((int32_t*)bg_ind_let)[2] * 22)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 21) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 8);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_1)[0] = 0;
    ((int32_t*)cache_cur_idx_let_1)[1] = 0;
    ((int32_t*)cache_cur_idx_let_1)[2] = 0;
    ((int32_t*)cache_cur_idx_let_1)[3] = 0;
    ((int8_t*)cache_buffer_var_let_2)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_2)[0] = 0;
    ((int32_t*)cache_cur_idx_let_2)[1] = 0;
    ((int32_t*)cache_cur_idx_let_2)[2] = 0;
    ((int32_t*)cache_cur_idx_let_2)[3] = 0;
    ((int8_t*)cache_buffer_var_let_3)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_3)[0] = 0;
    ((int32_t*)cache_cur_idx_let_3)[1] = 0;
    ((int32_t*)cache_cur_idx_let_3)[2] = 0;
    ((int32_t*)cache_cur_idx_let_3)[3] = 0;
    ((int8_t*)cache_buffer_var_let_4)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_4)[0] = 0;
    ((int32_t*)cache_cur_idx_let_4)[1] = 0;
    ((int32_t*)cache_cur_idx_let_4)[2] = 0;
    ((int32_t*)cache_cur_idx_let_4)[3] = 0;
    ((int8_t*)cache_buffer_var_let_5)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_5)[0] = 0;
    ((int32_t*)cache_cur_idx_let_5)[1] = 0;
    ((int32_t*)cache_cur_idx_let_5)[2] = 0;
    ((int32_t*)cache_cur_idx_let_5)[3] = 0;
    ((int8_t*)cache_buffer_var_let_6)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_6)[0] = 0;
    ((int32_t*)cache_cur_idx_let_6)[1] = 0;
    ((int32_t*)cache_cur_idx_let_6)[2] = 0;
    ((int32_t*)cache_cur_idx_let_6)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 8);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_1(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_3_var) {
  void* iterator_let = (&(global_workspace_3_var[26376]));
  void* iteratee_output_let = (&(global_workspace_3_var[26352]));
  void* bg_ind_let = (&(global_workspace_3_var[26408]));
  void* cache_buffer_var_let = (&(global_workspace_3_var[23232]));
  void* cache_cur_idx_let = (&(global_workspace_3_var[26392]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 21))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 21))) { break; }
      if (tvmgen_default_iteratee_20(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_3_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 24; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 11616) + (i * 484)) + (((int32_t*)bg_ind_let)[1] * 484)) + (((int32_t*)bg_ind_let)[2] * 22)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 21) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_10(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_26_var) {
  void* iterator_let = (&(global_workspace_26_var[36192]));
  void* iteratee_output_let = (&(global_workspace_26_var[35712]));
  void* bg_ind_let = (&(global_workspace_26_var[36224]));
  void* cache_buffer_var_let = (&(global_workspace_26_var[31104]));
  void* cache_cur_idx_let = (&(global_workspace_26_var[36208]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 5))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 5))) { break; }
      if (tvmgen_default_iteratee_51(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_26_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 480; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 17280) + (i * 36)) + (((int32_t*)bg_ind_let)[1] * 36)) + (((int32_t*)bg_ind_let)[2] * 6)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 5) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_2(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* fusion_iter_worker, uint8_t* global_workspace_5_var) {
  void* iterator_let = (&(global_workspace_5_var[10528]));
  void* iteratee_output_let = (&(global_workspace_5_var[10488]));
  void* bg_ind_let = (&(global_workspace_5_var[10576]));
  void* cache_buffer_var_let = (&(global_workspace_5_var[0]));
  void* cache_cur_idx_let = (&(global_workspace_5_var[10544]));
  void* cache_buffer_var_let_1 = (&(global_workspace_5_var[8400]));
  void* cache_cur_idx_let_1 = (&(global_workspace_5_var[10560]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_1)[0] = 0;
  ((int32_t*)cache_cur_idx_let_1)[1] = 0;
  ((int32_t*)cache_cur_idx_let_1)[2] = 0;
  ((int32_t*)cache_cur_idx_let_1)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_26(iterator_let, p0, p1, p2, p3, p4, p5, p6, cache_buffer_var_let, cache_cur_idx_let, cache_buffer_var_let_1, cache_cur_idx_let_1, iteratee_output_let, global_workspace_5_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 40; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 4840) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_1)[0] = 0;
    ((int32_t*)cache_cur_idx_let_1)[1] = 0;
    ((int32_t*)cache_cur_idx_let_1)[2] = 0;
    ((int32_t*)cache_cur_idx_let_1)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_3(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* fusion_iter_worker, uint8_t* global_workspace_7_var) {
  void* iterator_let = (&(global_workspace_7_var[43320]));
  void* iteratee_output_let = (&(global_workspace_7_var[43160]));
  void* bg_ind_let = (&(global_workspace_7_var[43352]));
  void* cache_buffer_var_let = (&(global_workspace_7_var[19360]));
  void* cache_cur_idx_let = (&(global_workspace_7_var[43336]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_30(iterator_let, p0, p1, p2, p3, p4, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_7_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 160; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 19360) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_4(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_9_var) {
  void* iterator_let = (&(global_workspace_9_var[29040]));
  void* iteratee_output_let = (&(global_workspace_9_var[24160]));
  void* bg_ind_let = (&(global_workspace_9_var[29072]));
  void* cache_buffer_var_let = (&(global_workspace_9_var[19360]));
  void* cache_cur_idx_let = (&(global_workspace_9_var[29056]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_32(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_9_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 40; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 4840) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_5(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_12_var) {
  void* iterator_let = (&(global_workspace_12_var[36056]));
  void* iteratee_output_let = (&(global_workspace_12_var[36008]));
  void* bg_ind_let = (&(global_workspace_12_var[36088]));
  void* cache_buffer_var_let = (&(global_workspace_12_var[30008]));
  void* cache_cur_idx_let = (&(global_workspace_12_var[36072]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_35(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_12_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 48; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 5808) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_6(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_14_var) {
  void* iterator_let = (&(global_workspace_14_var[23904]));
  void* iteratee_output_let = (&(global_workspace_14_var[23856]));
  void* bg_ind_let = (&(global_workspace_14_var[23936]));
  void* cache_buffer_var_let = (&(global_workspace_14_var[0]));
  void* cache_cur_idx_let = (&(global_workspace_14_var[23920]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_38(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_14_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 48; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 5808) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_7(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_17_var) {
  void* iterator_let = (&(global_workspace_17_var[31968]));
  void* iteratee_output_let = (&(global_workspace_17_var[31920]));
  void* bg_ind_let = (&(global_workspace_17_var[32000]));
  void* cache_buffer_var_let = (&(global_workspace_17_var[29040]));
  void* cache_cur_idx_let = (&(global_workspace_17_var[31984]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_41(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_17_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 48; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 5808) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_8(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_20_var) {
  void* iterator_let = (&(global_workspace_20_var[41856]));
  void* iteratee_output_let = (&(global_workspace_20_var[41760]));
  void* bg_ind_let = (&(global_workspace_20_var[41888]));
  void* cache_buffer_var_let = (&(global_workspace_20_var[38304]));
  void* cache_cur_idx_let = (&(global_workspace_20_var[41872]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 5))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 5))) { break; }
      if (tvmgen_default_iteratee_44(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_20_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 96; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 3456) + (i * 36)) + (((int32_t*)bg_ind_let)[1] * 36)) + (((int32_t*)bg_ind_let)[2] * 6)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 5) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_9(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_24_var) {
  void* iterator_let = (&(global_workspace_24_var[31968]));
  void* iteratee_output_let = (&(global_workspace_24_var[31584]));
  void* bg_ind_let = (&(global_workspace_24_var[31984]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 5))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 5))) { break; }
      if (tvmgen_default_iteratee_48(iterator_let, p0, p1, p2, iteratee_output_let, global_workspace_24_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 384; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 13824) + (i * 36)) + (((int32_t*)bg_ind_let)[1] * 36)) + (((int32_t*)bg_ind_let)[2] * 6)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 5) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_11_var) {
  for (int32_t ff = 0; ff < 200; ++ff) {
    for (int32_t yy = 0; yy < 11; ++yy) {
      for (int32_t xx = 0; xx < 11; ++xx) {
        conv2d_nchw[(((ff * 121) + (yy * 11)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 40; ++rc) {
          int32_t cse_var_2 = (yy * 11);
          int32_t cse_var_1 = (((ff * 121) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 121) + cse_var_2) + xx)] * p1[((ff * 40) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_1(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_16_var) {
  for (int32_t ff = 0; ff < 240; ++ff) {
    for (int32_t yy = 0; yy < 11; ++yy) {
      for (int32_t xx = 0; xx < 11; ++xx) {
        conv2d_nchw[(((ff * 121) + (yy * 11)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 48; ++rc) {
          int32_t cse_var_2 = (yy * 11);
          int32_t cse_var_1 = (((ff * 121) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 121) + cse_var_2) + xx)] * p1[((ff * 48) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_2(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_19_var) {
  for (int32_t ff = 0; ff < 288; ++ff) {
    for (int32_t yy = 0; yy < 11; ++yy) {
      for (int32_t xx = 0; xx < 11; ++xx) {
        conv2d_nchw[(((ff * 121) + (yy * 11)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 48; ++rc) {
          int32_t cse_var_2 = (yy * 11);
          int32_t cse_var_1 = (((ff * 121) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 121) + cse_var_2) + xx)] * p1[((ff * 48) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_3(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_22_var) {
  for (int32_t ff = 0; ff < 480; ++ff) {
    for (int32_t yy = 0; yy < 6; ++yy) {
      for (int32_t xx = 0; xx < 6; ++xx) {
        conv2d_nchw[(((ff * 36) + (yy * 6)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 96; ++rc) {
          int32_t cse_var_2 = (yy * 6);
          int32_t cse_var_1 = (((ff * 36) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 36) + cse_var_2) + xx)] * p1[((ff * 96) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_4(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_23_var) {
  for (int32_t c = 0; c < 480; ++c) {
    for (int32_t i = 0; i < 6; ++i) {
      for (int32_t j = 0; j < 6; ++j) {
        DepthwiseConv2d[(((c * 36) + (i * 6)) + j)] = (int8_t)0;
        for (int32_t di = 0; di < 7; ++di) {
          for (int32_t dj = 0; dj < 7; ++dj) {
            int32_t cse_var_2 = (c * 36);
            int32_t cse_var_1 = ((cse_var_2 + (i * 6)) + j);
            DepthwiseConv2d[cse_var_1] = (DepthwiseConv2d[cse_var_1] + (p0[((cse_var_2 + (((i + di) % 6) * 6)) + ((j + dj) % 6))] * p1[(((c * 49) + (di * 7)) + dj)]));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_5(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_28_var) {
  for (int32_t c = 0; c < 480; ++c) {
    for (int32_t i = 0; i < 6; ++i) {
      for (int32_t j = 0; j < 6; ++j) {
        DepthwiseConv2d[(((c * 36) + (i * 6)) + j)] = (int8_t)0;
        for (int32_t di = 0; di < 7; ++di) {
          for (int32_t dj = 0; dj < 7; ++dj) {
            int32_t cse_var_2 = (c * 36);
            int32_t cse_var_1 = ((cse_var_2 + (i * 6)) + j);
            DepthwiseConv2d[cse_var_1] = (DepthwiseConv2d[cse_var_1] + (p0[((cse_var_2 + (((i + di) % 6) * 6)) + ((j + dj) % 6))] * p1[(((c * 49) + (di * 7)) + dj)]));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_6(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_29_var) {
  for (int32_t ff = 0; ff < 160; ++ff) {
    for (int32_t yy = 0; yy < 6; ++yy) {
      for (int32_t xx = 0; xx < 6; ++xx) {
        conv2d_nchw[(((ff * 36) + (yy * 6)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 480; ++rc) {
          int32_t cse_var_2 = (yy * 6);
          int32_t cse_var_1 = (((ff * 36) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 36) + cse_var_2) + xx)] * p1[((ff * 480) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_17(int32_t* iterator, int8_t* dummy_input_0, int8_t* conv2d_1, int8_t* weight_depth_wise_1, int8_t* conv2d_2, int8_t* weight_1x1_conv2d_32, int8_t* weight_depth_wise_32, int8_t* weight_1x1_conv2d_linear_32, int8_t* weight_1x1_conv2d_33, int8_t* weight_depth_wise_33, int8_t* weight_1x1_conv2d_linear_33, int8_t* weight_1x1_conv2d_34, int8_t* weight_depth_wise_34, int8_t* weight_1x1_conv2d_linear_34, int8_t* weight_1x1_conv2d_35, int8_t* weight_depth_wise_35, int8_t* weight_1x1_conv2d_linear_35, int8_t* weight_1x1_conv2d_36, int8_t* weight_depth_wise_36, int8_t* weight_1x1_conv2d_linear_36, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* cache_buffer_var_2, int32_t* cache_cur_idx_2, int8_t* cache_buffer_var_3, int32_t* cache_cur_idx_3, int8_t* cache_buffer_var_4, int32_t* cache_cur_idx_4, int8_t* cache_buffer_var_5, int32_t* cache_cur_idx_5, int8_t* cache_buffer_var_6, int32_t* cache_cur_idx_6, int8_t* conv2d_nchw, uint8_t* global_workspace_2_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_2_var[34968]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_2_var[11616]));
  void* conv2d_nchw_let = (&(global_workspace_2_var[50724]));
  for (int32_t i1 = 0; i1 < 3; ++i1) {
    for (int32_t i2 = 0; i2 < 83; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 83) + i2)] = dummy_input_0[((((((iterator[0] * 92928) + (i1 * 30976)) + (iterator[1] * 30976)) + (i2 * 176)) + (iterator[2] * 176)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 3; ++i) {
      for (int32_t j = 0; j < 83; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 249) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 83) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((2 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 3; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 83; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 249) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t ff = 0; ff < 16; ++ff) {
    for (int32_t yy = 0; yy < 41; ++yy) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff * 41) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 3; ++rc) {
        for (int32_t ry = 0; ry < 3; ++ry) {
          for (int32_t rx = 0; rx < 3; ++rx) {
            int32_t cse_var_3 = (ry * 3);
            int32_t cse_var_2 = ((ff * 41) + yy);
            ((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] + (((int8_t*)cache_conv_input_compute_generic_let)[((((rc * 249) + (yy * 6)) + cse_var_3) + rx)] * conv2d_1[((((ff * 27) + (rc * 9)) + cse_var_3) + rx)]));
          }
        }
      }
    }
  }
  for (int32_t n_2 = 0; n_2 < 1; ++n_2) {
    for (int32_t i_1 = 0; i_1 < 16; ++i_1) {
      for (int32_t j_3 = 0; j_3 < 41; ++j_3) {
        for (int32_t k_2 = 0; k_2 < 1; ++k_2) {
          cache_buffer_var_1[(((i_1 * 123) + (j_3 * 3)) + (cache_cur_idx_1[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i_1 * 41) + j_3)];
        }
      }
    }
  }
  cache_cur_idx_1[3] = (cache_cur_idx_1[3] + 1);
  if (2 <= cache_cur_idx_1[3]) {
    for (int32_t n_3 = 0; n_3 < 1; ++n_3) {
      for (int32_t j_4 = 0; j_4 < 16; ++j_4) {
        for (int32_t j_5 = 0; j_5 < 41; ++j_5) {
          for (int32_t k_3 = 0; k_3 < 3; ++k_3) {
            int32_t cse_var_4 = (((j_4 * 123) + (j_5 * 3)) + k_3);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_4] = cache_buffer_var_1[cse_var_4];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 16; ++c) {
    for (int32_t i_2 = 0; i_2 < 39; ++i_2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((c * 39) + i_2)] = (int8_t)0;
      for (int32_t di = 0; di < 3; ++di) {
        for (int32_t dj = 0; dj < 3; ++dj) {
          int32_t cse_var_6 = (di * 3);
          int32_t cse_var_5 = ((c * 39) + i_2);
          ((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] + (((int8_t*)cache_conv_input_compute_generic_let)[((((c * 123) + (i_2 * 3)) + cse_var_6) + dj)] * weight_depth_wise_1[(((c * 9) + cse_var_6) + dj)]));
        }
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 8; ++ff_1) {
    for (int32_t yy_1 = 0; yy_1 < 39; ++yy_1) {
      ((int8_t*)cache_conv_input_compute_generic_let)[((ff_1 * 39) + yy_1)] = (int8_t)0;
      for (int32_t rc_1 = 0; rc_1 < 16; ++rc_1) {
        int32_t cse_var_7 = ((ff_1 * 39) + yy_1);
        ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_7] = (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_7] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_1 * 39) + yy_1)] * conv2d_2[((ff_1 * 16) + rc_1)]));
      }
    }
  }
  for (int32_t ff_2 = 0; ff_2 < 24; ++ff_2) {
    for (int32_t yy_2 = 0; yy_2 < 39; ++yy_2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_2 * 39) + yy_2)] = (int8_t)0;
      for (int32_t rc_2 = 0; rc_2 < 8; ++rc_2) {
        int32_t cse_var_8 = ((ff_2 * 39) + yy_2);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_8] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_8] + (((int8_t*)cache_conv_input_compute_generic_let)[((rc_2 * 39) + yy_2)] * weight_1x1_conv2d_32[((ff_2 * 8) + rc_2)]));
      }
    }
  }
  for (int32_t n_4 = 0; n_4 < 1; ++n_4) {
    for (int32_t i_3 = 0; i_3 < 24; ++i_3) {
      for (int32_t j_6 = 0; j_6 < 39; ++j_6) {
        for (int32_t k_4 = 0; k_4 < 1; ++k_4) {
          cache_buffer_var_2[(((i_3 * 273) + (j_6 * 7)) + ((cache_cur_idx_2[3] % 6) + (6 & ((cache_cur_idx_2[3] % 6) >> 31))))] = ((int8_t*)dyn_slice_fixed_size_let)[((i_3 * 39) + j_6)];
        }
      }
    }
  }
  cache_cur_idx_2[3] = (cache_cur_idx_2[3] + 1);
  if ((6 <= cache_cur_idx_2[3]) && ((cache_cur_idx_2[3] % 2) == 0)) {
    for (int32_t n_5 = 0; n_5 < 1; ++n_5) {
      for (int32_t j_7 = 0; j_7 < 24; ++j_7) {
        for (int32_t j_8 = 0; j_8 < 39; ++j_8) {
          for (int32_t k_5 = 0; k_5 < 7; ++k_5) {
            int32_t cse_var_9 = (((j_7 * 273) + (j_8 * 7)) + k_5);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_9] = cache_buffer_var_2[cse_var_9];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_1 = 0; c_1 < 24; ++c_1) {
    for (int32_t i_4 = 0; i_4 < 17; ++i_4) {
      ((int8_t*)dyn_slice_fixed_size_let)[((c_1 * 17) + i_4)] = (int8_t)0;
      for (int32_t di_1 = 0; di_1 < 7; ++di_1) {
        for (int32_t dj_1 = 0; dj_1 < 7; ++dj_1) {
          int32_t cse_var_11 = (di_1 * 7);
          int32_t cse_var_10 = ((c_1 * 17) + i_4);
          ((int8_t*)dyn_slice_fixed_size_let)[cse_var_10] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_10] + (((int8_t*)cache_conv_input_compute_generic_let)[((((c_1 * 273) + (i_4 * 14)) + cse_var_11) + dj_1)] * weight_depth_wise_32[(((c_1 * 49) + cse_var_11) + dj_1)]));
        }
      }
    }
  }
  for (int32_t ff_3 = 0; ff_3 < 16; ++ff_3) {
    for (int32_t yy_3 = 0; yy_3 < 17; ++yy_3) {
      ((int8_t*)conv2d_nchw_let)[((ff_3 * 17) + yy_3)] = (int8_t)0;
      for (int32_t rc_3 = 0; rc_3 < 24; ++rc_3) {
        int32_t cse_var_12 = ((ff_3 * 17) + yy_3);
        ((int8_t*)conv2d_nchw_let)[cse_var_12] = (((int8_t*)conv2d_nchw_let)[cse_var_12] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_3 * 17) + yy_3)] * weight_1x1_conv2d_linear_32[((ff_3 * 24) + rc_3)]));
      }
    }
  }
  for (int32_t ff_4 = 0; ff_4 < 80; ++ff_4) {
    for (int32_t yy_4 = 0; yy_4 < 17; ++yy_4) {
      ((int8_t*)cache_conv_input_compute_generic_let)[((ff_4 * 17) + yy_4)] = (int8_t)0;
      for (int32_t rc_4 = 0; rc_4 < 16; ++rc_4) {
        int32_t cse_var_13 = ((ff_4 * 17) + yy_4);
        ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_13] = (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_13] + (((int8_t*)conv2d_nchw_let)[((rc_4 * 17) + yy_4)] * weight_1x1_conv2d_33[((ff_4 * 16) + rc_4)]));
      }
    }
  }
  for (int32_t n_6 = 0; n_6 < 1; ++n_6) {
    for (int32_t i_5 = 0; i_5 < 80; ++i_5) {
      for (int32_t j_9 = 0; j_9 < 17; ++j_9) {
        for (int32_t k_6 = 0; k_6 < 1; ++k_6) {
          cache_buffer_var_3[(((i_5 * 51) + (j_9 * 3)) + (cache_cur_idx_3[3] & 1))] = ((int8_t*)cache_conv_input_compute_generic_let)[((i_5 * 17) + j_9)];
        }
      }
    }
  }
  cache_cur_idx_3[3] = (cache_cur_idx_3[3] + 1);
  if (2 <= cache_cur_idx_3[3]) {
    for (int32_t n_7 = 0; n_7 < 1; ++n_7) {
      for (int32_t j_10 = 0; j_10 < 80; ++j_10) {
        for (int32_t j_11 = 0; j_11 < 17; ++j_11) {
          for (int32_t k_7 = 0; k_7 < 3; ++k_7) {
            int32_t cse_var_14 = (((j_10 * 51) + (j_11 * 3)) + k_7);
            ((int8_t*)dyn_slice_fixed_size_let)[cse_var_14] = cache_buffer_var_3[cse_var_14];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_2 = 0; c_2 < 80; ++c_2) {
    for (int32_t i_6 = 0; i_6 < 15; ++i_6) {
      ((int8_t*)cache_conv_input_compute_generic_let)[((c_2 * 15) + i_6)] = (int8_t)0;
      for (int32_t di_2 = 0; di_2 < 3; ++di_2) {
        for (int32_t dj_2 = 0; dj_2 < 3; ++dj_2) {
          int32_t cse_var_16 = (di_2 * 3);
          int32_t cse_var_15 = ((c_2 * 15) + i_6);
          ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_15] = (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_15] + (((int8_t*)dyn_slice_fixed_size_let)[((((c_2 * 51) + (i_6 * 3)) + cse_var_16) + dj_2)] * weight_depth_wise_33[(((c_2 * 9) + cse_var_16) + dj_2)]));
        }
      }
    }
  }
  for (int32_t ff_5 = 0; ff_5 < 16; ++ff_5) {
    for (int32_t yy_5 = 0; yy_5 < 15; ++yy_5) {
      ((int8_t*)conv2d_nchw_let)[((ff_5 * 15) + yy_5)] = (int8_t)0;
      for (int32_t rc_5 = 0; rc_5 < 80; ++rc_5) {
        int32_t cse_var_17 = ((ff_5 * 15) + yy_5);
        ((int8_t*)conv2d_nchw_let)[cse_var_17] = (((int8_t*)conv2d_nchw_let)[cse_var_17] + (((int8_t*)cache_conv_input_compute_generic_let)[((rc_5 * 15) + yy_5)] * weight_1x1_conv2d_linear_33[((ff_5 * 80) + rc_5)]));
      }
    }
  }
  for (int32_t ff_6 = 0; ff_6 < 80; ++ff_6) {
    for (int32_t yy_6 = 0; yy_6 < 15; ++yy_6) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_6 * 15) + yy_6)] = (int8_t)0;
      for (int32_t rc_6 = 0; rc_6 < 16; ++rc_6) {
        int32_t cse_var_18 = ((ff_6 * 15) + yy_6);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_18] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_18] + (((int8_t*)conv2d_nchw_let)[((rc_6 * 15) + yy_6)] * weight_1x1_conv2d_34[((ff_6 * 16) + rc_6)]));
      }
    }
  }
  for (int32_t n_8 = 0; n_8 < 1; ++n_8) {
    for (int32_t i_7 = 0; i_7 < 80; ++i_7) {
      for (int32_t j_12 = 0; j_12 < 15; ++j_12) {
        for (int32_t k_8 = 0; k_8 < 1; ++k_8) {
          cache_buffer_var_4[(((i_7 * 105) + (j_12 * 7)) + ((cache_cur_idx_4[3] % 6) + (6 & ((cache_cur_idx_4[3] % 6) >> 31))))] = ((int8_t*)dyn_slice_fixed_size_let)[((i_7 * 15) + j_12)];
        }
      }
    }
  }
  cache_cur_idx_4[3] = (cache_cur_idx_4[3] + 1);
  if (6 <= cache_cur_idx_4[3]) {
    for (int32_t n_9 = 0; n_9 < 1; ++n_9) {
      for (int32_t j_13 = 0; j_13 < 80; ++j_13) {
        for (int32_t j_14 = 0; j_14 < 15; ++j_14) {
          for (int32_t k_9 = 0; k_9 < 7; ++k_9) {
            int32_t cse_var_19 = (((j_13 * 105) + (j_14 * 7)) + k_9);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_19] = cache_buffer_var_4[cse_var_19];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_3 = 0; c_3 < 80; ++c_3) {
    for (int32_t i_8 = 0; i_8 < 9; ++i_8) {
      ((int8_t*)dyn_slice_fixed_size_let)[((c_3 * 9) + i_8)] = (int8_t)0;
      for (int32_t di_3 = 0; di_3 < 7; ++di_3) {
        for (int32_t dj_3 = 0; dj_3 < 7; ++dj_3) {
          int32_t cse_var_21 = (di_3 * 7);
          int32_t cse_var_20 = ((c_3 * 9) + i_8);
          ((int8_t*)dyn_slice_fixed_size_let)[cse_var_20] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_20] + (((int8_t*)cache_conv_input_compute_generic_let)[((((c_3 * 105) + (i_8 * 7)) + cse_var_21) + dj_3)] * weight_depth_wise_34[(((c_3 * 49) + cse_var_21) + dj_3)]));
        }
      }
    }
  }
  for (int32_t ff_7 = 0; ff_7 < 16; ++ff_7) {
    for (int32_t yy_7 = 0; yy_7 < 9; ++yy_7) {
      ((int8_t*)conv2d_nchw_let)[((ff_7 * 9) + yy_7)] = (int8_t)0;
      for (int32_t rc_7 = 0; rc_7 < 80; ++rc_7) {
        int32_t cse_var_22 = ((ff_7 * 9) + yy_7);
        ((int8_t*)conv2d_nchw_let)[cse_var_22] = (((int8_t*)conv2d_nchw_let)[cse_var_22] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_7 * 9) + yy_7)] * weight_1x1_conv2d_linear_34[((ff_7 * 80) + rc_7)]));
      }
    }
  }
  for (int32_t ff_8 = 0; ff_8 < 64; ++ff_8) {
    for (int32_t yy_8 = 0; yy_8 < 9; ++yy_8) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_8 * 9) + yy_8)] = (int8_t)0;
      for (int32_t rc_8 = 0; rc_8 < 16; ++rc_8) {
        int32_t cse_var_23 = ((ff_8 * 9) + yy_8);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_23] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_23] + (((int8_t*)conv2d_nchw_let)[((rc_8 * 9) + yy_8)] * weight_1x1_conv2d_35[((ff_8 * 16) + rc_8)]));
      }
    }
  }
  for (int32_t n_10 = 0; n_10 < 1; ++n_10) {
    for (int32_t i_9 = 0; i_9 < 64; ++i_9) {
      for (int32_t j_15 = 0; j_15 < 9; ++j_15) {
        for (int32_t k_10 = 0; k_10 < 1; ++k_10) {
          cache_buffer_var_5[(((i_9 * 45) + (j_15 * 5)) + (cache_cur_idx_5[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i_9 * 9) + j_15)];
        }
      }
    }
  }
  cache_cur_idx_5[3] = (cache_cur_idx_5[3] + 1);
  if (4 <= cache_cur_idx_5[3]) {
    for (int32_t n_11 = 0; n_11 < 1; ++n_11) {
      for (int32_t j_16 = 0; j_16 < 64; ++j_16) {
        for (int32_t j_17 = 0; j_17 < 9; ++j_17) {
          for (int32_t k_11 = 0; k_11 < 5; ++k_11) {
            int32_t cse_var_24 = (((j_16 * 45) + (j_17 * 5)) + k_11);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_24] = cache_buffer_var_5[cse_var_24];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_4 = 0; c_4 < 64; ++c_4) {
    for (int32_t i_10 = 0; i_10 < 5; ++i_10) {
      ((int8_t*)dyn_slice_fixed_size_let)[((c_4 * 5) + i_10)] = (int8_t)0;
      for (int32_t di_4 = 0; di_4 < 5; ++di_4) {
        for (int32_t dj_4 = 0; dj_4 < 5; ++dj_4) {
          int32_t cse_var_26 = (di_4 * 5);
          int32_t cse_var_25 = ((c_4 * 5) + i_10);
          ((int8_t*)dyn_slice_fixed_size_let)[cse_var_25] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_25] + (((int8_t*)cache_conv_input_compute_generic_let)[((((c_4 * 45) + (i_10 * 5)) + cse_var_26) + dj_4)] * weight_depth_wise_35[(((c_4 * 25) + cse_var_26) + dj_4)]));
        }
      }
    }
  }
  for (int32_t ff_9 = 0; ff_9 < 16; ++ff_9) {
    for (int32_t yy_9 = 0; yy_9 < 5; ++yy_9) {
      ((int8_t*)conv2d_nchw_let)[((ff_9 * 5) + yy_9)] = (int8_t)0;
      for (int32_t rc_9 = 0; rc_9 < 64; ++rc_9) {
        int32_t cse_var_27 = ((ff_9 * 5) + yy_9);
        ((int8_t*)conv2d_nchw_let)[cse_var_27] = (((int8_t*)conv2d_nchw_let)[cse_var_27] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_9 * 5) + yy_9)] * weight_1x1_conv2d_linear_35[((ff_9 * 64) + rc_9)]));
      }
    }
  }
  for (int32_t ff_10 = 0; ff_10 < 80; ++ff_10) {
    for (int32_t yy_10 = 0; yy_10 < 5; ++yy_10) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_10 * 5) + yy_10)] = (int8_t)0;
      for (int32_t rc_10 = 0; rc_10 < 16; ++rc_10) {
        int32_t cse_var_28 = ((ff_10 * 5) + yy_10);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_28] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_28] + (((int8_t*)conv2d_nchw_let)[((rc_10 * 5) + yy_10)] * weight_1x1_conv2d_36[((ff_10 * 16) + rc_10)]));
      }
    }
  }
  for (int32_t n_12 = 0; n_12 < 1; ++n_12) {
    for (int32_t i_11 = 0; i_11 < 80; ++i_11) {
      for (int32_t j_18 = 0; j_18 < 5; ++j_18) {
        for (int32_t k_12 = 0; k_12 < 1; ++k_12) {
          cache_buffer_var_6[(((i_11 * 25) + (j_18 * 5)) + (cache_cur_idx_6[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i_11 * 5) + j_18)];
        }
      }
    }
  }
  cache_cur_idx_6[3] = (cache_cur_idx_6[3] + 1);
  if ((4 <= cache_cur_idx_6[3]) && ((cache_cur_idx_6[3] % 2) == 0)) {
    for (int32_t n_13 = 0; n_13 < 1; ++n_13) {
      for (int32_t j_19 = 0; j_19 < 80; ++j_19) {
        for (int32_t j_20 = 0; j_20 < 5; ++j_20) {
          for (int32_t k_13 = 0; k_13 < 5; ++k_13) {
            int32_t cse_var_29 = (((j_19 * 25) + (j_20 * 5)) + k_13);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_29] = cache_buffer_var_6[cse_var_29];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_5 = 0; c_5 < 80; ++c_5) {
    ((int8_t*)conv2d_nchw_let)[c_5] = (int8_t)0;
    for (int32_t di_5 = 0; di_5 < 5; ++di_5) {
      for (int32_t dj_5 = 0; dj_5 < 5; ++dj_5) {
        int32_t cse_var_30 = (((c_5 * 25) + (di_5 * 5)) + dj_5);
        ((int8_t*)conv2d_nchw_let)[c_5] = (((int8_t*)conv2d_nchw_let)[c_5] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_30] * weight_depth_wise_36[cse_var_30]));
      }
    }
  }
  for (int32_t ff_11 = 0; ff_11 < 24; ++ff_11) {
    conv2d_nchw[ff_11] = (int8_t)0;
    for (int32_t rc_11 = 0; rc_11 < 80; ++rc_11) {
      conv2d_nchw[ff_11] = (conv2d_nchw[ff_11] + (((int8_t*)conv2d_nchw_let)[rc_11] * weight_1x1_conv2d_linear_36[((ff_11 * 80) + rc_11)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_20(int32_t* iterator, int8_t* dummy_input_18, int8_t* weight_1x1_conv2d_37, int8_t* weight_depth_wise_37, int8_t* weight_1x1_conv2d_linear_37, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_4_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_4_var[26232]));
  void* conv2d_nchw_let = (&(global_workspace_4_var[0]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_4_var[0]));
  for (int32_t i1 = 0; i1 < 24; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_18[((((((iterator[0] * 11616) + (i1 * 484)) + (iterator[1] * 484)) + (i2 * 22)) + (iterator[2] * 22)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 120; ++ff) {
    for (int32_t yy = 0; yy < 5; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 5) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 24; ++rc) {
        int32_t cse_var_1 = ((ff * 5) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 5) + yy)] * weight_1x1_conv2d_37[((ff * 24) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 120; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)conv2d_nchw_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 120; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 120; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_3 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_3] * weight_depth_wise_37[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 24; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 120; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)dyn_slice_fixed_size_let)[rc_1] * weight_1x1_conv2d_linear_37[((ff_1 * 120) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_26(int32_t* iterator, int8_t* dummy_input_21, int8_t* weight_1x1_conv2d_38, int8_t* weight_depth_wise_38, int8_t* weight_1x1_conv2d_linear_38, int8_t* weight_1x1_conv2d_39, int8_t* weight_depth_wise_39, int8_t* weight_1x1_conv2d_linear_39, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* conv2d_nchw, uint8_t* global_workspace_6_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_6_var[10320]));
  void* conv2d_nchw_let = (&(global_workspace_6_var[9480]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_6_var[4200]));
  for (int32_t i1 = 0; i1 < 24; ++i1) {
    for (int32_t i2 = 0; i2 < 7; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 7) + i2)] = dummy_input_21[((((((iterator[0] * 11616) + (i1 * 484)) + (iterator[1] * 484)) + (i2 * 22)) + (iterator[2] * 22)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 120; ++ff) {
    for (int32_t yy = 0; yy < 7; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 7) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 24; ++rc) {
        int32_t cse_var_1 = ((ff * 7) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 7) + yy)] * weight_1x1_conv2d_38[((ff * 24) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 120; ++i) {
      for (int32_t j = 0; j < 7; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 35) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)conv2d_nchw_let)[((i * 7) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 120; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 7; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 35) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 120; ++c) {
    for (int32_t i_1 = 0; i_1 < 3; ++i_1) {
      ((int8_t*)conv2d_nchw_let)[((c * 3) + i_1)] = (int8_t)0;
      for (int32_t di = 0; di < 5; ++di) {
        for (int32_t dj = 0; dj < 5; ++dj) {
          int32_t cse_var_4 = (di * 5);
          int32_t cse_var_3 = ((c * 3) + i_1);
          ((int8_t*)conv2d_nchw_let)[cse_var_3] = (((int8_t*)conv2d_nchw_let)[cse_var_3] + (((int8_t*)cache_conv_input_compute_generic_let)[((((c * 35) + (i_1 * 5)) + cse_var_4) + dj)] * weight_depth_wise_38[(((c * 25) + cse_var_4) + dj)]));
        }
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 24; ++ff_1) {
    for (int32_t yy_1 = 0; yy_1 < 3; ++yy_1) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_1 * 3) + yy_1)] = (int8_t)0;
      for (int32_t rc_1 = 0; rc_1 < 120; ++rc_1) {
        int32_t cse_var_5 = ((ff_1 * 3) + yy_1);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] + (((int8_t*)conv2d_nchw_let)[((rc_1 * 3) + yy_1)] * weight_1x1_conv2d_linear_38[((ff_1 * 120) + rc_1)]));
      }
    }
  }
  for (int32_t ff_2 = 0; ff_2 < 120; ++ff_2) {
    for (int32_t yy_2 = 0; yy_2 < 3; ++yy_2) {
      ((int8_t*)conv2d_nchw_let)[((ff_2 * 3) + yy_2)] = (int8_t)0;
      for (int32_t rc_2 = 0; rc_2 < 24; ++rc_2) {
        int32_t cse_var_6 = ((ff_2 * 3) + yy_2);
        ((int8_t*)conv2d_nchw_let)[cse_var_6] = (((int8_t*)conv2d_nchw_let)[cse_var_6] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_2 * 3) + yy_2)] * weight_1x1_conv2d_39[((ff_2 * 24) + rc_2)]));
      }
    }
  }
  for (int32_t n_2 = 0; n_2 < 1; ++n_2) {
    for (int32_t i_2 = 0; i_2 < 120; ++i_2) {
      for (int32_t j_3 = 0; j_3 < 3; ++j_3) {
        for (int32_t k_2 = 0; k_2 < 1; ++k_2) {
          cache_buffer_var_1[(((i_2 * 9) + (j_3 * 3)) + (cache_cur_idx_1[3] & 1))] = ((int8_t*)conv2d_nchw_let)[((i_2 * 3) + j_3)];
        }
      }
    }
  }
  cache_cur_idx_1[3] = (cache_cur_idx_1[3] + 1);
  if ((2 <= cache_cur_idx_1[3]) && ((cache_cur_idx_1[3] % 2) == 0)) {
    for (int32_t n_3 = 0; n_3 < 1; ++n_3) {
      for (int32_t j_4 = 0; j_4 < 120; ++j_4) {
        for (int32_t j_5 = 0; j_5 < 3; ++j_5) {
          for (int32_t k_3 = 0; k_3 < 3; ++k_3) {
            int32_t cse_var_7 = (((j_4 * 9) + (j_5 * 3)) + k_3);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_7] = cache_buffer_var_1[cse_var_7];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_1 = 0; c_1 < 120; ++c_1) {
    ((int8_t*)dyn_slice_fixed_size_let)[c_1] = (int8_t)0;
    for (int32_t di_1 = 0; di_1 < 3; ++di_1) {
      for (int32_t dj_1 = 0; dj_1 < 3; ++dj_1) {
        int32_t cse_var_8 = (((c_1 * 9) + (di_1 * 3)) + dj_1);
        ((int8_t*)dyn_slice_fixed_size_let)[c_1] = (((int8_t*)dyn_slice_fixed_size_let)[c_1] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_8] * weight_depth_wise_39[cse_var_8]));
      }
    }
  }
  for (int32_t ff_3 = 0; ff_3 < 40; ++ff_3) {
    conv2d_nchw[ff_3] = (int8_t)0;
    for (int32_t rc_3 = 0; rc_3 < 120; ++rc_3) {
      conv2d_nchw[ff_3] = (conv2d_nchw[ff_3] + (((int8_t*)dyn_slice_fixed_size_let)[rc_3] * weight_1x1_conv2d_linear_39[((ff_3 * 120) + rc_3)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_30(int32_t* iterator, int8_t* dummy_input_27, int8_t* weight_1x1_conv2d_40, int8_t* weight_depth_wise_40, int8_t* weight_1x1_conv2d_linear_40, int8_t* weight_1x1_conv2d_41, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_8_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_8_var[42880]));
  void* conv2d_nchw_let = (&(global_workspace_8_var[31120]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_8_var[31120]));
  void* conv2d_nchw_let_1 = (&(global_workspace_8_var[31120]));
  for (int32_t i1 = 0; i1 < 40; ++i1) {
    for (int32_t i2 = 0; i2 < 7; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 7) + i2)] = dummy_input_27[((((((iterator[0] * 4840) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 240; ++ff) {
    for (int32_t yy = 0; yy < 7; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 7) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 40; ++rc) {
        int32_t cse_var_1 = ((ff * 7) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 7) + yy)] * weight_1x1_conv2d_40[((ff * 40) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 240; ++i) {
      for (int32_t j = 0; j < 7; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 49) + (j * 7)) + ((cache_cur_idx[3] % 6) + (6 & ((cache_cur_idx[3] % 6) >> 31))))] = ((int8_t*)conv2d_nchw_let)[((i * 7) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (6 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 240; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 7; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 7; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 49) + (j_2 * 7)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 240; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 7; ++di) {
      for (int32_t dj = 0; dj < 7; ++dj) {
        int32_t cse_var_3 = (((c * 49) + (di * 7)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_3] * weight_depth_wise_40[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 40; ++ff_1) {
    ((int8_t*)conv2d_nchw_let_1)[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 240; ++rc_1) {
      ((int8_t*)conv2d_nchw_let_1)[ff_1] = (((int8_t*)conv2d_nchw_let_1)[ff_1] + (((int8_t*)dyn_slice_fixed_size_let)[rc_1] * weight_1x1_conv2d_linear_40[((ff_1 * 240) + rc_1)]));
    }
  }
  for (int32_t ff_2 = 0; ff_2 < 160; ++ff_2) {
    conv2d_nchw[ff_2] = (int8_t)0;
    for (int32_t rc_2 = 0; rc_2 < 40; ++rc_2) {
      conv2d_nchw[ff_2] = (conv2d_nchw[ff_2] + (((int8_t*)conv2d_nchw_let_1)[rc_2] * weight_1x1_conv2d_41[((ff_2 * 40) + rc_2)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_32(int32_t* iterator, int8_t* dummy_input_31, int8_t* weight_depth_wise_41, int8_t* weight_1x1_conv2d_linear_41, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_10_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_10_var[23360]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_10_var[0]));
  for (int32_t i1 = 0; i1 < 160; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_31[((((((iterator[0] * 19360) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 160; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 160; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 160; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_2 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_41[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 40; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 160; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_41[((ff * 160) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_35(int32_t* iterator, int8_t* dummy_input_34, int8_t* weight_depth_wise_42, int8_t* weight_1x1_conv2d_linear_42, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_13_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_13_var[35008]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_13_var[0]));
  for (int32_t i1 = 0; i1 < 200; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_34[((((((iterator[0] * 24200) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 200; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 200; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 200; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_2 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_42[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 200; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_42[((ff * 200) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_38(int32_t* iterator, int8_t* dummy_input_36, int8_t* weight_1x1_conv2d_43, int8_t* weight_depth_wise_43, int8_t* weight_1x1_conv2d_linear_43, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_15_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_15_var[23520]));
  void* conv2d_nchw_let = (&(global_workspace_15_var[11760]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_15_var[11760]));
  for (int32_t i1 = 0; i1 < 48; ++i1) {
    for (int32_t i2 = 0; i2 < 7; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 7) + i2)] = dummy_input_36[((((((iterator[0] * 5808) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 240; ++ff) {
    for (int32_t yy = 0; yy < 7; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 7) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 48; ++rc) {
        int32_t cse_var_1 = ((ff * 7) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 7) + yy)] * weight_1x1_conv2d_43[((ff * 48) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 240; ++i) {
      for (int32_t j = 0; j < 7; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 49) + (j * 7)) + ((cache_cur_idx[3] % 6) + (6 & ((cache_cur_idx[3] % 6) >> 31))))] = ((int8_t*)conv2d_nchw_let)[((i * 7) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (6 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 240; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 7; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 7; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 49) + (j_2 * 7)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 240; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 7; ++di) {
      for (int32_t dj = 0; dj < 7; ++dj) {
        int32_t cse_var_3 = (((c * 49) + (di * 7)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_3] * weight_depth_wise_43[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 48; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 240; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)dyn_slice_fixed_size_let)[rc_1] * weight_1x1_conv2d_linear_43[((ff_1 * 240) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_41(int32_t* iterator, int8_t* dummy_input_40, int8_t* weight_depth_wise_44, int8_t* weight_1x1_conv2d_linear_44, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_18_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_18_var[31200]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_18_var[0]));
  for (int32_t i1 = 0; i1 < 240; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_40[((((((iterator[0] * 29040) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 240; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 240; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 240; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_44[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 240; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_44[((ff * 240) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_44(int32_t* iterator, int8_t* dummy_input_43, int8_t* weight_depth_wise_45, int8_t* weight_1x1_conv2d_linear_45, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_21_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_21_var[40896]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_21_var[0]));
  for (int32_t i1 = 0; i1 < 288; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_43[((((((iterator[0] * 34848) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 288; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((2 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 288; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 288; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_45[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 96; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 288; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_45[((ff * 288) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_48(int32_t* iterator, int8_t* dummy_input_47, int8_t* weight_1x1_conv2d_linear_46, int8_t* weight_1x1_conv2d_47, int8_t* conv2d_nchw, uint8_t* global_workspace_25_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_25_var[31104]));
  void* conv2d_nchw_let = (&(global_workspace_25_var[0]));
  for (int32_t i1 = 0; i1 < 480; ++i1) {
    ((int8_t*)dyn_slice_fixed_size_let)[i1] = dummy_input_47[(((((iterator[0] * 17280) + (i1 * 36)) + (iterator[1] * 36)) + (iterator[2] * 6)) + iterator[3])];
  }
  for (int32_t ff = 0; ff < 96; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 480; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_46[((ff * 480) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 384; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 96; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_47[((ff_1 * 96) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_51(int32_t* iterator, int8_t* dummy_input_49, int8_t* weight_depth_wise_47, int8_t* weight_1x1_conv2d_linear_47, int8_t* weight_1x1_conv2d_48, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_27_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_27_var[34560]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_27_var[17280]));
  void* conv2d_nchw_let = (&(global_workspace_27_var[17280]));
  for (int32_t i1 = 0; i1 < 384; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_49[((((((iterator[0] * 13824) + (i1 * 36)) + (iterator[1] * 36)) + (i2 * 6)) + (iterator[2] * 6)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 384; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 384; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 384; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_47[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 96; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 384; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_47[((ff * 384) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 480; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 96; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_48[((ff_1 * 96) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(int8_t* data_buffer_var, int8_t* conv2d_1_buffer_var, int8_t* weight_depth_wise_1_buffer_var, int8_t* conv2d_2_buffer_var, int8_t* weight_1x1_conv2d_32_buffer_var, int8_t* weight_depth_wise_32_buffer_var, int8_t* weight_1x1_conv2d_linear_32_buffer_var, int8_t* weight_1x1_conv2d_33_buffer_var, int8_t* weight_depth_wise_33_buffer_var, int8_t* weight_1x1_conv2d_linear_33_buffer_var, int8_t* weight_1x1_conv2d_34_buffer_var, int8_t* weight_depth_wise_34_buffer_var, int8_t* weight_1x1_conv2d_linear_34_buffer_var, int8_t* weight_1x1_conv2d_35_buffer_var, int8_t* weight_depth_wise_35_buffer_var, int8_t* weight_1x1_conv2d_linear_35_buffer_var, int8_t* weight_1x1_conv2d_36_buffer_var, int8_t* weight_depth_wise_36_buffer_var, int8_t* weight_1x1_conv2d_linear_36_buffer_var, int8_t* weight_1x1_conv2d_37_buffer_var, int8_t* weight_depth_wise_37_buffer_var, int8_t* weight_1x1_conv2d_linear_37_buffer_var, int8_t* weight_1x1_conv2d_38_buffer_var, int8_t* weight_depth_wise_38_buffer_var, int8_t* weight_1x1_conv2d_linear_38_buffer_var, int8_t* weight_1x1_conv2d_39_buffer_var, int8_t* weight_depth_wise_39_buffer_var, int8_t* weight_1x1_conv2d_linear_39_buffer_var, int8_t* weight_1x1_conv2d_40_buffer_var, int8_t* weight_depth_wise_40_buffer_var, int8_t* weight_1x1_conv2d_linear_40_buffer_var, int8_t* weight_1x1_conv2d_41_buffer_var, int8_t* weight_depth_wise_41_buffer_var, int8_t* weight_1x1_conv2d_linear_41_buffer_var, int8_t* weight_1x1_conv2d_42_buffer_var, int8_t* weight_depth_wise_42_buffer_var, int8_t* weight_1x1_conv2d_linear_42_buffer_var, int8_t* weight_1x1_conv2d_43_buffer_var, int8_t* weight_depth_wise_43_buffer_var, int8_t* weight_1x1_conv2d_linear_43_buffer_var, int8_t* weight_1x1_conv2d_44_buffer_var, int8_t* weight_depth_wise_44_buffer_var, int8_t* weight_1x1_conv2d_linear_44_buffer_var, int8_t* weight_1x1_conv2d_45_buffer_var, int8_t* weight_depth_wise_45_buffer_var, int8_t* weight_1x1_conv2d_linear_45_buffer_var, int8_t* weight_1x1_conv2d_46_buffer_var, int8_t* weight_depth_wise_46_buffer_var, int8_t* weight_1x1_conv2d_linear_46_buffer_var, int8_t* weight_1x1_conv2d_47_buffer_var, int8_t* weight_depth_wise_47_buffer_var, int8_t* weight_1x1_conv2d_linear_47_buffer_var, int8_t* weight_1x1_conv2d_48_buffer_var, int8_t* weight_depth_wise_48_buffer_var, int8_t* weight_1x1_conv2d_linear_48_buffer_var, int8_t* output_buffer_var, uint8_t* global_workspace_0_var) {
  void* sid_56_let = (&(global_workspace_0_var[11616]));
  void* sid_55_let = (&(global_workspace_0_var[0]));
  void* sid_65_let = (&(global_workspace_0_var[0]));
  void* sid_57_let = (&(global_workspace_0_var[31120]));
  void* sid_58_let = (&(global_workspace_0_var[0]));
  void* sid_59_let = (&(global_workspace_0_var[24200]));
  void* sid_60_let = (&(global_workspace_0_var[0]));
  void* sid_71_let = (&(global_workspace_0_var[17280]));
  void* sid_61_let = (&(global_workspace_0_var[24200]));
  void* sid_62_let = (&(global_workspace_0_var[30008]));
  void* sid_63_let = (&(global_workspace_0_var[0]));
  void* sid_64_let = (&(global_workspace_0_var[34848]));
  void* sid_66_let = (&(global_workspace_0_var[34848]));
  void* sid_67_let = (&(global_workspace_0_var[17280]));
  void* sid_68_let = (&(global_workspace_0_var[0]));
  void* sid_69_let = (&(global_workspace_0_var[17280]));
  void* sid_70_let = (&(global_workspace_0_var[0]));
  if (tvmgen_default_fused_fusion_iter_worker(data_buffer_var, conv2d_1_buffer_var, weight_depth_wise_1_buffer_var, conv2d_2_buffer_var, weight_1x1_conv2d_32_buffer_var, weight_depth_wise_32_buffer_var, weight_1x1_conv2d_linear_32_buffer_var, weight_1x1_conv2d_33_buffer_var, weight_depth_wise_33_buffer_var, weight_1x1_conv2d_linear_33_buffer_var, weight_1x1_conv2d_34_buffer_var, weight_depth_wise_34_buffer_var, weight_1x1_conv2d_linear_34_buffer_var, weight_1x1_conv2d_35_buffer_var, weight_depth_wise_35_buffer_var, weight_1x1_conv2d_linear_35_buffer_var, weight_1x1_conv2d_36_buffer_var, weight_depth_wise_36_buffer_var, weight_1x1_conv2d_linear_36_buffer_var, sid_55_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_1(sid_55_let, weight_1x1_conv2d_37_buffer_var, weight_depth_wise_37_buffer_var, weight_1x1_conv2d_linear_37_buffer_var, sid_56_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_2(sid_56_let, weight_1x1_conv2d_38_buffer_var, weight_depth_wise_38_buffer_var, weight_1x1_conv2d_linear_38_buffer_var, weight_1x1_conv2d_39_buffer_var, weight_depth_wise_39_buffer_var, weight_1x1_conv2d_linear_39_buffer_var, sid_57_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_3(sid_57_let, weight_1x1_conv2d_40_buffer_var, weight_depth_wise_40_buffer_var, weight_1x1_conv2d_linear_40_buffer_var, weight_1x1_conv2d_41_buffer_var, sid_58_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_4(sid_58_let, weight_depth_wise_41_buffer_var, weight_1x1_conv2d_linear_41_buffer_var, sid_59_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d(sid_59_let, weight_1x1_conv2d_42_buffer_var, sid_60_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_5(sid_60_let, weight_depth_wise_42_buffer_var, weight_1x1_conv2d_linear_42_buffer_var, sid_61_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_6(sid_61_let, weight_1x1_conv2d_43_buffer_var, weight_depth_wise_43_buffer_var, weight_1x1_conv2d_linear_43_buffer_var, sid_62_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_1(sid_62_let, weight_1x1_conv2d_44_buffer_var, sid_63_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_7(sid_63_let, weight_depth_wise_44_buffer_var, weight_1x1_conv2d_linear_44_buffer_var, sid_64_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_2(sid_64_let, weight_1x1_conv2d_45_buffer_var, sid_65_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_8(sid_65_let, weight_depth_wise_45_buffer_var, weight_1x1_conv2d_linear_45_buffer_var, sid_66_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_3(sid_66_let, weight_1x1_conv2d_46_buffer_var, sid_67_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_4(sid_67_let, weight_depth_wise_46_buffer_var, sid_68_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_9(sid_68_let, weight_1x1_conv2d_linear_46_buffer_var, weight_1x1_conv2d_47_buffer_var, sid_69_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_10(sid_69_let, weight_depth_wise_47_buffer_var, weight_1x1_conv2d_linear_47_buffer_var, weight_1x1_conv2d_48_buffer_var, sid_70_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_5(sid_70_let, weight_depth_wise_48_buffer_var, sid_71_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_6(sid_71_let, weight_1x1_conv2d_linear_48_buffer_var, output_buffer_var, global_workspace_0_var) != 0 ) return -1;
  return 0;
}


// tvm target: c -keys=partial_conv,arm_cpu,cpu -mcpu=cortex-m4+nodsp -model=nrf52840
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* fusion_iter_worker, uint8_t* global_workspace_1_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_1(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_3_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_10(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_23_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_11(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_26_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_12(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_28_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_2(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* p7, int8_t* p8, int8_t* p9, int8_t* fusion_iter_worker, uint8_t* global_workspace_5_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_3(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_7_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_4(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* p7, int8_t* fusion_iter_worker, uint8_t* global_workspace_9_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_5(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_11_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_6(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_13_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_7(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_15_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_8(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_18_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_9(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_20_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_17_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_1(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_22_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_2(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_25_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_3(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_30_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_4(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_31_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_17(int32_t* iterator, int8_t* dummy_input_9, int8_t* weight_1x1_conv2d_34, int8_t* weight_depth_wise_34, int8_t* weight_1x1_conv2d_linear_34, int8_t* weight_1x1_conv2d_35, int8_t* weight_depth_wise_35, int8_t* weight_1x1_conv2d_linear_35, int8_t* weight_1x1_conv2d_36, int8_t* weight_depth_wise_36, int8_t* weight_1x1_conv2d_linear_36, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* cache_buffer_var_2, int32_t* cache_cur_idx_2, int8_t* conv2d_nchw, uint8_t* global_workspace_6_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_20(int32_t* iterator, int8_t* dummy_input_18, int8_t* weight_1x1_conv2d_37, int8_t* weight_depth_wise_37, int8_t* weight_1x1_conv2d_linear_37, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_8_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_27(int32_t* iterator, int8_t* dummy_input_21, int8_t* weight_1x1_conv2d_38, int8_t* weight_depth_wise_38, int8_t* weight_1x1_conv2d_linear_38, int8_t* weight_1x1_conv2d_39, int8_t* weight_depth_wise_39, int8_t* weight_1x1_conv2d_linear_39, int8_t* weight_1x1_conv2d_40, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* conv2d_nchw, uint8_t* global_workspace_10_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_30(int32_t* iterator, int8_t* dummy_input_28, int8_t* weight_depth_wise_40, int8_t* weight_1x1_conv2d_linear_40, int8_t* weight_1x1_conv2d_41, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_12_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_33(int32_t* iterator, int8_t* dummy_input_31, int8_t* weight_depth_wise_41, int8_t* weight_1x1_conv2d_linear_41, int8_t* weight_1x1_conv2d_42, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_14_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_36(int32_t* iterator, int8_t* dummy_input_34, int8_t* weight_depth_wise_42, int8_t* weight_1x1_conv2d_linear_42, int8_t* weight_1x1_conv2d_43, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_16_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_39(int32_t* iterator, int8_t* dummy_input_38, int8_t* weight_1x1_conv2d_linear_43, int8_t* weight_1x1_conv2d_44, int8_t* conv2d_nchw, uint8_t* global_workspace_19_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_41(int32_t* iterator, int8_t* dummy_input_40, int8_t* weight_depth_wise_44, int8_t* weight_1x1_conv2d_linear_44, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_21_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_45(int32_t* iterator, int8_t* dummy_input_43, int8_t* weight_depth_wise_45, int8_t* weight_1x1_conv2d_linear_45, int8_t* weight_1x1_conv2d_46, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_24_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_48(int32_t* iterator, int8_t* dummy_input_47, int8_t* weight_1x1_conv2d_linear_46, int8_t* weight_1x1_conv2d_47, int8_t* conv2d_nchw, uint8_t* global_workspace_27_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_5(int32_t* iterator, int8_t* dummy_input_0, int8_t* conv2d_1, int8_t* weight_depth_wise_1, int8_t* conv2d_2, int8_t* weight_1x1_conv2d_32, int8_t* weight_depth_wise_32, int8_t* weight_1x1_conv2d_linear_32, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* cache_buffer_var_2, int32_t* cache_cur_idx_2, int8_t* conv2d_nchw, uint8_t* global_workspace_2_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_51(int32_t* iterator, int8_t* dummy_input_49, int8_t* weight_depth_wise_47, int8_t* weight_1x1_conv2d_linear_47, int8_t* weight_1x1_conv2d_48, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_29_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_8(int32_t* iterator, int8_t* dummy_input_6, int8_t* weight_1x1_conv2d_33, int8_t* weight_depth_wise_33, int8_t* weight_1x1_conv2d_linear_33, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_4_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(int8_t* data_buffer_var, int8_t* conv2d_1_buffer_var, int8_t* weight_depth_wise_1_buffer_var, int8_t* conv2d_2_buffer_var, int8_t* weight_1x1_conv2d_32_buffer_var, int8_t* weight_depth_wise_32_buffer_var, int8_t* weight_1x1_conv2d_linear_32_buffer_var, int8_t* weight_1x1_conv2d_33_buffer_var, int8_t* weight_depth_wise_33_buffer_var, int8_t* weight_1x1_conv2d_linear_33_buffer_var, int8_t* weight_1x1_conv2d_34_buffer_var, int8_t* weight_depth_wise_34_buffer_var, int8_t* weight_1x1_conv2d_linear_34_buffer_var, int8_t* weight_1x1_conv2d_35_buffer_var, int8_t* weight_depth_wise_35_buffer_var, int8_t* weight_1x1_conv2d_linear_35_buffer_var, int8_t* weight_1x1_conv2d_36_buffer_var, int8_t* weight_depth_wise_36_buffer_var, int8_t* weight_1x1_conv2d_linear_36_buffer_var, int8_t* weight_1x1_conv2d_37_buffer_var, int8_t* weight_depth_wise_37_buffer_var, int8_t* weight_1x1_conv2d_linear_37_buffer_var, int8_t* weight_1x1_conv2d_38_buffer_var, int8_t* weight_depth_wise_38_buffer_var, int8_t* weight_1x1_conv2d_linear_38_buffer_var, int8_t* weight_1x1_conv2d_39_buffer_var, int8_t* weight_depth_wise_39_buffer_var, int8_t* weight_1x1_conv2d_linear_39_buffer_var, int8_t* weight_1x1_conv2d_40_buffer_var, int8_t* weight_depth_wise_40_buffer_var, int8_t* weight_1x1_conv2d_linear_40_buffer_var, int8_t* weight_1x1_conv2d_41_buffer_var, int8_t* weight_depth_wise_41_buffer_var, int8_t* weight_1x1_conv2d_linear_41_buffer_var, int8_t* weight_1x1_conv2d_42_buffer_var, int8_t* weight_depth_wise_42_buffer_var, int8_t* weight_1x1_conv2d_linear_42_buffer_var, int8_t* weight_1x1_conv2d_43_buffer_var, int8_t* weight_depth_wise_43_buffer_var, int8_t* weight_1x1_conv2d_linear_43_buffer_var, int8_t* weight_1x1_conv2d_44_buffer_var, int8_t* weight_depth_wise_44_buffer_var, int8_t* weight_1x1_conv2d_linear_44_buffer_var, int8_t* weight_1x1_conv2d_45_buffer_var, int8_t* weight_depth_wise_45_buffer_var, int8_t* weight_1x1_conv2d_linear_45_buffer_var, int8_t* weight_1x1_conv2d_46_buffer_var, int8_t* weight_depth_wise_46_buffer_var, int8_t* weight_1x1_conv2d_linear_46_buffer_var, int8_t* weight_1x1_conv2d_47_buffer_var, int8_t* weight_depth_wise_47_buffer_var, int8_t* weight_1x1_conv2d_linear_47_buffer_var, int8_t* weight_1x1_conv2d_48_buffer_var, int8_t* weight_depth_wise_48_buffer_var, int8_t* weight_1x1_conv2d_linear_48_buffer_var, int8_t* output_buffer_var, uint8_t* global_workspace_0_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* fusion_iter_worker, uint8_t* global_workspace_1_var) {
  void* iterator_let = (&(global_workspace_1_var[3124]));
  void* iteratee_output_let = (&(global_workspace_1_var[3140]));
  void* bg_ind_let = (&(global_workspace_1_var[3204]));
  void* cache_buffer_var_let = (&(global_workspace_1_var[2784]));
  void* cache_cur_idx_let = (&(global_workspace_1_var[3188]));
  void* cache_buffer_var_let_1 = (&(global_workspace_1_var[2352]));
  void* cache_cur_idx_let_1 = (&(global_workspace_1_var[3172]));
  void* cache_buffer_var_let_2 = (&(global_workspace_1_var[1176]));
  void* cache_cur_idx_let_2 = (&(global_workspace_1_var[3156]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_1)[0] = 0;
  ((int32_t*)cache_cur_idx_let_1)[1] = 0;
  ((int32_t*)cache_cur_idx_let_1)[2] = 0;
  ((int32_t*)cache_cur_idx_let_1)[3] = 0;
  ((int8_t*)cache_buffer_var_let_2)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_2)[0] = 0;
  ((int32_t*)cache_cur_idx_let_2)[1] = 0;
  ((int32_t*)cache_cur_idx_let_2)[2] = 0;
  ((int32_t*)cache_cur_idx_let_2)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 43))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 43))) { break; }
      if (tvmgen_default_iteratee_5(iterator_let, p0, p1, p2, p3, p4, p5, p6, cache_buffer_var_let, cache_cur_idx_let, cache_buffer_var_let_1, cache_cur_idx_let_1, cache_buffer_var_let_2, cache_cur_idx_let_2, iteratee_output_let, global_workspace_1_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 16; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 30976) + (i * 1936)) + (((int32_t*)bg_ind_let)[1] * 1936)) + (((int32_t*)bg_ind_let)[2] * 44)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 43) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 4);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_1)[0] = 0;
    ((int32_t*)cache_cur_idx_let_1)[1] = 0;
    ((int32_t*)cache_cur_idx_let_1)[2] = 0;
    ((int32_t*)cache_cur_idx_let_1)[3] = 0;
    ((int8_t*)cache_buffer_var_let_2)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_2)[0] = 0;
    ((int32_t*)cache_cur_idx_let_2)[1] = 0;
    ((int32_t*)cache_cur_idx_let_2)[2] = 0;
    ((int32_t*)cache_cur_idx_let_2)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 4);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_1(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_3_var) {
  void* iterator_let = (&(global_workspace_3_var[63392]));
  void* iteratee_output_let = (&(global_workspace_3_var[63408]));
  void* bg_ind_let = (&(global_workspace_3_var[63440]));
  void* cache_buffer_var_let = (&(global_workspace_3_var[62672]));
  void* cache_cur_idx_let = (&(global_workspace_3_var[63424]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 43))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 43))) { break; }
      if (tvmgen_default_iteratee_8(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_3_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 16; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 30976) + (i * 1936)) + (((int32_t*)bg_ind_let)[1] * 1936)) + (((int32_t*)bg_ind_let)[2] * 44)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 43) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_10(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_23_var) {
  void* iterator_let = (&(global_workspace_23_var[56064]));
  void* iteratee_output_let = (&(global_workspace_23_var[55584]));
  void* bg_ind_let = (&(global_workspace_23_var[56096]));
  void* cache_buffer_var_let = (&(global_workspace_23_var[17280]));
  void* cache_cur_idx_let = (&(global_workspace_23_var[56080]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 5))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 5))) { break; }
      if (tvmgen_default_iteratee_45(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_23_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 480; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 17280) + (i * 36)) + (((int32_t*)bg_ind_let)[1] * 36)) + (((int32_t*)bg_ind_let)[2] * 6)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 5) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_11(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_26_var) {
  void* iterator_let = (&(global_workspace_26_var[960]));
  void* iteratee_output_let = (&(global_workspace_26_var[480]));
  void* bg_ind_let = (&(global_workspace_26_var[976]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 5))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 5))) { break; }
      if (tvmgen_default_iteratee_48(iterator_let, p0, p1, p2, iteratee_output_let, global_workspace_26_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 384; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 13824) + (i * 36)) + (((int32_t*)bg_ind_let)[1] * 36)) + (((int32_t*)bg_ind_let)[2] * 6)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 5) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_12(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_28_var) {
  void* iterator_let = (&(global_workspace_28_var[25824]));
  void* iteratee_output_let = (&(global_workspace_28_var[25344]));
  void* bg_ind_let = (&(global_workspace_28_var[25856]));
  void* cache_buffer_var_let = (&(global_workspace_28_var[17280]));
  void* cache_cur_idx_let = (&(global_workspace_28_var[25840]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 5))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 5))) { break; }
      if (tvmgen_default_iteratee_51(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_28_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 480; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 17280) + (i * 36)) + (((int32_t*)bg_ind_let)[1] * 36)) + (((int32_t*)bg_ind_let)[2] * 6)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 5) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_2(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* p7, int8_t* p8, int8_t* p9, int8_t* fusion_iter_worker, uint8_t* global_workspace_5_var) {
  void* iterator_let = (&(global_workspace_5_var[56136]));
  void* iteratee_output_let = (&(global_workspace_5_var[56112]));
  void* bg_ind_let = (&(global_workspace_5_var[56200]));
  void* cache_buffer_var_let = (&(global_workspace_5_var[42592]));
  void* cache_cur_idx_let = (&(global_workspace_5_var[56184]));
  void* cache_buffer_var_let_1 = (&(global_workspace_5_var[50992]));
  void* cache_cur_idx_let_1 = (&(global_workspace_5_var[56168]));
  void* cache_buffer_var_let_2 = (&(global_workspace_5_var[53872]));
  void* cache_cur_idx_let_2 = (&(global_workspace_5_var[56152]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_1)[0] = 0;
  ((int32_t*)cache_cur_idx_let_1)[1] = 0;
  ((int32_t*)cache_cur_idx_let_1)[2] = 0;
  ((int32_t*)cache_cur_idx_let_1)[3] = 0;
  ((int8_t*)cache_buffer_var_let_2)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_2)[0] = 0;
  ((int32_t*)cache_cur_idx_let_2)[1] = 0;
  ((int32_t*)cache_cur_idx_let_2)[2] = 0;
  ((int32_t*)cache_cur_idx_let_2)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 21))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 21))) { break; }
      if (tvmgen_default_iteratee_17(iterator_let, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, cache_buffer_var_let, cache_cur_idx_let, cache_buffer_var_let_1, cache_cur_idx_let_1, cache_buffer_var_let_2, cache_cur_idx_let_2, iteratee_output_let, global_workspace_5_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 24; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 11616) + (i * 484)) + (((int32_t*)bg_ind_let)[1] * 484)) + (((int32_t*)bg_ind_let)[2] * 22)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 21) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_1)[0] = 0;
    ((int32_t*)cache_cur_idx_let_1)[1] = 0;
    ((int32_t*)cache_cur_idx_let_1)[2] = 0;
    ((int32_t*)cache_cur_idx_let_1)[3] = 0;
    ((int8_t*)cache_buffer_var_let_2)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_2)[0] = 0;
    ((int32_t*)cache_cur_idx_let_2)[1] = 0;
    ((int32_t*)cache_cur_idx_let_2)[2] = 0;
    ((int32_t*)cache_cur_idx_let_2)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_3(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_7_var) {
  void* iterator_let = (&(global_workspace_7_var[6144]));
  void* iteratee_output_let = (&(global_workspace_7_var[6120]));
  void* bg_ind_let = (&(global_workspace_7_var[6176]));
  void* cache_buffer_var_let = (&(global_workspace_7_var[0]));
  void* cache_cur_idx_let = (&(global_workspace_7_var[6160]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 21))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 21))) { break; }
      if (tvmgen_default_iteratee_20(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_7_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 24; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 11616) + (i * 484)) + (((int32_t*)bg_ind_let)[1] * 484)) + (((int32_t*)bg_ind_let)[2] * 22)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 21) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_4(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* p4, int8_t* p5, int8_t* p6, int8_t* p7, int8_t* fusion_iter_worker, uint8_t* global_workspace_9_var) {
  void* iterator_let = (&(global_workspace_9_var[39768]));
  void* iteratee_output_let = (&(global_workspace_9_var[39360]));
  void* bg_ind_let = (&(global_workspace_9_var[39816]));
  void* cache_buffer_var_let = (&(global_workspace_9_var[29040]));
  void* cache_cur_idx_let = (&(global_workspace_9_var[39784]));
  void* cache_buffer_var_let_1 = (&(global_workspace_9_var[37440]));
  void* cache_cur_idx_let_1 = (&(global_workspace_9_var[39800]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let_1)[0] = 0;
  ((int32_t*)cache_cur_idx_let_1)[1] = 0;
  ((int32_t*)cache_cur_idx_let_1)[2] = 0;
  ((int32_t*)cache_cur_idx_let_1)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_27(iterator_let, p0, p1, p2, p3, p4, p5, p6, p7, cache_buffer_var_let, cache_cur_idx_let, cache_buffer_var_let_1, cache_cur_idx_let_1, iteratee_output_let, global_workspace_9_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 240; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 29040) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 2);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int8_t*)cache_buffer_var_let_1)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let_1)[0] = 0;
    ((int32_t*)cache_cur_idx_let_1)[1] = 0;
    ((int32_t*)cache_cur_idx_let_1)[2] = 0;
    ((int32_t*)cache_cur_idx_let_1)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 2);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_5(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_11_var) {
  void* iterator_let = (&(global_workspace_11_var[62000]));
  void* iteratee_output_let = (&(global_workspace_11_var[61840]));
  void* bg_ind_let = (&(global_workspace_11_var[62032]));
  void* cache_buffer_var_let = (&(global_workspace_11_var[48400]));
  void* cache_cur_idx_let = (&(global_workspace_11_var[62016]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_30(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_11_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 160; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 19360) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_6(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_13_var) {
  void* iterator_let = (&(global_workspace_13_var[49400]));
  void* iteratee_output_let = (&(global_workspace_13_var[49200]));
  void* bg_ind_let = (&(global_workspace_13_var[49432]));
  void* cache_buffer_var_let = (&(global_workspace_13_var[24200]));
  void* cache_cur_idx_let = (&(global_workspace_13_var[49416]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_33(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_13_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 200; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 24200) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_7(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* p3, int8_t* fusion_iter_worker, uint8_t* global_workspace_15_var) {
  void* iterator_let = (&(global_workspace_15_var[25440]));
  void* iteratee_output_let = (&(global_workspace_15_var[25200]));
  void* bg_ind_let = (&(global_workspace_15_var[25472]));
  void* cache_buffer_var_let = (&(global_workspace_15_var[58080]));
  void* cache_cur_idx_let = (&(global_workspace_15_var[25456]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_36(iterator_let, p0, p1, p2, p3, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_15_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 240; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 29040) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_8(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_18_var) {
  void* iterator_let = (&(global_workspace_18_var[58560]));
  void* iteratee_output_let = (&(global_workspace_18_var[58080]));
  void* bg_ind_let = (&(global_workspace_18_var[58576]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_39(iterator_let, p0, p1, p2, iteratee_output_let, global_workspace_18_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 240; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 29040) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker_9(int8_t* p0, int8_t* p1, int8_t* p2, int8_t* fusion_iter_worker, uint8_t* global_workspace_20_var) {
  void* iterator_let = (&(global_workspace_20_var[10896]));
  void* iteratee_output_let = (&(global_workspace_20_var[10848]));
  void* bg_ind_let = (&(global_workspace_20_var[10928]));
  void* cache_buffer_var_let = (&(global_workspace_20_var[7968]));
  void* cache_cur_idx_let = (&(global_workspace_20_var[10912]));
  p0[0] = (int8_t)0;
  fusion_iter_worker[0] = (int8_t)0;
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int8_t*)iteratee_output_let)[0] = (int8_t)0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
  ((int32_t*)cache_cur_idx_let)[0] = 0;
  ((int32_t*)cache_cur_idx_let)[1] = 0;
  ((int32_t*)cache_cur_idx_let)[2] = 0;
  ((int32_t*)cache_cur_idx_let)[3] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 10))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 10))) { break; }
      if (tvmgen_default_iteratee_41(iterator_let, p0, p1, p2, cache_buffer_var_let, cache_cur_idx_let, iteratee_output_let, global_workspace_20_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 48; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 5808) + (i * 121)) + (((int32_t*)bg_ind_let)[1] * 121)) + (((int32_t*)bg_ind_let)[2] * 11)) + ((int32_t*)bg_ind_let)[3])] = ((int8_t*)iteratee_output_let)[i];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 10) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int8_t*)cache_buffer_var_let)[0] = (int8_t)0;
    ((int32_t*)cache_cur_idx_let)[0] = 0;
    ((int32_t*)cache_cur_idx_let)[1] = 0;
    ((int32_t*)cache_cur_idx_let)[2] = 0;
    ((int32_t*)cache_cur_idx_let)[3] = 0;
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_17_var) {
  for (int32_t c = 0; c < 240; ++c) {
    for (int32_t i = 0; i < 11; ++i) {
      for (int32_t j = 0; j < 11; ++j) {
        DepthwiseConv2d[(((c * 121) + (i * 11)) + j)] = (int8_t)0;
        for (int32_t di = 0; di < 7; ++di) {
          for (int32_t dj = 0; dj < 7; ++dj) {
            int32_t cse_var_2 = (c * 121);
            int32_t cse_var_1 = ((cse_var_2 + (i * 11)) + j);
            DepthwiseConv2d[cse_var_1] = (DepthwiseConv2d[cse_var_1] + (p0[((cse_var_2 + (((i + di) % 11) * 11)) + ((j + dj) % 11))] * p1[(((c * 49) + (di * 7)) + dj)]));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_1(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_22_var) {
  for (int32_t ff = 0; ff < 288; ++ff) {
    for (int32_t yy = 0; yy < 11; ++yy) {
      for (int32_t xx = 0; xx < 11; ++xx) {
        conv2d_nchw[(((ff * 121) + (yy * 11)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 48; ++rc) {
          int32_t cse_var_2 = (yy * 11);
          int32_t cse_var_1 = (((ff * 121) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 121) + cse_var_2) + xx)] * p1[((ff * 48) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_2(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_25_var) {
  for (int32_t c = 0; c < 480; ++c) {
    for (int32_t i = 0; i < 6; ++i) {
      for (int32_t j = 0; j < 6; ++j) {
        DepthwiseConv2d[(((c * 36) + (i * 6)) + j)] = (int8_t)0;
        for (int32_t di = 0; di < 7; ++di) {
          for (int32_t dj = 0; dj < 7; ++dj) {
            int32_t cse_var_2 = (c * 36);
            int32_t cse_var_1 = ((cse_var_2 + (i * 6)) + j);
            DepthwiseConv2d[cse_var_1] = (DepthwiseConv2d[cse_var_1] + (p0[((cse_var_2 + (((i + di) % 6) * 6)) + ((j + dj) % 6))] * p1[(((c * 49) + (di * 7)) + dj)]));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_3(int8_t* p0, int8_t* p1, int8_t* DepthwiseConv2d, uint8_t* global_workspace_30_var) {
  for (int32_t c = 0; c < 480; ++c) {
    for (int32_t i = 0; i < 6; ++i) {
      for (int32_t j = 0; j < 6; ++j) {
        DepthwiseConv2d[(((c * 36) + (i * 6)) + j)] = (int8_t)0;
        for (int32_t di = 0; di < 7; ++di) {
          for (int32_t dj = 0; dj < 7; ++dj) {
            int32_t cse_var_2 = (c * 36);
            int32_t cse_var_1 = ((cse_var_2 + (i * 6)) + j);
            DepthwiseConv2d[cse_var_1] = (DepthwiseConv2d[cse_var_1] + (p0[((cse_var_2 + (((i + di) % 6) * 6)) + ((j + dj) % 6))] * p1[(((c * 49) + (di * 7)) + dj)]));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_4(int8_t* p0, int8_t* p1, int8_t* conv2d_nchw, uint8_t* global_workspace_31_var) {
  for (int32_t ff = 0; ff < 160; ++ff) {
    for (int32_t yy = 0; yy < 6; ++yy) {
      for (int32_t xx = 0; xx < 6; ++xx) {
        conv2d_nchw[(((ff * 36) + (yy * 6)) + xx)] = (int8_t)0;
        for (int32_t rc = 0; rc < 480; ++rc) {
          int32_t cse_var_2 = (yy * 6);
          int32_t cse_var_1 = (((ff * 36) + cse_var_2) + xx);
          conv2d_nchw[cse_var_1] = (conv2d_nchw[cse_var_1] + (p0[(((rc * 36) + cse_var_2) + xx)] * p1[((ff * 480) + rc)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_17(int32_t* iterator, int8_t* dummy_input_9, int8_t* weight_1x1_conv2d_34, int8_t* weight_depth_wise_34, int8_t* weight_1x1_conv2d_linear_34, int8_t* weight_1x1_conv2d_35, int8_t* weight_depth_wise_35, int8_t* weight_1x1_conv2d_linear_35, int8_t* weight_1x1_conv2d_36, int8_t* weight_depth_wise_36, int8_t* weight_1x1_conv2d_linear_36, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* cache_buffer_var_2, int32_t* cache_cur_idx_2, int8_t* conv2d_nchw, uint8_t* global_workspace_6_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_6_var[55872]));
  void* conv2d_nchw_let = (&(global_workspace_6_var[8400]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_6_var[0]));
  for (int32_t i1 = 0; i1 < 16; ++i1) {
    for (int32_t i2 = 0; i2 < 15; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 15) + i2)] = dummy_input_9[((((((iterator[0] * 30976) + (i1 * 1936)) + (iterator[1] * 1936)) + (i2 * 44)) + (iterator[2] * 44)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 80; ++ff) {
    for (int32_t yy = 0; yy < 15; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 15) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 16; ++rc) {
        int32_t cse_var_1 = ((ff * 15) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 15) + yy)] * weight_1x1_conv2d_34[((ff * 16) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 80; ++i) {
      for (int32_t j = 0; j < 15; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 105) + (j * 7)) + ((cache_cur_idx[3] % 6) + (6 & ((cache_cur_idx[3] % 6) >> 31))))] = ((int8_t*)conv2d_nchw_let)[((i * 15) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (6 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 80; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 15; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 7; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 105) + (j_2 * 7)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 80; ++c) {
    for (int32_t i_1 = 0; i_1 < 9; ++i_1) {
      ((int8_t*)conv2d_nchw_let)[((c * 9) + i_1)] = (int8_t)0;
      for (int32_t di = 0; di < 7; ++di) {
        for (int32_t dj = 0; dj < 7; ++dj) {
          int32_t cse_var_4 = (di * 7);
          int32_t cse_var_3 = ((c * 9) + i_1);
          ((int8_t*)conv2d_nchw_let)[cse_var_3] = (((int8_t*)conv2d_nchw_let)[cse_var_3] + (((int8_t*)cache_conv_input_compute_generic_let)[((((c * 105) + (i_1 * 7)) + cse_var_4) + dj)] * weight_depth_wise_34[(((c * 49) + cse_var_4) + dj)]));
        }
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 16; ++ff_1) {
    for (int32_t yy_1 = 0; yy_1 < 9; ++yy_1) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_1 * 9) + yy_1)] = (int8_t)0;
      for (int32_t rc_1 = 0; rc_1 < 80; ++rc_1) {
        int32_t cse_var_5 = ((ff_1 * 9) + yy_1);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] + (((int8_t*)conv2d_nchw_let)[((rc_1 * 9) + yy_1)] * weight_1x1_conv2d_linear_34[((ff_1 * 80) + rc_1)]));
      }
    }
  }
  for (int32_t ff_2 = 0; ff_2 < 64; ++ff_2) {
    for (int32_t yy_2 = 0; yy_2 < 9; ++yy_2) {
      ((int8_t*)conv2d_nchw_let)[((ff_2 * 9) + yy_2)] = (int8_t)0;
      for (int32_t rc_2 = 0; rc_2 < 16; ++rc_2) {
        int32_t cse_var_6 = ((ff_2 * 9) + yy_2);
        ((int8_t*)conv2d_nchw_let)[cse_var_6] = (((int8_t*)conv2d_nchw_let)[cse_var_6] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_2 * 9) + yy_2)] * weight_1x1_conv2d_35[((ff_2 * 16) + rc_2)]));
      }
    }
  }
  for (int32_t n_2 = 0; n_2 < 1; ++n_2) {
    for (int32_t i_2 = 0; i_2 < 64; ++i_2) {
      for (int32_t j_3 = 0; j_3 < 9; ++j_3) {
        for (int32_t k_2 = 0; k_2 < 1; ++k_2) {
          cache_buffer_var_1[(((i_2 * 45) + (j_3 * 5)) + (cache_cur_idx_1[3] & 3))] = ((int8_t*)conv2d_nchw_let)[((i_2 * 9) + j_3)];
        }
      }
    }
  }
  cache_cur_idx_1[3] = (cache_cur_idx_1[3] + 1);
  if (4 <= cache_cur_idx_1[3]) {
    for (int32_t n_3 = 0; n_3 < 1; ++n_3) {
      for (int32_t j_4 = 0; j_4 < 64; ++j_4) {
        for (int32_t j_5 = 0; j_5 < 9; ++j_5) {
          for (int32_t k_3 = 0; k_3 < 5; ++k_3) {
            int32_t cse_var_7 = (((j_4 * 45) + (j_5 * 5)) + k_3);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_7] = cache_buffer_var_1[cse_var_7];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_1 = 0; c_1 < 64; ++c_1) {
    for (int32_t i_3 = 0; i_3 < 5; ++i_3) {
      ((int8_t*)conv2d_nchw_let)[((c_1 * 5) + i_3)] = (int8_t)0;
      for (int32_t di_1 = 0; di_1 < 5; ++di_1) {
        for (int32_t dj_1 = 0; dj_1 < 5; ++dj_1) {
          int32_t cse_var_9 = (di_1 * 5);
          int32_t cse_var_8 = ((c_1 * 5) + i_3);
          ((int8_t*)conv2d_nchw_let)[cse_var_8] = (((int8_t*)conv2d_nchw_let)[cse_var_8] + (((int8_t*)cache_conv_input_compute_generic_let)[((((c_1 * 45) + (i_3 * 5)) + cse_var_9) + dj_1)] * weight_depth_wise_35[(((c_1 * 25) + cse_var_9) + dj_1)]));
        }
      }
    }
  }
  for (int32_t ff_3 = 0; ff_3 < 16; ++ff_3) {
    for (int32_t yy_3 = 0; yy_3 < 5; ++yy_3) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_3 * 5) + yy_3)] = (int8_t)0;
      for (int32_t rc_3 = 0; rc_3 < 64; ++rc_3) {
        int32_t cse_var_10 = ((ff_3 * 5) + yy_3);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_10] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_10] + (((int8_t*)conv2d_nchw_let)[((rc_3 * 5) + yy_3)] * weight_1x1_conv2d_linear_35[((ff_3 * 64) + rc_3)]));
      }
    }
  }
  for (int32_t ff_4 = 0; ff_4 < 80; ++ff_4) {
    for (int32_t yy_4 = 0; yy_4 < 5; ++yy_4) {
      ((int8_t*)conv2d_nchw_let)[((ff_4 * 5) + yy_4)] = (int8_t)0;
      for (int32_t rc_4 = 0; rc_4 < 16; ++rc_4) {
        int32_t cse_var_11 = ((ff_4 * 5) + yy_4);
        ((int8_t*)conv2d_nchw_let)[cse_var_11] = (((int8_t*)conv2d_nchw_let)[cse_var_11] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_4 * 5) + yy_4)] * weight_1x1_conv2d_36[((ff_4 * 16) + rc_4)]));
      }
    }
  }
  for (int32_t n_4 = 0; n_4 < 1; ++n_4) {
    for (int32_t i_4 = 0; i_4 < 80; ++i_4) {
      for (int32_t j_6 = 0; j_6 < 5; ++j_6) {
        for (int32_t k_4 = 0; k_4 < 1; ++k_4) {
          cache_buffer_var_2[(((i_4 * 25) + (j_6 * 5)) + (cache_cur_idx_2[3] & 3))] = ((int8_t*)conv2d_nchw_let)[((i_4 * 5) + j_6)];
        }
      }
    }
  }
  cache_cur_idx_2[3] = (cache_cur_idx_2[3] + 1);
  if ((4 <= cache_cur_idx_2[3]) && ((cache_cur_idx_2[3] % 2) == 0)) {
    for (int32_t n_5 = 0; n_5 < 1; ++n_5) {
      for (int32_t j_7 = 0; j_7 < 80; ++j_7) {
        for (int32_t j_8 = 0; j_8 < 5; ++j_8) {
          for (int32_t k_5 = 0; k_5 < 5; ++k_5) {
            int32_t cse_var_12 = (((j_7 * 25) + (j_8 * 5)) + k_5);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_12] = cache_buffer_var_2[cse_var_12];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_2 = 0; c_2 < 80; ++c_2) {
    ((int8_t*)dyn_slice_fixed_size_let)[c_2] = (int8_t)0;
    for (int32_t di_2 = 0; di_2 < 5; ++di_2) {
      for (int32_t dj_2 = 0; dj_2 < 5; ++dj_2) {
        int32_t cse_var_13 = (((c_2 * 25) + (di_2 * 5)) + dj_2);
        ((int8_t*)dyn_slice_fixed_size_let)[c_2] = (((int8_t*)dyn_slice_fixed_size_let)[c_2] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_13] * weight_depth_wise_36[cse_var_13]));
      }
    }
  }
  for (int32_t ff_5 = 0; ff_5 < 24; ++ff_5) {
    conv2d_nchw[ff_5] = (int8_t)0;
    for (int32_t rc_5 = 0; rc_5 < 80; ++rc_5) {
      conv2d_nchw[ff_5] = (conv2d_nchw[ff_5] + (((int8_t*)dyn_slice_fixed_size_let)[rc_5] * weight_1x1_conv2d_linear_36[((ff_5 * 80) + rc_5)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_20(int32_t* iterator, int8_t* dummy_input_18, int8_t* weight_1x1_conv2d_37, int8_t* weight_depth_wise_37, int8_t* weight_1x1_conv2d_linear_37, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_8_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_8_var[6000]));
  void* conv2d_nchw_let = (&(global_workspace_8_var[3000]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_8_var[3000]));
  for (int32_t i1 = 0; i1 < 24; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_18[((((((iterator[0] * 11616) + (i1 * 484)) + (iterator[1] * 484)) + (i2 * 22)) + (iterator[2] * 22)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 120; ++ff) {
    for (int32_t yy = 0; yy < 5; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 5) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 24; ++rc) {
        int32_t cse_var_1 = ((ff * 5) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 5) + yy)] * weight_1x1_conv2d_37[((ff * 24) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 120; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)conv2d_nchw_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 120; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 120; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_3 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_3] * weight_depth_wise_37[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 24; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 120; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)dyn_slice_fixed_size_let)[rc_1] * weight_1x1_conv2d_linear_37[((ff_1 * 120) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_27(int32_t* iterator, int8_t* dummy_input_21, int8_t* weight_1x1_conv2d_38, int8_t* weight_depth_wise_38, int8_t* weight_1x1_conv2d_linear_38, int8_t* weight_1x1_conv2d_39, int8_t* weight_depth_wise_39, int8_t* weight_1x1_conv2d_linear_39, int8_t* weight_1x1_conv2d_40, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* conv2d_nchw, uint8_t* global_workspace_10_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_10_var[39600]));
  void* conv2d_nchw_let = (&(global_workspace_10_var[38520]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_10_var[33240]));
  void* conv2d_nchw_let_1 = (&(global_workspace_10_var[33240]));
  for (int32_t i1 = 0; i1 < 24; ++i1) {
    for (int32_t i2 = 0; i2 < 7; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 7) + i2)] = dummy_input_21[((((((iterator[0] * 11616) + (i1 * 484)) + (iterator[1] * 484)) + (i2 * 22)) + (iterator[2] * 22)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 120; ++ff) {
    for (int32_t yy = 0; yy < 7; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 7) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 24; ++rc) {
        int32_t cse_var_1 = ((ff * 7) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 7) + yy)] * weight_1x1_conv2d_38[((ff * 24) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 120; ++i) {
      for (int32_t j = 0; j < 7; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 35) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)conv2d_nchw_let)[((i * 7) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 120; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 7; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 35) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 120; ++c) {
    for (int32_t i_1 = 0; i_1 < 3; ++i_1) {
      ((int8_t*)conv2d_nchw_let)[((c * 3) + i_1)] = (int8_t)0;
      for (int32_t di = 0; di < 5; ++di) {
        for (int32_t dj = 0; dj < 5; ++dj) {
          int32_t cse_var_4 = (di * 5);
          int32_t cse_var_3 = ((c * 3) + i_1);
          ((int8_t*)conv2d_nchw_let)[cse_var_3] = (((int8_t*)conv2d_nchw_let)[cse_var_3] + (((int8_t*)cache_conv_input_compute_generic_let)[((((c * 35) + (i_1 * 5)) + cse_var_4) + dj)] * weight_depth_wise_38[(((c * 25) + cse_var_4) + dj)]));
        }
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 24; ++ff_1) {
    for (int32_t yy_1 = 0; yy_1 < 3; ++yy_1) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_1 * 3) + yy_1)] = (int8_t)0;
      for (int32_t rc_1 = 0; rc_1 < 120; ++rc_1) {
        int32_t cse_var_5 = ((ff_1 * 3) + yy_1);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] + (((int8_t*)conv2d_nchw_let)[((rc_1 * 3) + yy_1)] * weight_1x1_conv2d_linear_38[((ff_1 * 120) + rc_1)]));
      }
    }
  }
  for (int32_t ff_2 = 0; ff_2 < 120; ++ff_2) {
    for (int32_t yy_2 = 0; yy_2 < 3; ++yy_2) {
      ((int8_t*)conv2d_nchw_let)[((ff_2 * 3) + yy_2)] = (int8_t)0;
      for (int32_t rc_2 = 0; rc_2 < 24; ++rc_2) {
        int32_t cse_var_6 = ((ff_2 * 3) + yy_2);
        ((int8_t*)conv2d_nchw_let)[cse_var_6] = (((int8_t*)conv2d_nchw_let)[cse_var_6] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_2 * 3) + yy_2)] * weight_1x1_conv2d_39[((ff_2 * 24) + rc_2)]));
      }
    }
  }
  for (int32_t n_2 = 0; n_2 < 1; ++n_2) {
    for (int32_t i_2 = 0; i_2 < 120; ++i_2) {
      for (int32_t j_3 = 0; j_3 < 3; ++j_3) {
        for (int32_t k_2 = 0; k_2 < 1; ++k_2) {
          cache_buffer_var_1[(((i_2 * 9) + (j_3 * 3)) + (cache_cur_idx_1[3] & 1))] = ((int8_t*)conv2d_nchw_let)[((i_2 * 3) + j_3)];
        }
      }
    }
  }
  cache_cur_idx_1[3] = (cache_cur_idx_1[3] + 1);
  if ((2 <= cache_cur_idx_1[3]) && ((cache_cur_idx_1[3] % 2) == 0)) {
    for (int32_t n_3 = 0; n_3 < 1; ++n_3) {
      for (int32_t j_4 = 0; j_4 < 120; ++j_4) {
        for (int32_t j_5 = 0; j_5 < 3; ++j_5) {
          for (int32_t k_3 = 0; k_3 < 3; ++k_3) {
            int32_t cse_var_7 = (((j_4 * 9) + (j_5 * 3)) + k_3);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_7] = cache_buffer_var_1[cse_var_7];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_1 = 0; c_1 < 120; ++c_1) {
    ((int8_t*)dyn_slice_fixed_size_let)[c_1] = (int8_t)0;
    for (int32_t di_1 = 0; di_1 < 3; ++di_1) {
      for (int32_t dj_1 = 0; dj_1 < 3; ++dj_1) {
        int32_t cse_var_8 = (((c_1 * 9) + (di_1 * 3)) + dj_1);
        ((int8_t*)dyn_slice_fixed_size_let)[c_1] = (((int8_t*)dyn_slice_fixed_size_let)[c_1] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_8] * weight_depth_wise_39[cse_var_8]));
      }
    }
  }
  for (int32_t ff_3 = 0; ff_3 < 40; ++ff_3) {
    ((int8_t*)conv2d_nchw_let_1)[ff_3] = (int8_t)0;
    for (int32_t rc_3 = 0; rc_3 < 120; ++rc_3) {
      ((int8_t*)conv2d_nchw_let_1)[ff_3] = (((int8_t*)conv2d_nchw_let_1)[ff_3] + (((int8_t*)dyn_slice_fixed_size_let)[rc_3] * weight_1x1_conv2d_linear_39[((ff_3 * 120) + rc_3)]));
    }
  }
  for (int32_t ff_4 = 0; ff_4 < 240; ++ff_4) {
    conv2d_nchw[ff_4] = (int8_t)0;
    for (int32_t rc_4 = 0; rc_4 < 40; ++rc_4) {
      conv2d_nchw[ff_4] = (conv2d_nchw[ff_4] + (((int8_t*)conv2d_nchw_let_1)[rc_4] * weight_1x1_conv2d_40[((ff_4 * 40) + rc_4)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_30(int32_t* iterator, int8_t* dummy_input_28, int8_t* weight_depth_wise_40, int8_t* weight_1x1_conv2d_linear_40, int8_t* weight_1x1_conv2d_41, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_12_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_12_var[60160]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_12_var[0]));
  void* conv2d_nchw_let = (&(global_workspace_12_var[0]));
  for (int32_t i1 = 0; i1 < 240; ++i1) {
    for (int32_t i2 = 0; i2 < 7; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 7) + i2)] = dummy_input_28[((((((iterator[0] * 29040) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 240; ++i) {
      for (int32_t j = 0; j < 7; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 49) + (j * 7)) + ((cache_cur_idx[3] % 6) + (6 & ((cache_cur_idx[3] % 6) >> 31))))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 7) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (6 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 240; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 7; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 7; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 49) + (j_2 * 7)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 240; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 7; ++di) {
      for (int32_t dj = 0; dj < 7; ++dj) {
        int32_t cse_var_2 = (((c * 49) + (di * 7)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_40[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 40; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 240; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_40[((ff * 240) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 160; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 40; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_41[((ff_1 * 40) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_33(int32_t* iterator, int8_t* dummy_input_31, int8_t* weight_depth_wise_41, int8_t* weight_1x1_conv2d_linear_41, int8_t* weight_1x1_conv2d_42, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_14_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_14_var[48400]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_14_var[28200]));
  void* conv2d_nchw_let = (&(global_workspace_14_var[28200]));
  for (int32_t i1 = 0; i1 < 160; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_31[((((((iterator[0] * 19360) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 160; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 160; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 160; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_2 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_41[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 40; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 160; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_41[((ff * 160) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 200; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 40; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_42[((ff_1 * 40) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_36(int32_t* iterator, int8_t* dummy_input_34, int8_t* weight_depth_wise_42, int8_t* weight_1x1_conv2d_linear_42, int8_t* weight_1x1_conv2d_43, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_16_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_16_var[24200]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_16_var[0]));
  void* conv2d_nchw_let = (&(global_workspace_16_var[0]));
  for (int32_t i1 = 0; i1 < 200; ++i1) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 5) + i2)] = dummy_input_34[((((((iterator[0] * 24200) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 200; ++i) {
      for (int32_t j = 0; j < 5; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 25) + (j * 5)) + (cache_cur_idx[3] & 3))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 5) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (4 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 200; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 5; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 5; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 25) + (j_2 * 5)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 200; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 5; ++di) {
      for (int32_t dj = 0; dj < 5; ++dj) {
        int32_t cse_var_2 = (((c * 25) + (di * 5)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_42[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 200; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_42[((ff * 200) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 240; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 48; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_43[((ff_1 * 48) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_39(int32_t* iterator, int8_t* dummy_input_38, int8_t* weight_1x1_conv2d_linear_43, int8_t* weight_1x1_conv2d_44, int8_t* conv2d_nchw, uint8_t* global_workspace_19_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_19_var[58320]));
  void* conv2d_nchw_let = (&(global_workspace_19_var[0]));
  for (int32_t i1 = 0; i1 < 240; ++i1) {
    ((int8_t*)dyn_slice_fixed_size_let)[i1] = dummy_input_38[(((((iterator[0] * 29040) + (i1 * 121)) + (iterator[1] * 121)) + (iterator[2] * 11)) + iterator[3])];
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 240; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_43[((ff * 240) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 240; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 48; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_44[((ff_1 * 48) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_41(int32_t* iterator, int8_t* dummy_input_40, int8_t* weight_depth_wise_44, int8_t* weight_1x1_conv2d_linear_44, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_21_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_21_var[10128]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_21_var[0]));
  for (int32_t i1 = 0; i1 < 240; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_40[((((((iterator[0] * 29040) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 240; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 240; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 240; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_44[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 48; ++ff) {
    conv2d_nchw[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 240; ++rc) {
      conv2d_nchw[ff] = (conv2d_nchw[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_44[((ff * 240) + rc)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_45(int32_t* iterator, int8_t* dummy_input_43, int8_t* weight_depth_wise_45, int8_t* weight_1x1_conv2d_linear_45, int8_t* weight_1x1_conv2d_46, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_24_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_24_var[54720]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_24_var[19872]));
  void* conv2d_nchw_let = (&(global_workspace_24_var[19872]));
  for (int32_t i1 = 0; i1 < 288; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_43[((((((iterator[0] * 34848) + (i1 * 121)) + (iterator[1] * 121)) + (i2 * 11)) + (iterator[2] * 11)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 288; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((2 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 288; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 288; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_45[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 96; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 288; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_45[((ff * 288) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 480; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 96; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_46[((ff_1 * 96) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_48(int32_t* iterator, int8_t* dummy_input_47, int8_t* weight_1x1_conv2d_linear_46, int8_t* weight_1x1_conv2d_47, int8_t* conv2d_nchw, uint8_t* global_workspace_27_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_27_var[0]));
  void* conv2d_nchw_let = (&(global_workspace_27_var[864]));
  for (int32_t i1 = 0; i1 < 480; ++i1) {
    ((int8_t*)dyn_slice_fixed_size_let)[i1] = dummy_input_47[(((((iterator[0] * 17280) + (i1 * 36)) + (iterator[1] * 36)) + (iterator[2] * 6)) + iterator[3])];
  }
  for (int32_t ff = 0; ff < 96; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 480; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_46[((ff * 480) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 384; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 96; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_47[((ff_1 * 96) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_5(int32_t* iterator, int8_t* dummy_input_0, int8_t* conv2d_1, int8_t* weight_depth_wise_1, int8_t* conv2d_2, int8_t* weight_1x1_conv2d_32, int8_t* weight_depth_wise_32, int8_t* weight_1x1_conv2d_linear_32, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* cache_buffer_var_1, int32_t* cache_cur_idx_1, int8_t* cache_buffer_var_2, int32_t* cache_cur_idx_2, int8_t* conv2d_nchw, uint8_t* global_workspace_2_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_2_var[2956]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_2_var[0]));
  for (int32_t i1 = 0; i1 < 3; ++i1) {
    for (int32_t i2 = 0; i2 < 19; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 19) + i2)] = dummy_input_0[((((((iterator[0] * 92928) + (i1 * 30976)) + (iterator[1] * 30976)) + (i2 * 176)) + (iterator[2] * 176)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 3; ++i) {
      for (int32_t j = 0; j < 19; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 57) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 19) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if ((2 <= cache_cur_idx[3]) && ((cache_cur_idx[3] % 2) == 0)) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 3; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 19; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 57) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t ff = 0; ff < 16; ++ff) {
    for (int32_t yy = 0; yy < 9; ++yy) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff * 9) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 3; ++rc) {
        for (int32_t ry = 0; ry < 3; ++ry) {
          for (int32_t rx = 0; rx < 3; ++rx) {
            int32_t cse_var_3 = (ry * 3);
            int32_t cse_var_2 = ((ff * 9) + yy);
            ((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] + (((int8_t*)cache_conv_input_compute_generic_let)[((((rc * 57) + (yy * 6)) + cse_var_3) + rx)] * conv2d_1[((((ff * 27) + (rc * 9)) + cse_var_3) + rx)]));
          }
        }
      }
    }
  }
  for (int32_t n_2 = 0; n_2 < 1; ++n_2) {
    for (int32_t i_1 = 0; i_1 < 16; ++i_1) {
      for (int32_t j_3 = 0; j_3 < 9; ++j_3) {
        for (int32_t k_2 = 0; k_2 < 1; ++k_2) {
          cache_buffer_var_1[(((i_1 * 27) + (j_3 * 3)) + (cache_cur_idx_1[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i_1 * 9) + j_3)];
        }
      }
    }
  }
  cache_cur_idx_1[3] = (cache_cur_idx_1[3] + 1);
  if (2 <= cache_cur_idx_1[3]) {
    for (int32_t n_3 = 0; n_3 < 1; ++n_3) {
      for (int32_t j_4 = 0; j_4 < 16; ++j_4) {
        for (int32_t j_5 = 0; j_5 < 9; ++j_5) {
          for (int32_t k_3 = 0; k_3 < 3; ++k_3) {
            int32_t cse_var_4 = (((j_4 * 27) + (j_5 * 3)) + k_3);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_4] = cache_buffer_var_1[cse_var_4];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 16; ++c) {
    for (int32_t i_2 = 0; i_2 < 7; ++i_2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((c * 7) + i_2)] = (int8_t)0;
      for (int32_t di = 0; di < 3; ++di) {
        for (int32_t dj = 0; dj < 3; ++dj) {
          int32_t cse_var_6 = (di * 3);
          int32_t cse_var_5 = ((c * 7) + i_2);
          ((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_5] + (((int8_t*)cache_conv_input_compute_generic_let)[((((c * 27) + (i_2 * 3)) + cse_var_6) + dj)] * weight_depth_wise_1[(((c * 9) + cse_var_6) + dj)]));
        }
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 8; ++ff_1) {
    for (int32_t yy_1 = 0; yy_1 < 7; ++yy_1) {
      ((int8_t*)cache_conv_input_compute_generic_let)[((ff_1 * 7) + yy_1)] = (int8_t)0;
      for (int32_t rc_1 = 0; rc_1 < 16; ++rc_1) {
        int32_t cse_var_7 = ((ff_1 * 7) + yy_1);
        ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_7] = (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_7] + (((int8_t*)dyn_slice_fixed_size_let)[((rc_1 * 7) + yy_1)] * conv2d_2[((ff_1 * 16) + rc_1)]));
      }
    }
  }
  for (int32_t ff_2 = 0; ff_2 < 24; ++ff_2) {
    for (int32_t yy_2 = 0; yy_2 < 7; ++yy_2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((ff_2 * 7) + yy_2)] = (int8_t)0;
      for (int32_t rc_2 = 0; rc_2 < 8; ++rc_2) {
        int32_t cse_var_8 = ((ff_2 * 7) + yy_2);
        ((int8_t*)dyn_slice_fixed_size_let)[cse_var_8] = (((int8_t*)dyn_slice_fixed_size_let)[cse_var_8] + (((int8_t*)cache_conv_input_compute_generic_let)[((rc_2 * 7) + yy_2)] * weight_1x1_conv2d_32[((ff_2 * 8) + rc_2)]));
      }
    }
  }
  for (int32_t n_4 = 0; n_4 < 1; ++n_4) {
    for (int32_t i_3 = 0; i_3 < 24; ++i_3) {
      for (int32_t j_6 = 0; j_6 < 7; ++j_6) {
        for (int32_t k_4 = 0; k_4 < 1; ++k_4) {
          cache_buffer_var_2[(((i_3 * 49) + (j_6 * 7)) + ((cache_cur_idx_2[3] % 6) + (6 & ((cache_cur_idx_2[3] % 6) >> 31))))] = ((int8_t*)dyn_slice_fixed_size_let)[((i_3 * 7) + j_6)];
        }
      }
    }
  }
  cache_cur_idx_2[3] = (cache_cur_idx_2[3] + 1);
  if ((6 <= cache_cur_idx_2[3]) && ((cache_cur_idx_2[3] % 2) == 0)) {
    for (int32_t n_5 = 0; n_5 < 1; ++n_5) {
      for (int32_t j_7 = 0; j_7 < 24; ++j_7) {
        for (int32_t j_8 = 0; j_8 < 7; ++j_8) {
          for (int32_t k_5 = 0; k_5 < 7; ++k_5) {
            int32_t cse_var_9 = (((j_7 * 49) + (j_8 * 7)) + k_5);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_9] = cache_buffer_var_2[cse_var_9];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c_1 = 0; c_1 < 24; ++c_1) {
    ((int8_t*)dyn_slice_fixed_size_let)[c_1] = (int8_t)0;
    for (int32_t di_1 = 0; di_1 < 7; ++di_1) {
      for (int32_t dj_1 = 0; dj_1 < 7; ++dj_1) {
        int32_t cse_var_10 = (((c_1 * 49) + (di_1 * 7)) + dj_1);
        ((int8_t*)dyn_slice_fixed_size_let)[c_1] = (((int8_t*)dyn_slice_fixed_size_let)[c_1] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_10] * weight_depth_wise_32[cse_var_10]));
      }
    }
  }
  for (int32_t ff_3 = 0; ff_3 < 16; ++ff_3) {
    conv2d_nchw[ff_3] = (int8_t)0;
    for (int32_t rc_3 = 0; rc_3 < 24; ++rc_3) {
      conv2d_nchw[ff_3] = (conv2d_nchw[ff_3] + (((int8_t*)dyn_slice_fixed_size_let)[rc_3] * weight_1x1_conv2d_linear_32[((ff_3 * 24) + rc_3)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_51(int32_t* iterator, int8_t* dummy_input_49, int8_t* weight_depth_wise_47, int8_t* weight_1x1_conv2d_linear_47, int8_t* weight_1x1_conv2d_48, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_29_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_29_var[24192]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_29_var[20736]));
  void* conv2d_nchw_let = (&(global_workspace_29_var[20736]));
  for (int32_t i1 = 0; i1 < 384; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_49[((((((iterator[0] * 13824) + (i1 * 36)) + (iterator[1] * 36)) + (i2 * 6)) + (iterator[2] * 6)) + iterator[3])];
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 384; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)dyn_slice_fixed_size_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 384; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_1 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)cache_conv_input_compute_generic_let)[cse_var_1] = cache_buffer_var[cse_var_1];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 384; ++c) {
    ((int8_t*)dyn_slice_fixed_size_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_2 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)dyn_slice_fixed_size_let)[c] = (((int8_t*)dyn_slice_fixed_size_let)[c] + (((int8_t*)cache_conv_input_compute_generic_let)[cse_var_2] * weight_depth_wise_47[cse_var_2]));
      }
    }
  }
  for (int32_t ff = 0; ff < 96; ++ff) {
    ((int8_t*)conv2d_nchw_let)[ff] = (int8_t)0;
    for (int32_t rc = 0; rc < 384; ++rc) {
      ((int8_t*)conv2d_nchw_let)[ff] = (((int8_t*)conv2d_nchw_let)[ff] + (((int8_t*)dyn_slice_fixed_size_let)[rc] * weight_1x1_conv2d_linear_47[((ff * 384) + rc)]));
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 480; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 96; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_48[((ff_1 * 96) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee_8(int32_t* iterator, int8_t* dummy_input_6, int8_t* weight_1x1_conv2d_33, int8_t* weight_depth_wise_33, int8_t* weight_1x1_conv2d_linear_33, int8_t* cache_buffer_var, int32_t* cache_cur_idx, int8_t* conv2d_nchw, uint8_t* global_workspace_4_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_4_var[61952]));
  void* conv2d_nchw_let = (&(global_workspace_4_var[30976]));
  for (int32_t i1 = 0; i1 < 16; ++i1) {
    for (int32_t i2 = 0; i2 < 3; ++i2) {
      ((int8_t*)dyn_slice_fixed_size_let)[((i1 * 3) + i2)] = dummy_input_6[((((((iterator[0] * 30976) + (i1 * 1936)) + (iterator[1] * 1936)) + (i2 * 44)) + (iterator[2] * 44)) + iterator[3])];
    }
  }
  for (int32_t ff = 0; ff < 80; ++ff) {
    for (int32_t yy = 0; yy < 3; ++yy) {
      ((int8_t*)conv2d_nchw_let)[((ff * 3) + yy)] = (int8_t)0;
      for (int32_t rc = 0; rc < 16; ++rc) {
        int32_t cse_var_1 = ((ff * 3) + yy);
        ((int8_t*)conv2d_nchw_let)[cse_var_1] = (((int8_t*)conv2d_nchw_let)[cse_var_1] + (((int8_t*)dyn_slice_fixed_size_let)[((rc * 3) + yy)] * weight_1x1_conv2d_33[((ff * 16) + rc)]));
      }
    }
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 80; ++i) {
      for (int32_t j = 0; j < 3; ++j) {
        for (int32_t k = 0; k < 1; ++k) {
          cache_buffer_var[(((i * 9) + (j * 3)) + (cache_cur_idx[3] & 1))] = ((int8_t*)conv2d_nchw_let)[((i * 3) + j)];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (2 <= cache_cur_idx[3]) {
    for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
      for (int32_t j_1 = 0; j_1 < 80; ++j_1) {
        for (int32_t j_2 = 0; j_2 < 3; ++j_2) {
          for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
            int32_t cse_var_2 = (((j_1 * 9) + (j_2 * 3)) + k_1);
            ((int8_t*)dyn_slice_fixed_size_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t c = 0; c < 80; ++c) {
    ((int8_t*)conv2d_nchw_let)[c] = (int8_t)0;
    for (int32_t di = 0; di < 3; ++di) {
      for (int32_t dj = 0; dj < 3; ++dj) {
        int32_t cse_var_3 = (((c * 9) + (di * 3)) + dj);
        ((int8_t*)conv2d_nchw_let)[c] = (((int8_t*)conv2d_nchw_let)[c] + (((int8_t*)dyn_slice_fixed_size_let)[cse_var_3] * weight_depth_wise_33[cse_var_3]));
      }
    }
  }
  for (int32_t ff_1 = 0; ff_1 < 16; ++ff_1) {
    conv2d_nchw[ff_1] = (int8_t)0;
    for (int32_t rc_1 = 0; rc_1 < 80; ++rc_1) {
      conv2d_nchw[ff_1] = (conv2d_nchw[ff_1] + (((int8_t*)conv2d_nchw_let)[rc_1] * weight_1x1_conv2d_linear_33[((ff_1 * 80) + rc_1)]));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(int8_t* data_buffer_var, int8_t* conv2d_1_buffer_var, int8_t* weight_depth_wise_1_buffer_var, int8_t* conv2d_2_buffer_var, int8_t* weight_1x1_conv2d_32_buffer_var, int8_t* weight_depth_wise_32_buffer_var, int8_t* weight_1x1_conv2d_linear_32_buffer_var, int8_t* weight_1x1_conv2d_33_buffer_var, int8_t* weight_depth_wise_33_buffer_var, int8_t* weight_1x1_conv2d_linear_33_buffer_var, int8_t* weight_1x1_conv2d_34_buffer_var, int8_t* weight_depth_wise_34_buffer_var, int8_t* weight_1x1_conv2d_linear_34_buffer_var, int8_t* weight_1x1_conv2d_35_buffer_var, int8_t* weight_depth_wise_35_buffer_var, int8_t* weight_1x1_conv2d_linear_35_buffer_var, int8_t* weight_1x1_conv2d_36_buffer_var, int8_t* weight_depth_wise_36_buffer_var, int8_t* weight_1x1_conv2d_linear_36_buffer_var, int8_t* weight_1x1_conv2d_37_buffer_var, int8_t* weight_depth_wise_37_buffer_var, int8_t* weight_1x1_conv2d_linear_37_buffer_var, int8_t* weight_1x1_conv2d_38_buffer_var, int8_t* weight_depth_wise_38_buffer_var, int8_t* weight_1x1_conv2d_linear_38_buffer_var, int8_t* weight_1x1_conv2d_39_buffer_var, int8_t* weight_depth_wise_39_buffer_var, int8_t* weight_1x1_conv2d_linear_39_buffer_var, int8_t* weight_1x1_conv2d_40_buffer_var, int8_t* weight_depth_wise_40_buffer_var, int8_t* weight_1x1_conv2d_linear_40_buffer_var, int8_t* weight_1x1_conv2d_41_buffer_var, int8_t* weight_depth_wise_41_buffer_var, int8_t* weight_1x1_conv2d_linear_41_buffer_var, int8_t* weight_1x1_conv2d_42_buffer_var, int8_t* weight_depth_wise_42_buffer_var, int8_t* weight_1x1_conv2d_linear_42_buffer_var, int8_t* weight_1x1_conv2d_43_buffer_var, int8_t* weight_depth_wise_43_buffer_var, int8_t* weight_1x1_conv2d_linear_43_buffer_var, int8_t* weight_1x1_conv2d_44_buffer_var, int8_t* weight_depth_wise_44_buffer_var, int8_t* weight_1x1_conv2d_linear_44_buffer_var, int8_t* weight_1x1_conv2d_45_buffer_var, int8_t* weight_depth_wise_45_buffer_var, int8_t* weight_1x1_conv2d_linear_45_buffer_var, int8_t* weight_1x1_conv2d_46_buffer_var, int8_t* weight_depth_wise_46_buffer_var, int8_t* weight_1x1_conv2d_linear_46_buffer_var, int8_t* weight_1x1_conv2d_47_buffer_var, int8_t* weight_depth_wise_47_buffer_var, int8_t* weight_1x1_conv2d_linear_47_buffer_var, int8_t* weight_1x1_conv2d_48_buffer_var, int8_t* weight_depth_wise_48_buffer_var, int8_t* weight_1x1_conv2d_linear_48_buffer_var, int8_t* output_buffer_var, uint8_t* global_workspace_0_var) {
  void* sid_56_let = (&(global_workspace_0_var[0]));
  void* sid_71_let = (&(global_workspace_0_var[17280]));
  void* sid_55_let = (&(global_workspace_0_var[30976]));
  void* sid_65_let = (&(global_workspace_0_var[2160]));
  void* sid_57_let = (&(global_workspace_0_var[30976]));
  void* sid_58_let = (&(global_workspace_0_var[42592]));
  void* sid_63_let = (&(global_workspace_0_var[0]));
  void* sid_59_let = (&(global_workspace_0_var[0]));
  void* sid_60_let = (&(global_workspace_0_var[29040]));
  void* sid_61_let = (&(global_workspace_0_var[0]));
  void* sid_62_let = (&(global_workspace_0_var[29040]));
  void* sid_64_let = (&(global_workspace_0_var[29040]));
  void* sid_66_let = (&(global_workspace_0_var[19872]));
  void* sid_67_let = (&(global_workspace_0_var[0]));
  void* sid_68_let = (&(global_workspace_0_var[17280]));
  void* sid_69_let = (&(global_workspace_0_var[34560]));
  void* sid_70_let = (&(global_workspace_0_var[0]));
  if (tvmgen_default_fused_fusion_iter_worker(data_buffer_var, conv2d_1_buffer_var, weight_depth_wise_1_buffer_var, conv2d_2_buffer_var, weight_1x1_conv2d_32_buffer_var, weight_depth_wise_32_buffer_var, weight_1x1_conv2d_linear_32_buffer_var, sid_55_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_1(sid_55_let, weight_1x1_conv2d_33_buffer_var, weight_depth_wise_33_buffer_var, weight_1x1_conv2d_linear_33_buffer_var, sid_56_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_2(sid_56_let, weight_1x1_conv2d_34_buffer_var, weight_depth_wise_34_buffer_var, weight_1x1_conv2d_linear_34_buffer_var, weight_1x1_conv2d_35_buffer_var, weight_depth_wise_35_buffer_var, weight_1x1_conv2d_linear_35_buffer_var, weight_1x1_conv2d_36_buffer_var, weight_depth_wise_36_buffer_var, weight_1x1_conv2d_linear_36_buffer_var, sid_57_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_3(sid_57_let, weight_1x1_conv2d_37_buffer_var, weight_depth_wise_37_buffer_var, weight_1x1_conv2d_linear_37_buffer_var, sid_58_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_4(sid_58_let, weight_1x1_conv2d_38_buffer_var, weight_depth_wise_38_buffer_var, weight_1x1_conv2d_linear_38_buffer_var, weight_1x1_conv2d_39_buffer_var, weight_depth_wise_39_buffer_var, weight_1x1_conv2d_linear_39_buffer_var, weight_1x1_conv2d_40_buffer_var, sid_59_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_5(sid_59_let, weight_depth_wise_40_buffer_var, weight_1x1_conv2d_linear_40_buffer_var, weight_1x1_conv2d_41_buffer_var, sid_60_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_6(sid_60_let, weight_depth_wise_41_buffer_var, weight_1x1_conv2d_linear_41_buffer_var, weight_1x1_conv2d_42_buffer_var, sid_61_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_7(sid_61_let, weight_depth_wise_42_buffer_var, weight_1x1_conv2d_linear_42_buffer_var, weight_1x1_conv2d_43_buffer_var, sid_62_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d(sid_62_let, weight_depth_wise_43_buffer_var, sid_63_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_8(sid_63_let, weight_1x1_conv2d_linear_43_buffer_var, weight_1x1_conv2d_44_buffer_var, sid_64_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_9(sid_64_let, weight_depth_wise_44_buffer_var, weight_1x1_conv2d_linear_44_buffer_var, sid_65_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_1(sid_65_let, weight_1x1_conv2d_45_buffer_var, sid_66_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_10(sid_66_let, weight_depth_wise_45_buffer_var, weight_1x1_conv2d_linear_45_buffer_var, weight_1x1_conv2d_46_buffer_var, sid_67_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_2(sid_67_let, weight_depth_wise_46_buffer_var, sid_68_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_11(sid_68_let, weight_1x1_conv2d_linear_46_buffer_var, weight_1x1_conv2d_47_buffer_var, sid_69_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker_12(sid_69_let, weight_depth_wise_47_buffer_var, weight_1x1_conv2d_linear_47_buffer_var, weight_1x1_conv2d_48_buffer_var, sid_70_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_3(sid_70_let, weight_depth_wise_48_buffer_var, sid_71_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_4(sid_71_let, weight_1x1_conv2d_linear_48_buffer_var, output_buffer_var, global_workspace_0_var) != 0 ) return -1;
  return 0;
}


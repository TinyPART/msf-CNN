#ifndef TVMGEN_DEFAULT_H_
#define TVMGEN_DEFAULT_H_
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*!
 * \brief Input tensor weight_1x1_conv2d_15 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_15_SIZE 18816
/*!
 * \brief Input tensor weight_1x1_conv2d_8 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_8_SIZE 2904
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_1 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_1_SIZE 55
/*!
 * \brief Input tensor weight_1x1_conv2d_6 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_6_SIZE 726
/*!
 * \brief Input tensor weight_1x1_conv2d_11 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_11_SIZE 2904
/*!
 * \brief Input tensor weight_depth_wise_14 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_14_SIZE 1782
/*!
 * \brief Input tensor weight_1x1_conv2d_4 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_4_SIZE 384
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_6 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_6_SIZE 726
/*!
 * \brief Input tensor weight_1x1_conv2d_2 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_2_SIZE 150
/*!
 * \brief Input tensor weight_depth_wise_10 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_10_SIZE 1188
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_17 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_17_SIZE 37632
/*!
 * \brief Input tensor weight_depth_wise_9 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_9_SIZE 1188
/*!
 * \brief Input tensor data size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_DATA_SIZE 62208
/*!
 * \brief Input tensor weight_1x1_conv2d_14 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_14_SIZE 6534
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_15 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_15_SIZE 18816
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_2 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_2_SIZE 240
/*!
 * \brief Input tensor weight_depth_wise_17 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_17_SIZE 3024
/*!
 * \brief Input tensor weight_depth_wise_7 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_7_SIZE 594
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_13 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_13_SIZE 6534
/*!
 * \brief Input tensor weight_depth_wise_5 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_5_SIZE 594
/*!
 * \brief Input tensor weight_1x1_conv2d_10 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_10_SIZE 2904
/*!
 * \brief Input tensor conv2d_1 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_CONV2D_1_SIZE 297
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_11 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_11_SIZE 4356
/*!
 * \brief Input tensor weight_depth_wise_3 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_3_SIZE 432
/*!
 * \brief Input tensor weight_depth_wise_13 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_13_SIZE 1782
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_7 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_7_SIZE 1452
/*!
 * \brief Input tensor weight_depth_wise_1 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_1_SIZE 99
/*!
 * \brief Input tensor weight_1x1_conv2d_17 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_17_SIZE 18816
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_3 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_3_SIZE 384
/*!
 * \brief Input tensor weight_1x1_conv2d_9 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_9_SIZE 2904
/*!
 * \brief Input tensor weight_1x1_conv2d_13 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_13_SIZE 6534
/*!
 * \brief Input tensor weight_depth_wise_16 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_16_SIZE 3024
/*!
 * \brief Input tensor weight_1x1_conv2d_7 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_7_SIZE 726
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_8 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_8_SIZE 2904
/*!
 * \brief Input tensor weight_1x1_conv2d_5 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_5_SIZE 726
/*!
 * \brief Input tensor weight_1x1_conv2d_3 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_3_SIZE 384
/*!
 * \brief Input tensor weight_depth_wise_12 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_12_SIZE 1782
/*!
 * \brief Input tensor weight_1x1_conv2d_16 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_16_SIZE 18816
/*!
 * \brief Input tensor weight_1x1_conv2d_1 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_1_SIZE 121
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_4 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_4_SIZE 528
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_16 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_16_SIZE 18816
/*!
 * \brief Input tensor weight_depth_wise_8 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_8_SIZE 1188
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_14 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_14_SIZE 11088
/*!
 * \brief Input tensor weight_1x1_conv2d_12 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_12_SIZE 6534
/*!
 * \brief Input tensor weight_depth_wise_6 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_6_SIZE 594
/*!
 * \brief Input tensor conv2d_2 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_CONV2D_2_SIZE 50176
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_9 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_9_SIZE 2904
/*!
 * \brief Input tensor weight_depth_wise_15 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_15_SIZE 3024
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_12 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_12_SIZE 6534
/*!
 * \brief Input tensor weight_depth_wise_4 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_4_SIZE 432
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_10 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_10_SIZE 2904
/*!
 * \brief Input tensor weight_depth_wise_2 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_2_SIZE 270
/*!
 * \brief Input tensor weight_depth_wise_11 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_11_SIZE 1188
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_5 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_5_SIZE 726
/*!
 * \brief Output tensor output size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_OUTPUT_SIZE 11200
/*!
 * \brief Input tensor pointers for TVM module "default" 
 */
struct tvmgen_default_inputs {
  void* data;
  void* conv2d_1;
  void* weight_1x1_conv2d_1;
  void* weight_depth_wise_1;
  void* weight_1x1_conv2d_linear_1;
  void* weight_1x1_conv2d_2;
  void* weight_depth_wise_2;
  void* weight_1x1_conv2d_linear_2;
  void* weight_1x1_conv2d_3;
  void* weight_depth_wise_3;
  void* weight_1x1_conv2d_linear_3;
  void* weight_1x1_conv2d_4;
  void* weight_depth_wise_4;
  void* weight_1x1_conv2d_linear_4;
  void* weight_1x1_conv2d_5;
  void* weight_depth_wise_5;
  void* weight_1x1_conv2d_linear_5;
  void* weight_1x1_conv2d_6;
  void* weight_depth_wise_6;
  void* weight_1x1_conv2d_linear_6;
  void* weight_1x1_conv2d_7;
  void* weight_depth_wise_7;
  void* weight_1x1_conv2d_linear_7;
  void* weight_1x1_conv2d_8;
  void* weight_depth_wise_8;
  void* weight_1x1_conv2d_linear_8;
  void* weight_1x1_conv2d_9;
  void* weight_depth_wise_9;
  void* weight_1x1_conv2d_linear_9;
  void* weight_1x1_conv2d_10;
  void* weight_depth_wise_10;
  void* weight_1x1_conv2d_linear_10;
  void* weight_1x1_conv2d_11;
  void* weight_depth_wise_11;
  void* weight_1x1_conv2d_linear_11;
  void* weight_1x1_conv2d_12;
  void* weight_depth_wise_12;
  void* weight_1x1_conv2d_linear_12;
  void* weight_1x1_conv2d_13;
  void* weight_depth_wise_13;
  void* weight_1x1_conv2d_linear_13;
  void* weight_1x1_conv2d_14;
  void* weight_depth_wise_14;
  void* weight_1x1_conv2d_linear_14;
  void* weight_1x1_conv2d_15;
  void* weight_depth_wise_15;
  void* weight_1x1_conv2d_linear_15;
  void* weight_1x1_conv2d_16;
  void* weight_depth_wise_16;
  void* weight_1x1_conv2d_linear_16;
  void* weight_1x1_conv2d_17;
  void* weight_depth_wise_17;
  void* weight_1x1_conv2d_linear_17;
  void* conv2d_2;
};

/*!
 * \brief Output tensor pointers for TVM module "default" 
 */
struct tvmgen_default_outputs {
  void* output;
};

/*!
 * \brief entrypoint function for TVM module "default"
 * \param inputs Input tensors for the module 
 * \param outputs Output tensors for the module 
 */
int32_t tvmgen_default_run(
  struct tvmgen_default_inputs* inputs,
  struct tvmgen_default_outputs* outputs
);
/*!
 * \brief Workspace size for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WORKSPACE_SIZE 181440

#ifdef __cplusplus
}
#endif

#endif // TVMGEN_DEFAULT_H_

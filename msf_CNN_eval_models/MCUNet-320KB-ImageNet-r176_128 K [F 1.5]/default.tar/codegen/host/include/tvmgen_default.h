#ifndef TVMGEN_DEFAULT_H_
#define TVMGEN_DEFAULT_H_
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*!
 * \brief Input tensor weight_1x1_conv2d_43 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_43_SIZE 11520
/*!
 * \brief Input tensor weight_depth_wise_38 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_38_SIZE 3000
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_43 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_43_SIZE 11520
/*!
 * \brief Input tensor weight_depth_wise_46 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_46_SIZE 23520
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_41 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_41_SIZE 6400
/*!
 * \brief Input tensor weight_depth_wise_34 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_34_SIZE 3920
/*!
 * \brief Input tensor weight_depth_wise_42 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_42_SIZE 5000
/*!
 * \brief Input tensor weight_1x1_conv2d_38 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_38_SIZE 2880
/*!
 * \brief Input tensor weight_1x1_conv2d_46 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_46_SIZE 46080
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_38 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_38_SIZE 2880
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_36 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_36_SIZE 1920
/*!
 * \brief Input tensor weight_1x1_conv2d_34 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_34_SIZE 1280
/*!
 * \brief Input tensor data size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_DATA_SIZE 92928
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_34 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_34_SIZE 1280
/*!
 * \brief Input tensor weight_depth_wise_37 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_37_SIZE 3000
/*!
 * \brief Input tensor weight_1x1_conv2d_42 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_42_SIZE 8000
/*!
 * \brief Input tensor weight_depth_wise_45 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_45_SIZE 2592
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_32 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_32_SIZE 384
/*!
 * \brief Input tensor weight_depth_wise_33 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_33_SIZE 720
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_48 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_48_SIZE 76800
/*!
 * \brief Input tensor weight_depth_wise_41 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_41_SIZE 4000
/*!
 * \brief Input tensor conv2d_1 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_CONV2D_1_SIZE 432
/*!
 * \brief Input tensor weight_1x1_conv2d_37 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_37_SIZE 2880
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_46 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_46_SIZE 46080
/*!
 * \brief Input tensor weight_1x1_conv2d_45 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_45_SIZE 13824
/*!
 * \brief Input tensor weight_depth_wise_1 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_1_SIZE 144
/*!
 * \brief Input tensor weight_depth_wise_48 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_48_SIZE 23520
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_44 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_44_SIZE 11520
/*!
 * \brief Input tensor weight_1x1_conv2d_33 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_33_SIZE 1280
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_42 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_42_SIZE 9600
/*!
 * \brief Input tensor weight_1x1_conv2d_41 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_41_SIZE 6400
/*!
 * \brief Input tensor weight_depth_wise_36 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_36_SIZE 2000
/*!
 * \brief Input tensor weight_depth_wise_44 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_44_SIZE 2160
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_40 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_40_SIZE 9600
/*!
 * \brief Input tensor weight_1x1_conv2d_48 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_48_SIZE 46080
/*!
 * \brief Input tensor weight_depth_wise_32 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_32_SIZE 1176
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_39 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_39_SIZE 4800
/*!
 * \brief Input tensor weight_depth_wise_40 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_40_SIZE 11760
/*!
 * \brief Input tensor weight_1x1_conv2d_36 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_36_SIZE 1280
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_37 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_37_SIZE 2880
/*!
 * \brief Input tensor weight_1x1_conv2d_44 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_44_SIZE 11520
/*!
 * \brief Input tensor weight_depth_wise_39 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_39_SIZE 1080
/*!
 * \brief Input tensor weight_depth_wise_47 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_47_SIZE 3456
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_35 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_35_SIZE 1024
/*!
 * \brief Input tensor weight_1x1_conv2d_32 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_32_SIZE 192
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_33 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_33_SIZE 1280
/*!
 * \brief Input tensor weight_depth_wise_35 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_35_SIZE 1600
/*!
 * \brief Input tensor weight_1x1_conv2d_40 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_40_SIZE 9600
/*!
 * \brief Input tensor weight_depth_wise_43 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_DEPTH_WISE_43_SIZE 11760
/*!
 * \brief Input tensor conv2d_2 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_CONV2D_2_SIZE 128
/*!
 * \brief Input tensor weight_1x1_conv2d_39 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_39_SIZE 2880
/*!
 * \brief Input tensor weight_1x1_conv2d_47 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_47_SIZE 36864
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_47 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_47_SIZE 36864
/*!
 * \brief Input tensor weight_1x1_conv2d_linear_45 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_LINEAR_45_SIZE 27648
/*!
 * \brief Input tensor weight_1x1_conv2d_35 size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WEIGHT_1X1_CONV2D_35_SIZE 1024
/*!
 * \brief Output tensor output size (in bytes) for TVM module "default" 
 */
#define TVMGEN_DEFAULT_OUTPUT_SIZE 5760
/*!
 * \brief Input tensor pointers for TVM module "default" 
 */
struct tvmgen_default_inputs {
  void* data;
  void* conv2d_1;
  void* weight_depth_wise_1;
  void* conv2d_2;
  void* weight_1x1_conv2d_32;
  void* weight_depth_wise_32;
  void* weight_1x1_conv2d_linear_32;
  void* weight_1x1_conv2d_33;
  void* weight_depth_wise_33;
  void* weight_1x1_conv2d_linear_33;
  void* weight_1x1_conv2d_34;
  void* weight_depth_wise_34;
  void* weight_1x1_conv2d_linear_34;
  void* weight_1x1_conv2d_35;
  void* weight_depth_wise_35;
  void* weight_1x1_conv2d_linear_35;
  void* weight_1x1_conv2d_36;
  void* weight_depth_wise_36;
  void* weight_1x1_conv2d_linear_36;
  void* weight_1x1_conv2d_37;
  void* weight_depth_wise_37;
  void* weight_1x1_conv2d_linear_37;
  void* weight_1x1_conv2d_38;
  void* weight_depth_wise_38;
  void* weight_1x1_conv2d_linear_38;
  void* weight_1x1_conv2d_39;
  void* weight_depth_wise_39;
  void* weight_1x1_conv2d_linear_39;
  void* weight_1x1_conv2d_40;
  void* weight_depth_wise_40;
  void* weight_1x1_conv2d_linear_40;
  void* weight_1x1_conv2d_41;
  void* weight_depth_wise_41;
  void* weight_1x1_conv2d_linear_41;
  void* weight_1x1_conv2d_42;
  void* weight_depth_wise_42;
  void* weight_1x1_conv2d_linear_42;
  void* weight_1x1_conv2d_43;
  void* weight_depth_wise_43;
  void* weight_1x1_conv2d_linear_43;
  void* weight_1x1_conv2d_44;
  void* weight_depth_wise_44;
  void* weight_1x1_conv2d_linear_44;
  void* weight_1x1_conv2d_45;
  void* weight_depth_wise_45;
  void* weight_1x1_conv2d_linear_45;
  void* weight_1x1_conv2d_46;
  void* weight_depth_wise_46;
  void* weight_1x1_conv2d_linear_46;
  void* weight_1x1_conv2d_47;
  void* weight_depth_wise_47;
  void* weight_1x1_conv2d_linear_47;
  void* weight_1x1_conv2d_48;
  void* weight_depth_wise_48;
  void* weight_1x1_conv2d_linear_48;
};

/*!
 * \brief Output tensor pointers for TVM module "default" 
 */
struct tvmgen_default_outputs {
  void* output;
};

/*!
 * \brief entrypoint function for TVM module "default"
 * \param inputs Input tensors for the module 
 * \param outputs Output tensors for the module 
 */
int32_t tvmgen_default_run(
  struct tvmgen_default_inputs* inputs,
  struct tvmgen_default_outputs* outputs
);
/*!
 * \brief Workspace size for TVM module "default" 
 */
#define TVMGEN_DEFAULT_WORKSPACE_SIZE 94224

#ifdef __cplusplus
}
#endif

#endif // TVMGEN_DEFAULT_H_
